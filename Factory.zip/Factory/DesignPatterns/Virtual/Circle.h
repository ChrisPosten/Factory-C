#ifndef CIRCLE_H_INCLUDED
#define CIRCLE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "Shape.h"

    #define Circle(Member) Circle##Member //namespace

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct Circle ;

    typedef struct Circle Circle;


    typedef struct Circle(VirtualTable)
    {   Shape(VirtualTable) base;
    } Circle(VirtualTable);


    struct Circle
    {   Shape base;

        size_t r;

    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Circle * Circle(Init)(Circle *, .../*size_t*/);

    static void Circle(Dtor)(Circle *) ;

    static cstring Circle(Type)() ;


    explicit void Circle(Dtor)(Circle * self)  {}

    explicit cstring Circle(Type)() { return "Circle"; }


    static size_t Circle(GetArea)(Circle *);


    static Circle(VirtualTable)

        Circle(Interface) =  //extended vto interface (pure Circle)
    {
        {
            & Circle(Type),

            & Circle(Init),

            & Circle(Dtor)
        },
        & Circle(GetArea)
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit Circle *

        Circle(Init)(Circle * self, .../*size_t r*/)//always check for self being null
    {                                    //inside initializer and return self
        /*if(self == nullptr){ return nullptr; }*/
                                       //to assure there will be no error
        stack(control)();           ///UPDATE: this keyword throws exception
                                   ///         so no need to check anymore
        size_t r = stack(arg)(size_t);


        self->r = r;                 //when this function is used as the
                                    //constructor for Circle:
        return self;               //
    }                             ///Shape * c = new(Circle)(this, ...);

    explicit size_t Circle(GetArea)(Circle * self)
    {                          //no need to check for self being null inside
        return 3.14 * pow(self->r, 2);//any other member function since
    }                        //the object passes itself into it's function
                            //as the function is called from the object's
                           //interface assigned to it by new(Class)
                          //and stored with the object in its slot in
                         //the vTable (virtual table)
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief  this may be the virtual pattern being covered but *
     *                                                           *
     *         a small factory table class will be implemented here
     *                                                           *
     *         so we can overlook the strategic significance of a*
     *                                                           *
     *         class factory method as a singleton method that is*
     *                                                           *
     *         used by an unregistered factory table class.      *
     *                                                           *
     *         not to put anyone in the corner away from factory *
     *                                                           *
     *         c to an earlier ooc definition where the interface*
     *                                                           *
     *         still has a problem or 2. the class interface heap*
     *                                                           *
     *         solves all the problems like where multiple inheritance
     *                                                           *
     *         is supposedly needed, like where to inherit the   *
     *                                                           *
     *         print method. here with the shapes will be some   *
     *                                                           *
     *         makeshift low-level overloads before introducing  *
     *                                                           *
     *         the factory table, and before going too slow, by  *
     *                                                           *
     *         only implementing the above code for a struct class
     *                                                           *
     *         that easily (properly) produces a virtual table   *
     *                                                           *
     *         object.  (or should they just register and use    *
     *                                                           *
     *                   factory()() and cout()()()?)            *
     *                                                           *
     *         i think to truly cover virtual a virtual heap     *
     *                                                           *
     *         should be included, but then the factory table... *
     *                                                           *
     *         (others like Adapter use a virtual heap (Duck))   *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static ctorPtr Circle(Ctor)();

    explicit ctorPtr Circle(Ctor)(){return new(Circle);}


    static struct class(FactoryTable)

        Circle(Factory) = //non-extended registration style interface
    {
        & class(FactoryTable)(Type),

        Circle(Ctor),

        0
    };


    #define defineCircleOut(Type,Print,End)\
    \
      /*static int*/ Circle(Type##Out)(Circle *);\
    \
      explicit int Circle(Type##Out)(Circle * self)\
      {\
          Print "%u", virtual(self, Shape)->getArea(this) End ;\
      }

    static int typename(CircleOut)(Console, _cPrint(), cEnd());

    static struct class(ConsoleTable)

        Circle(Console) =
    {
        & class(ConsoleTable)(Type),

        0,

        & Circle(ConsoleOut)
    };


    static Interface

        Circle(InterfaceHeap)[two] =

    {/*(by int_it:) abcdefghijklmnopqrstuvwxyz*/
        & Rectangle(Console),

        & Rectangle(Factory),

        nullptr
    };
    static Interface
    typename(ClassFactoryMethod)(Circle,0,1);//singleton method


    static void typename(Setup)(Circle){}

    static void typename(Abort)(Circle){}


                                                           //CWP
#endif // CIRCLE_H_INCLUDED
