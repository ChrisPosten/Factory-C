#ifndef COFFEE_H_INCLUDED
#define COFFEE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "CaffeineBeverage.h"

    #define Coffee(Member)  Coffee##Member
    typedef struct Coffee
    {   CaffeineBeverage base;

    }Coffee;


    typedef struct Coffee(VirtualTable)
    {   CaffeineBeverage(VirtualTable)base;
    }Coffee(VirtualTable);


    static Coffee * CoffeeInit( Coffee *, ... );

    static void CoffeeDtor( Coffee * );

    static cstring CoffeeType();


    explicit cstring CoffeeType(){ return "Coffee"; }


    static void CoffeeBrew ( Coffee * );

    static void CoffeeAdd ( Coffee * );


    static Coffee(VirtualTable)

        Coffee(Interface) =
    {//Coffee
        {//CaffeineBeverage
            {//structclass
                & CoffeeType,

                & CoffeeInit,

                & CoffeeDtor
            },//end structclass

            & CaffeineBeveragePrepare,

            & CaffeineBeverageBoil,

            & CoffeeBrew,

            & CaffeineBeveragePour,

            & CoffeeAdd
        }//end CaffeineBeverage
    };//end Coffee


    explicit Coffee * CoffeeInit( Coffee * self, ... )

    { if(!self){return 0;}

        //...

    return self;}

    explicit void CoffeeDtor( Coffee * self ) {}


    explicit void CoffeeBrew ( Coffee * self )
    {
        printf( "DrippingCoffeeThroughFilter\n" );
    }

    explicit void CoffeeAdd ( Coffee * self )
    {
        printf( "AddingSugarAndMilk\n" );
    }

#endif // COFFEE_H_INCLUDED
