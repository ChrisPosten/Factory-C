#ifndef DOOR_H_INCLUDED
#define DOOR_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../../OOC/Virtual/vTable.h"

    #include "../../OOC/Library/String.h"

    #define Door(Member)      Door##Member

    typedef struct
    {   struct class base;

        String * location; ///Garage

        uint8_t  percent;

    } Door;
    ///volatile static bool Door(Flag) = 0;  ///stop the door from going up, down

    ///volatile static void (*Door(Ptr)) ( Door * ) = 0;


    typedef struct
    {   struct class (VirtualTable) base;

        void (*up)( Door * );

        void (*down)( Door * );

        void (*stop)( Door * );

    }DoorVirtualTable;


    static Door * DoorInit( Door *, String *, uint8_t );

    static void DoorDtor( Door * );

    static cstring DoorType() ;


    explicit void DoorDtor( Door * self ){ delete(self->location); }

    explicit cstring DoorType() { return "Door"; }


    static void DoorUp( Door * );

    static void DoorDown( Door * );

    static void DoorStop( Door * );


    static DoorVirtualTable DoorInterface =

    {
      { &DoorType, &DoorInit, &DoorDtor },

        &DoorUp,

        &DoorDown,

        &DoorStop };


    explicit Door * DoorInit

        ( Door * self, String * location, uint8_t percent )

    { if(!self){return 0;}

        self->location = location;

        self->percent = percent;

      return self; }


    explicit void DoorUp( Door * self )

    { if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sDoor is going up:\n",
            virtual(self->location, String)
            ->toString(this) );

      while( self->percent <= 100 )
      { ///sleep(100);

        self->percent += 25;

            ///if( Door(Ptr) ) { Door(Ptr)(self); }///throw maybe

        printf("%d%%", self->percent); }

        printf("\n%sDoor is up.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    explicit void DoorDown( Door * self )

    { if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sDoor is going down:\n",
            virtual(self->location, String)
            ->toString(this) );

      while( self->percent >= 0 )
      { ///sleep(100);

        self->percent -= 25;

            ///if( Door(Ptr) ) { Door(Ptr)(self); }///throw maybe

        printf("%d%%", self->percent); }

        printf("\n%sDoor is down.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    explicit void DoorStop( Door * self )

    { if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sDoor is stopped.\n",
            virtual(self->location, String)
            ->toString(this) );



        /// ???


            }



#endif // DOOR_H_INCLUDED
