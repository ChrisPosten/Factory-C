#ifdef CHOCOLATEBOILERSINGLETON
    #ifndef FILL_H_INCLUDED
    #define FILL_H_INCLUDED

    explicit bool      fill(void)

    { return ChocolateBoiler(Fill)(cboiler); }

    #endif // FILL_H_INCLUDED
#endif // CHOCOLATEBOILERSINGLETON
