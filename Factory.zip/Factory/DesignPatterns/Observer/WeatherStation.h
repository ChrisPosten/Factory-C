#ifndef WEATHERSTATION_H_INCLUDED
#define WEATHERSTATION_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../../OOC/Adapter/Observer.h"

    #include "../../OOC/Template/defineVector.h"

    #include "../../OOC/Adapter/aTable.h"

    #include "../../DesignPatterns/Strategy/Display.h"


    #define WeatherStation(Member)  WeatherStation##Member
    #define WeatherStationSecurity(Member)  WeatherStationSecurity##Member

    #define pObserverIterator(Member)  pObserverIterator##Member

    #define pObserverVector(Member)  pObserverVector##Member


    //typename(Iterator)(pObserver);

    //typename(Vector)(pObserver, );//implement

    /// VIRTUAL TABLE OBJECT /// VIRTUAL TABLE OBJECT /// VIRTUAL TABLE OBJECT ///

    struct WeatherStation ;

    typedef struct WeatherStation WeatherStation;


    typedef struct WeatherStation (VirtualTable)
    {   Subject (VirtualTable) base;

        bool () (*insert)( WeatherStation *, ... );/// = 0              ()

        bool () (*remove)( WeatherStation *, ... );/// = 0              ()

    } WeatherStation (VirtualTable);


    struct WeatherStation
    {   Subject base;

        double      temperature,

                    humidity,

                    pressure;
    };


    static WeatherStation * WeatherStation(Init)(WeatherStation *, .../*Container * */);

    static void WeatherStation(Dtor)(WeatherStation *);

    static cstring WeatherStation(Type)();

    static ctorPtr WeatherStation(Ctor)();


    explicit cstring WeatherStation(Type)(){ return "WeatherStation"; }


    static void WeatherStation(Set)(WeatherStation *, double, double, double);

    static void WeatherStation(Notify)(WeatherStation *);


    static bool WeatherStation(InsertObserver)(WeatherStation *, .../*Observer * */);

    static bool WeatherStation(RemoveObserver)(WeatherStation *, .../*Observer * */);



    static WeatherStation(VirtualTable)

        WeatherStation(Interface) =
    {
        {
            {
                &WeatherStation(Type),

                &WeatherStation(Init),

                &WeatherStation(Dtor)
            },

            &WeatherStation(Set),

            &WeatherStation(Notify)
        },

        &WeatherStation(InsertObserver),

        &WeatherStation(RemoveObserver)
    };
    explicit ctorPtr WeatherStation(Ctor)(){return new(WeatherStation);}

    /**
     * @brief   initializer
     *
     * @param   self, observers
     *
     * @return  *
     */
    explicit WeatherStation *

        WeatherStation(Init)(WeatherStation * self, .../*Container * observers*/)
    {printf("WeatherStation(Init)()\n");
        //if( !self ) { return 0; }//not needed anymore (this throws an exception)

        Stack * stack = control();

        size_t c = arg(stack, size_t);
        switch(c)
        {
            case 0:
                self->base.observers = new(Vector(pObserver))(this, 0, 4);

                WeatherStationSet(self, 0.0f, 0.0f, 0.0f);
            break;
            case 1:    ;//(chicken scratch)

                WeatherStation * obj = arg(stack, WeatherStation*);

                self->base.observers = new(Vector(pObserver))
                    ( this, 1, obj->base.observers );

                WeatherStationSet(self, obj->temperature, obj->humidity, obj->pressure);
            break;
            case 2:
                self->base.observers = new(Vector(pObserver))
                    ( this, 1, arg(stack, Container*) );

                WeatherStationSet(self, arg(stack, double), arg(stack, double), arg(stack, double));
            break;
        }

        return self;
    }

    /**
     * @brief   set
     *
     * @param   self, temp, humi, pres
     *
     * @return  *
     */
    explicit void WeatherStation(Set)(WeatherStation * self, double temperature,

        double humidity, double pressure)
    {
        self->temperature   =   temperature;

        self->humidity      =   humidity;

        self->pressure      =   pressure;

        Subject(Flag)       =   true;

        printf("TURN ON/");


    }

    /**
     * @brief this one is the only one that worked for an abstract Container
     *
     * @param
     *
     * @return (error handling incomplete) ... {} <-- return ... throw ...
     */
    explicit bool WeatherStation(InsertObserver)(WeatherStation * self, .../*Observer * o*/)
    {
        Stack * stack = control();

        Observer * o = arg(stack, Observer*);

        if( (*self).base.observers )
        {
            if( !virtual((*self).base.observers, Container)
                ->insert(this, o) )
                    {return false;}  else  {return true;}
        }
        else
        {return false;}
    }

    /**
     * @brief   ...this needs to possibly delete() i would think
     *
     * @param
     *
     *  TODO: make this function handle an abstract Container
     *
     * @return (error handling incomplete) ... {} <-- return ...
     */
    explicit bool WeatherStation(RemoveObserver)(WeatherStation * self, .../*Observer * o*/)
    {
        /*Stack stack = control();

        Observer * o = arg(stack, Observer*);*/

        if( (*self).base.observers )
        {
            Object * obj = *(pObserver*)virtual( self->base.observers, Container )->at(this);

                delete(obj);

            if( !virtual((*self).base.observers, Container)
                ->remove(this) )
                    {return false;}  else  {return true;}
        }
        else
        {return false;}
    }

    /**
     * @brief ...
     *
     * @param self
     *
     *  TODO: make this function handle an abstract Container
     *
     * @return void
     */
    explicit void WeatherStation(Notify)(WeatherStation * self)
    {
        if( (*self).base.observers )
        {
            Iterator * iterator = virtual( ((Subject*)self)->observers, Container )->begin(this);

            size_t size = virtual( ((Subject*)self)->observers, Container )->size(this);

            for( size_t index = 0; index < size; index++ )
            {

                virtual( *(pObserver*)virtual( iterator, Iterator )->get(this), Observer )

                    ->update( this, self->temperature, self->humidity, self->pressure );


         //       update( *(pObserver*)virtual( iterator, Iterator )->get(this),

            //           self->temperature, self->humidity, self->pressure );

                virtual( iterator, Iterator )->next(this);
            }

            delete(iterator);

            Subject(Flag) = false;

            printf("TURN OFF\n");
        }
    }

    /**
     * @brief destructor
     *
     * @param self
     *
     *  TODO: make this function handle an abstract Container
     *
     * @return void
     */
    explicit void WeatherStation(Dtor)(WeatherStation * self)
    {printf("WeatherStation(Dtor)()\n");
        if( (*self).base.observers )
        {
            Iterator * iterator = virtual( ((Subject*)self)->observers, Container )->begin(this);

            size_t size = virtual( ((Subject*)self)->observers, Container )->size(this);

            for( size_t index = 0; index < size; index++ )
            {
                Object * obj = *(pObserver*)virtual( iterator, Iterator )->get(this);

                delete(obj);

                virtual( iterator, Iterator )->next(this);
            }
            delete(iterator);

            delete((*self).base.observers);
        }
    }


    /// VIRTUAL TABLE OBJECT /// VIRTUAL TABLE OBJECT /// VIRTUAL TABLE OBJECT ///

    /// FACTORY TABLE CLASS /// FACTORY TABLE CLASS /// FACTORY TABLE CLASS ///


    /**
     * @brief this is for the observers class(AdapterTable)
     */
    # define WeatherStationAdapterTable(Member)\
        WeatherStationAdapterTable ## Member
    static cstring WeatherStation(AdapterTable)(Type)();

    explicit cstring WeatherStation(AdapterTable)(Type)()
        {return"WeatherStation(AdapterTable)";}


    static Virtual  /**Table(Name, Pos, Default)**/

        WeatherStation(VirtualHeap)[seven] = /**CLASS VIRTUAL TABLE TABLE**/
    {/**A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P  Q  R  S  T  U  V  W  X  Y  Z**/
        { "dtor",             2,      &WeatherStation(Dtor)             },
        { "init",             1,      &WeatherStation(Init)             },
        { "insert",           5,      &WeatherStation(InsertObserver)   },
        { "notify",           4,      &WeatherStation(Notify)           },
        { "remove",           6,      &WeatherStation(RemoveObserver)   },
        { "set",              3,      &WeatherStation(Set)              },
        { "type",             0,      &WeatherStation(Type)             },

        { "", 0, 0 }
    };static Virtual *
    typename(SubFactoryMethod)(WeatherStation,Virtual,Virtual,0,6);


    static struct class(VirtualHeap)
        WeatherStation(Virtual) =

    { &class(VirtualHeap)(Type),
    &WeatherStation(VirtualSearch),
    WeatherStation(VirtualHeap) };


    static Complex  /**Grid( Name, Pos, Bytes, Type )**/
        WeatherStation(ComplexHeap)[four] =

    {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z**/
        { "humidity",     2,     sizeof(double),      "double"      },
        { "observers",    0,     sizeof(void*),       "Container*"  },
        { "pressure",     3,     sizeof(double),      "double"      },
        { "temperature",  1,     sizeof(double),      "double"      },

        { "", 0, 0, "" }
    };static Complex *
    typename(SubFactoryMethod)(WeatherStation,Complex,Complex,0,3);


    static struct class(ComplexHeap)
        WeatherStation(Complex) =

    { &class(ComplexHeap)(Type),
    &WeatherStation(ComplexSearch),
    WeatherStation(ComplexHeap) };


    static Polymorph  /**Grid( Name, Offset, Offset, Type )**/
        WeatherStation(PolymorphHeap)[two] =

    {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z**/
        { "Subject",                                    0,              0, "" },
        { "class",                                      0,              0, "" },
        /** THESE OFFSETS ARE IMPORTANT FOR WHEN THE
            OBJECT IS ADJACENT TO ANOTHER ON A STACK
               (TO SUPPORT MULTIPLE INHERITANCE)**/
        { "", 0, 0, "" }
    };static Polymorph *
    typename(SubFactoryMethod)(WeatherStation,Polymorph,Polymorph,0,1);


    static struct class(PolymorphHeap)
        WeatherStation(Polymorph) =

    { &class(PolymorphHeap)(Type),
      &WeatherStation(PolymorphSearch),
       WeatherStation(PolymorphHeap) };


    static struct class(FactoryTable)
        WeatherStation(Factory) =

    { &class(FactoryTable)(Type),
      &WeatherStation(Ctor), 0 } ;


    static Adapter
        WeatherStation(AdapterHeap)[four] =
    {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z**/
            { "CurrentConditions", "WeatherStation(CurrentConditions)" },
            { "Forecast",          "WeatherStation(Forecast)" },
            { "HeatIndex",         "WeatherStation(HeatIndex)" },
            { "Statistics",        "WeatherStation(Statistics)" },{"",""}
    };
    static Adapter *
    typename(SubFactoryMethod)(WeatherStation,Adapter,Adapter,0,3);


    static struct class(AdapterHeap)

        WeatherStation(Adapter) = { &class(AdapterHeap)(Type),
    &WeatherStation(AdapterSearch), WeatherStation(AdapterHeap) };


    static cstring typename(PassNumber)(WeatherStation, Security);

    extern struct pass(SecurityHeap)
        WeatherStation(Security) ;


    static Interface WeatherStation
        (InterfaceHeap)[seven] =

    {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z**/

        &WeatherStation(Security),  //0x...

        &WeatherStation(Interface), //WeatherStation

        &WeatherStation(Adapter),

        &WeatherStation(Complex),   //class(...)

        &WeatherStation(Factory),

        &WeatherStation(Polymorph),

        &WeatherStation(Virtual),   // ...

        nullptr

    } ;
    static Interface
    typename(ClassFactoryMethod)(WeatherStation,0,6);


    struct pass(SecurityHeap)
        WeatherStation(Security) =

    { { & WeatherStation(Security)(ID), 0,
          WeatherStation(InterfaceHeap) },
        & pass(SecurityHeap)(Type) } ;


    static void typename(Setup)(WeatherStation)
    {try{
        /** re-init the interface insert position for vector as an
            excuse for not using an adapter configuration of some sort */
        pObserverVectorInterface.base.insert = & pObserverVectorStackInsert;
        pObserverVectorInterface.base.remove = & pObserverVectorNoIndexRemove;
        /* actually: */
        /// * VirtualTable(Interface).search(vtable, vstk, (*self).base.observers)

            ///  = &pObserverVectorAdapterInterface; (insert, remove, at: NoIndex)



        ///virtual(self, WeatherStation)->notify(self);//too quick

        //a set function should only do what it implies and thats set values

        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


    static void typename(Abort)(WeatherStation)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}

    /// FACTORY TABLE CLASS /// FACTORY TABLE CLASS /// FACTORY TABLE CLASS ///


#endif // WEATHERSTATION_H_INCLUDED
