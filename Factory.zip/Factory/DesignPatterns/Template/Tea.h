#ifndef TEA_H_INCLUDED
#define TEA_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "CaffeineBeverage.h"

    #define Tea(Member)  Tea##Member
    typedef struct Tea
    {   CaffeineBeverage base;

    }Tea;


    typedef struct Tea(VirtualTable)
    {   CaffeineBeverage(VirtualTable)base;
    }Tea(VirtualTable);


    static Tea * TeaInit( Tea *, ... );

    static void TeaDtor( Tea * );

    static cstring TeaType();


    explicit cstring TeaType(){ return "Tea"; }


    static void TeaBrew ( Tea * );

    static void TeaAdd ( Tea * );


    static Tea(VirtualTable)

        Tea(Interface) =
    {//Tea
        {//CaffeineBeverage
            {//structclass
                & TeaType,

                & TeaInit,

                & TeaDtor
            },//end structclass

            & CaffeineBeveragePrepare,

            & CaffeineBeverageBoil,

            & TeaBrew,

            & CaffeineBeveragePour,

            & TeaAdd
        }//end CaffeineBeverage
    };//end Tea


    explicit Tea * TeaInit( Tea * self, ... )

    { if(!self){return 0;}

        //...

    return self;}

    explicit void TeaDtor( Tea * self ) {}


    explicit void TeaBrew ( Tea * self )
    {
        printf( "SteepingTheTea\n" );
    }

    explicit void TeaAdd ( Tea * self )
    {
        printf( "AddingLemon\n" );
    }


#endif // TEA_H_INCLUDED
