#ifndef CONDIMENTDECORATOR_H_INCLUDED
#define CONDIMENTDECORATOR_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "Beverage.h"


   #define CondimentDecorator(Member)CondimentDecorator ## Member
    struct CondimentDecorator ; //Decorator pattern

    typedef struct CondimentDecorator CondimentDecorator;


    typedef struct CondimentDecorator(VirtualTable)
    {   Beverage(VirtualTable) base;
    } CondimentDecorator(VirtualTable);


    struct CondimentDecorator
    {   Beverage base;
    };

    /*
        this class must be for the class name only as its a
        seemingly pointless extension...

        I still question if this empty struct is necessary at all
        but the example did come from a Java book and a prototype
        needed to be redeclared as abstract, so if that necessary there...

        this is otherwise just an empty Class thats there for the
        extra data-type name because you must add this in a class hierarchy:

                            Beverage
                           /        \
        Espresso, DarkRoast, ...     CondimentDecorator   (empty)
                                      \
                                       Mocha, Whip, ...

        now that i think about it, this is the all important extension
        that makes our class hierarchy worth considering for the Decorator pattern
        (even though its still empty)

        by worth considering, i mean worth considering to someone who
        probably would have an opinion that counts, even tho they may
        only look at class hierarchies, UML, ...

    */

    ///static CondimentDecoratorVirtualTable

    ///    CondimentDecoratorInterface = {{{0,0},0,0}};


    ///lol (nothing to add)

    ///now write: define(Decorator)(Beverage); OR NOT


#endif // CONDIMENTDECORATOR_H_INCLUDED
