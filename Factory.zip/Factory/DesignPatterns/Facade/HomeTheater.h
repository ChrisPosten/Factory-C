#ifndef HOMETHEATER_H_INCLUDED
#define HOMETHEATER_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
	///#define println( arg )   puts( arg "\n" )

	///#define print( arg )     puts( arg )



	#include "Tuner.h"

	#include "TheaterLights.h"

	#include "StreamingPlayer.h"

	#include "Screen.h"

	#include "Projector.h"

	#include "PopcornPopper.h"

	#include "CDPlayer.h"

	#include "Amplifier.h"



        /**
         * THIS IS THE FACADE PATTERNS FACADE CLASS
         */
    #define HomeTheater(Member)  HomeTheater##Member
    typedef struct HomeTheater
    { struct class base;

        Amplifier *         amp;

        Tuner *             tuner;

        StreamingPlayer *   player;

        CDPlayer *          cd;

        Projector *         projector;

        TheaterLights *     lights;

        Screen *            screen;

        PopcornPopper *     popper;

    }HomeTheater;


    typedef struct HomeTheater(VirtualTable)
    { struct class (VirtualTable) base;

        void (*watchMovie)( HomeTheater *, String * );

        void (*endMovie)( HomeTheater * );

        void (*listenToRadio) ( HomeTheater *, double ) ;

        void (*endRadio)( HomeTheater * ) ;

    }HomeTheater(VirtualTable);


    static HomeTheater * HomeTheaterInit( HomeTheater *,


                                    Amplifier * ,

                                    Tuner *     ,

                                    StreamingPlayer *,

                                    CDPlayer *,

                                    Projector * ,

                                    TheaterLights *,

                                    Screen *    ,

                                    PopcornPopper * );

    static void HomeTheaterDtor( HomeTheater * );

    static cstring HomeTheaterType() ;


    explicit cstring HomeTheaterType() { return "HomeTheater"; }


    static void HomeTheaterWatchMovie( HomeTheater *, String * );

    static void HomeTheaterEndMovie( HomeTheater * );

    static void HomeTheaterListenToRadio ( HomeTheater *, double ) ;

    static void HomeTheaterEndRadio( HomeTheater * ) ;


    static HomeTheater(VirtualTable)

        HomeTheater(Interface) =

    {
        {
            &HomeTheaterType,

            &HomeTheaterInit,

            &HomeTheaterDtor
        },

        &HomeTheaterWatchMovie,

        &HomeTheaterEndMovie,

        &HomeTheaterListenToRadio,

        &HomeTheaterEndRadio
    };


    /**
     * @brief   initializer
     *
     * @param   self, ... (everything from Facade folder)
     *
     * @return  *
     */
    explicit HomeTheater * HomeTheaterInit( HomeTheater *      self,


                                    Amplifier *         amp,

                                    Tuner *             tuner,

                                    StreamingPlayer *   player,

                                    CDPlayer *          cd,

                                    Projector *         projector,

                                    TheaterLights *     lights,

                                    Screen *            screen,

                                    PopcornPopper *     popper )

    {
        if(!self){return 0;}

		self->amp           =       amp;

		self->tuner         =       tuner;

		self->player        =       player;

		self->cd            =       cd;

		self->projector     =       projector;

		self->lights        =       lights;

		self->screen        =       screen;

		self->popper        =       popper;


		return self;
    }

    /**
     * @brief   destructor
     *
     * @param   self
     *
     * @return  void
     */
    explicit void HomeTheaterDtor( HomeTheater * self )
    {
		delete(self->amp);

		delete(self->tuner);

		delete(self->player);

		delete(self->cd);

		delete(self->projector);

		delete(self->lights);

		delete(self->screen);

		delete(self->popper);
    }

    //#define int(member) int##member
    //typename (Object)  (int);
    /**
     * @brief   watchMovie
     *
     * @param   self, movie
     *
     * @return  void
     */
    explicit void HomeTheaterWatchMovie( HomeTheater * self, String * movie )
    {
		printf("\nGet ready to watch a movie->->->\n");

		virtual( self->popper, PopcornPopper ) -> on(this);
//printf("on\n");
		virtual( self->popper, PopcornPopper )->pop(this);
//printf("pop\n");
		virtual( self->lights, TheaterLights ) ->dim(this, 10);
//printf("dim\n");
		virtual( self->screen, Screen) ->down(this);
//printf("down\n");
		virtual( self->projector, Projector )->on(this);
//printf("on\n");
		virtual( self->projector, Projector )->wideScreenMode(this);
//printf("wide\n");
		virtual( self->amp, Amplifier )->on(this);
//printf("on\n");
		virtual( self->amp, Amplifier )->setStreamingPlayer(this, self->player);
//printf("set1\n");
		virtual( self->amp, Amplifier )->setSurroundSound(this);
//printf("set2\n");
		virtual( self->amp, Amplifier )->setVolume(this, 5);
//printf("set3\n");
		virtual( self->player, StreamingPlayer ) -> on(this);
//printf("on\n");
		virtual( self->player, StreamingPlayer ) -> play(this, movie);
//printf("on\n");
        int * i = new (int) (this, 4);

            virtual( self->player, StreamingPlayer ) -> play(this, i);

		delete(i);
//printf("play\n");
    }

    /**
     * @brief   endMovie
     *
     * @param   self
     *
     * @return  void
     */
    explicit void HomeTheaterEndMovie( HomeTheater * self )
    {
		printf("\nShutting movie theater down->->->\n");

		virtual( self->popper, PopcornPopper )->off(this);
//printf("off\n");
		virtual( self->lights, TheaterLights )->on(this);
//printf("on\n");
		virtual( self->screen, Screen )->up(this);
//printf("up\n");
		virtual( self->projector, Projector )->off(this);
//printf("off1\n");
		virtual( self->amp, Amplifier )   ->   off(this);
//printf("off2\n");
		virtual( self->player, StreamingPlayer )->stop(this);
//printf("stop\n");
		virtual( self->player, StreamingPlayer )->off(this);
//printf("off\n");
    }

    /**
     * @brief   listenToRadio
     *
     * @param   self, freq
     *
     * @return  void
     */
    explicit void HomeTheaterListenToRadio ( HomeTheater * self, double frequency )
    {
		printf("\nTuning in the airwaves->->->\n");

		virtual( self->tuner, Tuner )->on(this);

		virtual( self->tuner, Tuner )->setFrequency(this, frequency);

		virtual( self->amp, Amplifier) ->on(this);

		virtual( self->amp, Amplifier )->setVolume(this, 5);

		virtual( self->amp, Amplifier )->setTuner(this, self->tuner);
    }

    /**
     * @brief   endRadio
     *
     * @param   self
     *
     * @return  void
     */
    explicit void HomeTheaterEndRadio( HomeTheater * self )
    {
		printf("\nShutting down the tuner->->->\n");

		virtual( self->tuner, Tuner )->off(this);

		virtual( self->amp, Amplifier )->off(this);
    }



#endif // HOMETHEATER_H_INCLUDED
