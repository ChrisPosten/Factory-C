#ifndef PIZZAFACTORY_H_INCLUDED
#define PIZZAFACTORY_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #include "../../OOC/Virtual/vTable.h"

    #include "../../OOC/Library/String.h"

    #include "../../OOC/Exception/Exception.h"

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**
        the Factory C function named factory()() is the fully

        dynamic function for the factory method that includes

        being able to call the constructor at the same point

        as the function that is used for calling every hook

        function that is a function used to encapsulate every

        case of the use of the macro new() without calling the

        constructor () (factory()()). the only thing to do

        after that for the solution from the textbook would be

        to restrict how dynamic it is including having an

        involved strategy that includes a strategic function

        pointer for there to be separate lists of available

        pizza(s). i believe that is because their is a small

        facade going on here also.
     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #undef  Pizza
    #define Pizza(Member)              Pizza##Member

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                     pizza interface                       */;
    typedef struct Pizza { struct class base; } Pizza;

    typedef struct Pizza     (VirtualTable)
    { struct class (VirtualTable) base;

        void (*prepare)( Pizza * );

        void (*bake)( Pizza * );

        void (*cut)( Pizza * );

        void (*box)( Pizza * );
    }
      Pizza                  (VirtualTable);

    #undef Pizza
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*         concrete pizzas (typename macro factory)          */
    #include "definePizza.h"
                        ///City##Type##Pizza##Member
    #define NYCheesePizza(Member)  NYCheesePizza##Member
    typename(Pizza)(NY, Cheese);

        #define NYPepperoniPizza(Member)  NYPepperoniPizza##Member
        typename(Pizza)(NY, Pepperoni);

            #define NYClamPizza(Member)  NYClamPizza##Member
            typename(Pizza)(NY, Clam);

                #define NYVeggiePizza(Member)  NYVeggiePizza##Member
                typename(Pizza)(NY, Veggie);


    #define ChicagoCheesePizza(Member)  ChicagoCheesePizza##Member
    typename(Pizza)(Chicago, Cheese);

        #define ChicagoPepperoniPizza(Member)  ChicagoPepperoniPizza##Member
        typename(Pizza)(Chicago, Pepperoni);

            #define ChicagoClamPizza(Member)  ChicagoClamPizza##Member
            typename(Pizza)(Chicago, Clam);

                #define ChicagoVeggiePizza(Member)  ChicagoVeggiePizza##Member
                typename(Pizza)(Chicago, Veggie);


    #define MoscowCheesePizza(Member)  MoscowCheesePizza##Member
    typename(Pizza)(Moscow, Cheese);

        #define MoscowPepperoniPizza(Member)  MoscowPepperoniPizza##Member
        typename(Pizza)(Moscow, Pepperoni);

            #define MoscowClamPizza(Member)  MoscowClamPizza##Member
            typename(Pizza)(Moscow, Clam);

                #define MoscowVeggiePizza(Member)  MoscowVeggiePizza##Member
                typename(Pizza)(Moscow, Veggie);


    #define SmolenskCheesePizza(Member)  SmolenskCheesePizza##Member
    typename(Pizza)(Smolensk, Cheese);

        #define SmolenskPepperoniPizza(Member)  SmolenskPepperoniPizza##Member
        typename(Pizza)(Smolensk, Pepperoni);

            #define SmolenskClamPizza(Member)  SmolenskClamPizza##Member
            typename(Pizza)(Smolensk, Clam);

                #define SmolenskVeggiePizza(Member)  SmolenskVeggiePizza##Member
                typename(Pizza)(Smolensk, Veggie);


            ///...
    #define BukarestCheesePizza(Member)  BukarestCheesePizza##Member
    typename(Pizza)(Bukarest, Cheese);

        #define BukarestPepperoniPizza(Member)  BukarestPepperoniPizza##Member
        typename(Pizza)(Bukarest, Pepperoni);

            #define BukarestClamPizza(Member)  BukarestClamPizza##Member
            typename(Pizza)(Bukarest, Clam);

                #define BukarestVeggiePizza(Member)  BukarestVeggiePizza##Member
                typename(Pizza)(Bukarest, Veggie);


                ///looks like romania has been invaded!
    #define BudapestCheesePizza(Member)  BudapestCheesePizza##Member
    typename(Pizza)(Budapest, Cheese);

        #define BudapestPepperoniPizza(Member)  BudapestPepperoniPizza##Member
        typename(Pizza)(Budapest, Pepperoni);

            #define BudapestClamPizza(Member)  BudapestClamPizza##Member
            typename(Pizza)(Budapest, Clam);

                #define BudapestVeggiePizza(Member)  BudapestVeggiePizza##Member
                typename(Pizza)(Budapest, Veggie);


    #define RomeCheesePizza(Member)  RomeCheesePizza##Member
    typename(Pizza)(Rome, Cheese);

        #define RomePepperoniPizza(Member)  RomePepperoniPizza##Member
        typename(Pizza)(Rome, Pepperoni);

            #define RomeClamPizza(Member)  RomeClamPizza##Member
            typename(Pizza)(Rome, Clam);

                #define RomeVeggiePizza(Member)  RomeVeggiePizza##Member
                typename(Pizza)(Rome, Veggie);


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z*/
    /**
    cstring PizzaFactoryCountries[five] =
    {
        "America",

        "Hungary",

        "Italy", *//* the best! *//**

        "Romania", *//* yummy! *//**

        "Russia",

        ""   };
    */
    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactoryCities[seven]  =
    {
        "Budapest",

        "Bukarest",

        "Chicago",

        "Moscow",

        "NY",

        "Rome",

        "Smolensk",

        ""    };

    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactoryNYPizzas[four]  =
    {
        "Cheese",

        "Clam",

        "Pepperoni",

        "Deluxe",

        ""    };

    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactoryMoscowPizzas[four]  =
    {
        "Cheese",

        "Pepperoni",

        "Deluxe",

        "Veggie",

        ""    };

    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactoryChicagoPizzas[four]  =
    {
        "Pepperoni",

        "Veggie",

        "Deluxe",

        ""    };

    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactorySmolenskPizzas[four]  =
    {
        "Clam",

        "Veggie",

        "Deluxe",

        ""    };

    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactoryBukarestPizzas[four]  =
    {
        "Pepperoni",

        "Veggie",

        "Deluxe",

        ""    };

    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactoryBudapestPizzas[four]  =
    {
        "Pepperoni",

        "Veggie",

        "Deluxe",

        ""    };

    /**ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
    static cstring PizzaFactoryRomePizzas[four]  =
    {
        "Clam",

        "Deluxe",

        "Pepperoni",

        ""    };

    /// ... toppings? maybe a sub-factory for topping classes?

    /// ... when toppings go inside pizzas?

    /** ... this Factory pattern example as a design-level pattern
            is primed with enthusiasm and good ideas, but i can't
            stand it much so im going to just move on with patterns

            ... I find problems in the level of abstraction i want
            with a factory that is this design-level Factory has
            when it becomes a problem to solve using sets of strings
            or a problem to solve by concatenationg strings when
            factory("Class")(this, ...); is available...

            a factory in a real program would need tables of strings
            or certain data members that are String objects not
            cstrings but something more dynamic on that end maybe,

            but its only as dynamic as the amount of implementations
            there are...


            I WILL RE-IMPLEMENT THE PIZZA FACTORY WITH MY OWN CHOICE

            OF AN IMPLEMENTATION THAT CAN BE CONSIDERED PREPARATION

            OR JUST SOMETHING TO HELP GIVE AN UNDERSTANDING OF A

            FACTORY TABLE CLASS BECAUSE IT WILL INCLUDE SOME OF THE

            STATIC TABLES A FACTORY TABLE CLASS NEEDS TO BECOME

            FULLY-DYNAMIC. STRATEGY IS USED WITH A STRATEGY ARRAY

            THATS A FUNCTION NAME (STRING) IN A SLOT WITH A FUNCTION

            ADDRESS AS A CONSTANT VALUE. FACTORY METHOD TOKEN

            TABLES WILL BE REQUIRED FOR EACH CITY AND THEY CAN ALL

            GO INTO THEIR OWN STRATEGY TABLE THEMSELVES.(01/23/2022)


            - - -TEMPLATE FACTORY METHOD STRATEGY SINGLETON- - -


                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                        pizza store                        */
    struct PizzaFactory;//un-implemented structured datatype
    #if 0
    typedef ctorPtr Constructor;      ///factory method return type

    ///look inside Object.h for type define by typedef: ctorPtr
    #endif // 0

    ///declare singleton here

    #define PizzaFactory(Member) PizzaFactory##Member
    typedef struct PizzaFactory PizzaFactory;
    struct PizzaFactory  /* restaurant */
    {   struct class base;

        cstring   * city;

        Container * recipes;

        Pizza * (*createPizza)( String * );///strategic

    };//implemented


    typedef struct PizzaFactory (VirtualTable)
    {   struct class (VirtualTable) base;

        PizzaFactory * self;  ///or declare singleton here

        Pizza * (*orderPizza)( PizzaFactory *, String * );///not

    } PizzaFactory (VirtualTable);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

        ///add a level of strategy to our factory pattern example


    ///typename (Pair) (Name, CreatePizza);
            //just for the sake of it (implement)


    static Constructor NYCreatePizza( String * );

    static Constructor ChicagoCreatePizza( String * );



    static Constructor MoscowCreatePizza( String * );

    static Constructor SmolenskCreatePizza( String * );



    static Constructor BukarestCreatePizza( String * );

    static Constructor BudapestCreatePizza( String * );

    static Constructor RomeCreatePizza( String * );


    ///static Strategy


    static Strategy

        PizzaFactory(StrategyHeap)[seven] =
    { /**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z*/
        {
            "Budapest",     & BudapestCreatePizza
        },
        {
            "Bukarest",     & BukarestCreatePizza
        },
        {
            "Chicago",      & ChicagoCreatePizza
        },
        {
            "Moscow",       & MoscowCreatePizza
        },
        {
            "NY",           & NYCreatePizza
        },
        {
            "Smolensk",     & SmolenskCreatePizza
        },
        {
            "Rome",         & RomeCreatePizza
        },

        {   "",             0 }
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static PizzaFactory * PizzaFactory(Init)( PizzaFactory *,

        Constructor (*)( String * ) );

    static void PizzaFactory(Dtor)(PizzaFactory *);

    static cstring PizzaFactory(Type)();


    explicit void PizzaFactory(Dtor)(PizzaFactory * self) {}

    explicit cstring PizzaFactory(Type)(){ return "PizzaFactory"; }


    static Pizza * PizzaFactoryOrderPizza( PizzaFactory *, String * );


    static PizzaFactory (VirtualTable) PizzaFactory(Interface) =
    {
        {
            &PizzaFactoryType,

            &PizzaFactoryInit,

            &PizzaFactoryDtor
        },

        0, ///singleton pointer

        &PizzaFactoryOrderPizza };///not strategic


    explicit PizzaFactory * PizzaFactoryInit( PizzaFactory * self,

        Constructor (*createPizza)( String * ) )

    {   if( !self ){ return 0; }

        self->createPizza = createPizza;///strategic



        /* restarants */


        return self; }


    explicit Pizza * PizzaFactoryOrderPizza( PizzaFactory * self,

        String * type )
    {
        Pizza * pizza;



        ///pizza = self->createPizza( type )(this, 12, 8.99, "Debit");




        ///pizza = factory( virtual( type, String )->toString(this) )(this);





        ///if( !pizza ){ throw( new(Exception) ) (this, "NOT IMPLEMENTED") ; }///LAST RESORT


        return pizza; }


    explicit Constructor NYCreatePizza( String * recipe )
    {   printf("NY: ");



        ///maybe treat this function as place to concatenate strings ? ...



        return factory( recipe ); }

    explicit Constructor ChicagoCreatePizza( String * recipe )
    {   printf("Chicago: ");



        ///... ?




        return factory( recipe ); }

    explicit Constructor MoscowCreatePizza( String * recipe )
    {   printf("Moscow: ");


        ///...



        return factory( recipe ); }

    explicit Constructor SmolenskCreatePizza( String * recipe )
    {   printf("Smolensk: ");


        ///...





        return factory( recipe ); }

    explicit Constructor BukarestCreatePizza( String * recipe )
    {   printf("Bukarest: ");




        ///...


        return factory( recipe ); }

    explicit Constructor BudapestCreatePizza( String * recipe )
    {   printf("Budapest: ");


        ///...




        return factory( recipe ); }

    explicit Constructor RomeCreatePizza( String * recipe )
    {   printf("Rome: ");


        ///...




        return factory( recipe ); }





    /** REMEMBER YOU CAN DATATYPE AN ARRAY TO HOLD A SINGLE TYPE OF FUNCTION */

    /** THE COMMAND PATTERN REVOLVES AROUND SOMETHING LIKE THAT */


#endif // PIZZAFACTORY_H_INCLUDED
