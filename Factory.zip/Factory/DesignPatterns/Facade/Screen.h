#ifndef SCREEN_H_INCLUDED
#define SCREEN_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #define Screen(Member)Screen##Member
    typedef struct Screen
    {   struct class base;

        String * description;

    }Screen;


    typedef struct Screen(VirtualTable)
    {   struct class(VirtualTable) base;

        void (*up) ( Screen * );

        void (*down)( Screen * );

        cstring () (*toString)( Screen * );

    }Screen(VirtualTable);


    static Screen * ScreenInit( Screen *, String *, ... );

    static void ScreenDtor( Screen * );

    static cstring ScreenType();


    explicit cstring ScreenType(){ return "Screen"; }


    static void ScreenUp ( Screen * );

    static void ScreenDown( Screen * );

    static cstring ScreenToString( Screen * );


    static Screen(VirtualTable)

        Screen(Interface) =

    {
        {
            &ScreenType,

            &ScreenInit,

            &ScreenDtor
        },

        &ScreenUp,

        &ScreenDown,

        &ScreenToString
    };


    /**
     * @brief   initializer (constructor)
     *
     * @param   self, desc
     *
     * @return  *
     */
    explicit Screen * ScreenInit( Screen * self,

        String * description, ... )
    {
        if( !self ){ return 0; }

        self->description = description;

        return self;
    }

    /**
     * @brief   destructor
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ScreenDtor( Screen * self )
    {
        delete(self->description);
    }


    /**
     * @brief   up
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ScreenUp ( Screen * self )
    {
        printf("%s going up\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief   down
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ScreenDown( Screen * self )
    {
        printf("%s going down\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief   virtual(screen, Screen) -> toString(this);
     *
     * @param   self or this
     *
     * @return  cstring
     */
    explicit cstring ScreenToString( Screen * self )
    {
        return virtual( self->description, String )->toString(this) ;
    }


#endif // SCREEN_H_INCLUDED
