#ifndef STATISTICS_H_INCLUDED
#define STATISTICS_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #include "WeatherStation.h"

    #define Statistics(Member)  Statistics##Member

    #define WeatherStationStatistics(Member)\
    \
        WeatherStationStatistics##Member

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct Statistics;

    typedef struct Statistics Statistics;


    typedef struct Statistics (VirtualTable)
    {   Observer (VirtualTable) base;
    }Statistics (VirtualTable);


    struct Statistics
    {   Observer base;

        double       max_temp,

                     min_temp,

                     temp_sum;

        size_t       num_read;
    };

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Statistics * Statistics(Init)(Statistics *);

    static void Statistics(Dtor)(Statistics *) ;

    static cstring Statistics(Type)();

    static ctorPtr Statistics(Ctor)();


    explicit void Statistics(Dtor)(Statistics * self)  { }

    explicit cstring Statistics(Type)(){ return "Statistics"; }

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static void StatisticsUpdate( Statistics *, ... );

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static Statistics * WeatherStation(Statistics)(Init)(Statistics *, ...);///
                                                                    /// /// /// /// ///
    static void WeatherStation(Statistics)(Update)( Statistics *, ... ); /// ///

    static void WeatherStation(Statistics)(Dtor)( Statistics * );

    explicit void WeatherStation(Statistics)(Dtor)( Statistics * self )

    { AdapterTable(Interface).remove( atable, self ); }

    static ctorPtr WeatherStation(Statistics)(Ctor)();

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    static Statistics (VirtualTable)

        Statistics (Interface) =
    {
        {
            {
                &Statistics(Type),

                &Statistics(Init),

                &Statistics(Dtor)
            },

            &Statistics(Update)
        }
    };
    explicit ctorPtr Statistics(Ctor)(){return new(Statistics);}

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static Statistics (VirtualTable)

        WeatherStation(Statistics)(Interface) =
    {
        {
            {
                &Statistics(Type),
                         /// /// /// /// /// /// /// /// ///
                &WeatherStation(Statistics)(Init), /// ///
                         /// /// /// /// /// /// /// ///
                &WeatherStation(Statistics)(Dtor)
            }, /// /// /// /// /// /// /// /// /// ///
                 /// /// /// /// /// /// /// /// /// /// ///
            &WeatherStation(Statistics)(Update) /// /// ///
        } /// /// /// /// /// /// /// /// /// ///
    };
    explicit ctorPtr WeatherStation(Statistics)(Ctor)()
    { return adapter(WeatherStation,Statistics); }
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit Statistics * Statistics(Init)( Statistics * self )
    {
        if( self == nullptr ){ return nullptr; }

        self->max_temp      =       0.0f;

        self->min_temp      =       0.0f;

        self->temp_sum      =       0.0f;

        self->num_read      =       0;

        return self;
    }

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit Statistics * WeatherStation(Statistics)(Init)

        ( Statistics * self, ... )
    {
        if( self == nullptr ){ return nullptr; } /// /// /// ///

        Stack * stack = control(); /// /// /// /// /// ///(factory function case)

        WeatherStation * host = arg(stack, Object *); /// /// /// ///


        self->max_temp      =       0.0f;

        self->min_temp      =       0.0f;

        self->temp_sum      =       0.0f;

        self->num_read      =       0;

         /// /// /// /// /// /// /// ///
        AdapterTable(Interface).insert( atable, self, host );
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WeatherStation(InsertObserver)(host, self);//removed from interface by choice
                                             //since no need to be dynamic
        return self; /// /// /// ///
    } /// /// /// ///
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    explicit void Statistics(Update)( Statistics * self, ... )
    {
        Stack * stack = control();

        double temperature = arg(stack, double);



        self->temp_sum += temperature;

        self->num_read++;

        if( temperature > self->max_temp )
        {
            self->max_temp = temperature;
        }
        if( self->min_temp == 0 )
        {
            self->min_temp = temperature;
        }
        if( temperature < self->min_temp )
        {
            self->min_temp = temperature;
        }

    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    explicit void WeatherStation(Statistics)(Update)

        ( Statistics * self, ... )
    {// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        Stack * stack = control();

        if( Subject(Flag) == true )  //2) BASE CASE 2 (ON)
        {printf("ON/");


            double temperature = arg(stack, double);


            self->temp_sum += temperature;

            self->num_read++;

            if( temperature > self->max_temp )
            {
                self->max_temp = temperature;
            }

            if( self->min_temp == 0 )
            {
                self->min_temp = temperature;
            }

            if( temperature < self->min_temp )
            {
                self->min_temp = temperature;
            }

        }
        if( Subject(Flag) == false ) //1) BASE CASE 1 (OFF)
        {printf("OFF/");Subject(Flag) = true;

            virtual( friend( self ), Subject )

                ->assign( this, arg(stack, double),

                      arg(stack, double), arg(stack, double) );

            virtual( friend( self ), Subject )

                ->notify( this );
        }
    } /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit int Statistics(Display)( Statistics * self )
    {
        printf("\t   << STATISTICS DISPLAY >>\n\n");
        if( !self->num_read )
        {
            printf("average:\t\t\t\t%s\n", "NULL");
        }
        else
        {
            printf("average:\t\t\t\t%.3f\n",

                (double)(self->temp_sum / self->num_read));
        }


        printf("maximum:\t\t\t\t%.3f\n", self->max_temp);

        printf("minimum:\t\t\t\t%.3f\n", self->min_temp);

        printf("sum_of_temperatures:\t\t\t%.3f\n", self->temp_sum);

        printf("number_of_reads:\t\t\t%d\n\n\n", self->num_read);

        return 0;
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    static Virtual  /**Table(Name, Pos, Default)**/

        Statistics(VirtualHeap)[four] = /**CLASS VIRTUAL TABLE TABLE**/
    {/**A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P  Q  R  S  T  U  V  W  X  Y  Z**/
        { "dtor",             2,      &Statistics(Dtor)             },
        { "init",             1,      &Statistics(Init)             },
        { "type",             0,      &Statistics(Type)             },
        { "update",           3,      &Statistics(Update)           },

        { "", 0, 0 }
    };static Virtual *
    typename(SubFactoryMethod)(Statistics,Virtual,Virtual,0,3);


    static struct class(VirtualHeap)
        Statistics(Virtual) =

    { &class(VirtualHeap)(Type),
    &Statistics(VirtualSearch),
    Statistics(VirtualHeap) };


    static struct class(FactoryTable)

        Statistics(Factory) =
    {
        &class(FactoryTable)(Type),
        &Statistics(Ctor),0 };


    static struct class (AdapterTable)
        WeatherStation(Statistics)(Adapter) =

    {&WeatherStation(AdapterTable)(Type),&WeatherStation(Statistics)(Init),
     &WeatherStation(Statistics)(Interface)};


    static struct class (ConsoleTable)
        Statistics(Console) =

    {&class(ConsoleTable)(Type),0,
     &Statistics(Display)};

   # define StatisticsSecurity(Member)StatisticsSecurity ## Member
    static cstring typename(PassNumber)(Statistics, Security);

    extern struct pass(SecurityHeap)

        Statistics(Security) ;


    static Interface Statistics(InterfaceHeap)[six] =
    {
      &Statistics(Security),

      &Statistics(Interface),//capital S

      &WeatherStation(Statistics)(Adapter),// capital W with WeatherStation

      &Statistics(Console),

      &Statistics(Factory),//lowercase c then F with class(FactoryTable)

      &Statistics(Virtual),

      nullptr
    };

    ///class construction/template macro
    static Interface typename(ClassFactoryMethod)(Statistics,0,5);


    struct pass(SecurityHeap)

        Statistics(Security) =

    { { & Statistics(Security)(ID), 0,

          Statistics(InterfaceHeap) },

        & pass(SecurityHeap)(Type) } ;


    static void typename(Setup)(Statistics)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


    static void typename(Abort)(Statistics)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
///NOT A DATATYPE BEING REGISTERED, BUT A UNION BETWEEN TWO DATATYPES AND ITS
///USE OF ADAPTER BEING ENCAPSULATED



    static struct class(FactoryTable)

        WeatherStation(Statistics)(Factory) =
    {
        &class(FactoryTable)(Type),

        &WeatherStation(Statistics)(Ctor),

        0   };


    static Interface WeatherStation(Statistics)(InterfaceHeap)[one] =

    { & WeatherStation(Statistics)(Factory), nullptr };


    static Interface typename(ClassFactoryMethod)(WeatherStation(Statistics), 0, 0);


    static void typename(Setup)(WeatherStation(Statistics)) {}

    static void typename(Abort)(WeatherStation(Statistics)) {}


#endif // STATISTICS_H_INCLUDED
