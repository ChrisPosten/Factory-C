#ifndef ESPRESSO_H_INCLUDED
#define ESPRESSO_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for Factory C (OOC)>*
 *                                                                   *
 * THIS SOFTWARE IS NOT COPYRIGHTED                                  *
 *                                                                   *
 * This source code is offered for use in the static domain.         *
 * You may use, modify or distribute it freely.                      *
 *                                                                   *
 * This code is distributed in the hope that it will be useful, but  *
 * WITHOUT ANY WARRANTY.  ALL WARRANTIES, EXPRESS OR IMPLIED ARE     *
 * HEREBY DISCLAIMED.  This includes but is not limited to           *
 * warranties of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.*
 *                                                                   *
 * <jb.bee250@gmail.com> <Christopher Posten>                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "defineBeverage.h"

    #define Espresso(Member)  Espresso##Member

    #define BeverageEspresso(Member)\
        BeverageEspresso##Member

  #if 0 //1 DEBUG
        struct Espresso ;

        typedef struct Espresso Espresso;


        typedef struct Espresso(VirtualTable)
        {   Beverage(VirtualTable) base;
        } Espresso(VirtualTable);


        struct Espresso
        {   Beverage base;
        };


        static Espresso * Espresso(Init)( Beverage *, ... );

        static void Espresso(Dtor)( Beverage * self )  {}

        static cstring Espresso(Type)();


        explicit cstring Espresso(Type)(){ return "Espresso"; }


        explicit double Espresso(Cost)( Espresso * self ){ return 1.99; }


        static Espresso * Beverage(Espresso)(Init)( Beverage *, ... );

        static void Beverage(Espresso)(Dtor)( Beverage * );


        static Espresso(VirtualTable)

            Espresso(Interface) =
        {
            {
                {
                    & Espresso(Type),

                    & Espresso(Init),

                    & Beverage(Dtor)
                },

                & Beverage(GetDescription),

                & Espresso(Cost)
            }
        };


        static Espresso(VirtualTable)

            Beverage(Espresso)(Interface) =
        {
            {
                {
                    & Espresso(Type),

                    & Beverage(Espresso)(Init),

                    & Beverage(Espresso)(Dtor)
                },

                & Beverage(GetDescription),

                & Espresso(Cost)
            }
        };

        /**
         * @brief normal constructor  (dont decorate)
         *
         * @param self
         *
         * @return ...
         */
        explicit Espresso * Espresso(Init)( Beverage * self, ... )
        {   self  = BeverageInit(  self  ) ;

            if( self == nullptr ){ return nullptr; }

            if( self->description )
            {
                delete(self->description);

                self->description = new(String)(this, 2, "Espresso");
            }
            if( self->description == nullptr ){ return nullptr; }

                /**...*/

            return self;
        }

        /**
         * @brief ***decorated*** constructor
         *
         * @param self
         *
         * @return instance of object, following the virtual pattern
         */
        explicit Espresso * Beverage(Espresso)(Init)( Beverage * self, ... )
        {   self  = Beverage(Init)(  self  ) ;

            if( self == nullptr ){ return nullptr; }//wont be

            if( self->description )
            {
                delete(self->description);
                                               //same as typeid but whatever
                self->description = new(String)(this, 2, "Espresso");
            }
            if(self->description==nullptr){return nullptr;}//wont be(old check)



                AdapterTable(Interface).insert( atable, self, self );
                /**PREFERENCE TO HAVE ***DECORATED*** COME
                       WITH LOOP TERMINATION CONDITION    **/


            return self;
        }


        explicit void Beverage(Espresso)(Dtor)( Beverage * self )
        {
            //if ( friend(self) == self ){ terminate }

        }
  #else
    typename(Beverage)(Espresso, 1.99);
  #endif // DEBUG

#endif // ESPRESSO_H_INCLUDED
