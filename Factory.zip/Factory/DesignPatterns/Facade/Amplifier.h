#ifndef AMPLIFIER_H_INCLUDED
#define AMPLIFIER_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "StreamingPlayer.h"

    struct Tuner;

    typedef struct Tuner Tuner;


    struct TunerVirtualTable;

    typedef struct TunerVirtualTable TunerVirtualTable;

    #define Amplifier(Member)  Amplifier##Member
    struct  Amplifier
    {   struct class base;

        String * description;

        Tuner * tuner;

        StreamingPlayer * player;
    };

    typedef struct Amplifier(VirtualTable)
    {   struct class(VirtualTable)base;

        void (*on)( Amplifier * );

        void (*off)( Amplifier * );

        void (*setStereoSound)( Amplifier * );

        void (*setSurroundSound)( Amplifier * );

        void (*setVolume)( Amplifier *, unsigned int );

        void (*setTuner)( Amplifier *, Tuner * );

        void (*setStreamingPlayer)( Amplifier *, StreamingPlayer * );

        cstring () (*toString)( Amplifier * );

    } Amplifier(VirtualTable);


    static Amplifier * AmplifierInit( Amplifier *, String *,
        Tuner *, StreamingPlayer * );

    static void AmplifierDtor( Amplifier * );

    static cstring AmplifierType();


    explicit cstring AmplifierType(){ return "Amplifier"; }


    static void AmplifierOn( Amplifier * );

    static void AmplifierOff( Amplifier * );

    static void AmplifierSetStereoSound( Amplifier * );

    static void AmplifierSetSurroundSound( Amplifier * );

    static void AmplifierSetVolume( Amplifier *, unsigned int );

    static void AmplifierSetTuner( Amplifier *, Tuner * );

    static void AmplifierSetStreamingPlayer( Amplifier *, StreamingPlayer * );

    static cstring AmplifierToString( Amplifier * );


    static Amplifier(VirtualTable)

        Amplifier(Interface) =

    {
        {
            &AmplifierType,

            &AmplifierInit,

            &AmplifierDtor
        },

        &AmplifierOn,

        &AmplifierOff,

        &AmplifierSetStereoSound,

        &AmplifierSetSurroundSound,

        &AmplifierSetVolume,

        &AmplifierSetTuner,

        &AmplifierSetStreamingPlayer,

        &AmplifierToString
    };


    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit Amplifier * AmplifierInit( Amplifier * self,

        String * description, Tuner * tuner, StreamingPlayer * player )
    {
        if(!self){ return 0; }

        self->description   =       description;

        self->tuner         =       tuner;

        self->player        =       player;

        return self;
    }

    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit void AmplifierDtor( Amplifier * self )
    {
        delete(self->description);
    }


    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit void AmplifierOn( Amplifier * self )
    {
        printf("%s is on\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit void AmplifierOff( Amplifier * self )
    {
        printf("%s is off\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit void AmplifierSetStereoSound( Amplifier * self )
    {
        printf("%s stereo mode on\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit void AmplifierSetSurroundSound( Amplifier * self )
    {
        printf("%s surround sound on (5 speakers, 1 subwoofer)\n",

               virtual( self->description, String )->toString(this));
    }

    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit void AmplifierSetVolume( Amplifier * self, unsigned int level )
    {
        printf("%s setting volume to %d\n",

               virtual( self->description, String )->toString(this), level);
    }


    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit void AmplifierSetStreamingPlayer( Amplifier * self,

        StreamingPlayer * player )
    {
        self->player = player;

        printf("%s setting streaming player to %s\n",

            virtual( self->description, String )->toString(this),

            virtual( self->player, StreamingPlayer )->toString(this) );
    }

    /**
     * @brief
     *
     * @param
     *
     * @return
     */
    explicit cstring AmplifierToString( Amplifier * self )
    {
        return virtual( self->description, String ) -> toString(this) ;
    }


#endif // AMPLIFIER_H_INCLUDED
