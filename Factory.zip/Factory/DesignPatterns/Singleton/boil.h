#ifdef CHOCOLATEBOILERSINGLETON
    #ifndef BOIL_H_INCLUDED
    #define BOIL_H_INCLUDED

    explicit bool      boil(void)

    { return ChocolateBoiler(Boil)(cboiler); }

    #endif // BOIL_H_INCLUDED
#endif // CHOCOLATEBOILERSINGLETON
