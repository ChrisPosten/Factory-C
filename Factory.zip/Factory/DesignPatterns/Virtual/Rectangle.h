#ifndef RECTANGLE_H_INCLUDED
#define RECTANGLE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /**
        THIS FILE WILL DEMONSTRATE THE PURPOSE OF A FACTORY

        FUNCTION FOR THE CONSTRUCTOR. A FACTORY CONSTRUCTOR.


        A FACTORY CONSTRUCTOR USES A SECOND PARAMETER THAT

        IS ALWAYS A CASE NUMBER, IF YOU HAVE A BETTER IDEA

        THEN BY ALL MEANS DO SO, WHAT IM SAYING IS THAT A

        FACTORY FUNCTION CAN HAVE MULTIPLE WAYS OF HANDLING

        ITS VARIABLE AMOUNT OF PARAMETERS. HERE WHAT ITS

        GOING TO BE IS A C FACTORY CONSTRUCTOR (IN FACTORY C)

        SO THATS WHERE THE SECOND PARAMETER (AFTER this) IS

        RESERVED FOR A CASE NUMBER, PRIMARILY A NUMERIC CONSTANT.

        CASE 0 CAN BE DEFAULT CONSTRUCTOR BUT NOT THE DEFAULT CASE

        TO THE SWITCH, THE DEFAULT SWITCH CASE IS SOMETHING TO

        TRY FOR BUT... ANYWAYS THE C VECTOR GETS RID OF ITS

        CASE NUMBER AT A CERTAIN POINT THAT MIGHT BE TOO CONFUSING

        RIGHT NOW FOR SOMEONE ELSE, THE SECOND PARAMETER IS FOR

        A SIZE VARIABLE AFTER CASE 0 AND CASE 1 COVER


        ...A TECHNICAL OVERLOAD USING !instance(obj) IS A SUBSTITUTE

        FOR CASE 0 AND 1 AS A PARAMETER.

     */
    #include "Shape.h"

    #define Rectangle(Member) Rectangle##Member

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct Rectangle ;

    typedef struct Rectangle Rectangle;


    typedef struct Rectangle(VirtualTable)
    {   Shape(VirtualTable)base;
    } Rectangle(VirtualTable);


    struct Rectangle
    {   Shape base;

        size_t l, w;

    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Rectangle * Rectangle(Init)(Rectangle *, .../*size_t, size_t*/);

    static void Rectangle(Dtor)(Rectangle *) ;

    static cstring Rectangle(Type)();


    explicit void Rectangle(Dtor)(Rectangle * self) {}/*(empty hook)*/

    explicit cstring Rectangle(Type)() { return "Rectangle"; }


    static size_t Rectangle(GetArea)(Rectangle *);


    static Rectangle(VirtualTable)

        Rectangle(Interface) =
    {
        {
            &Rectangle(Type),

            &Rectangle(Init),

            &Rectangle(Dtor)
        },
        &Rectangle(GetArea)
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                            //always give your initializer
    explicit Rectangle * Rectangle(Init)

        (Rectangle * self, .../*size_t l, size_t w*/)
    {                                     //an identifier (name) that matches the
        /*if(self == nullptr){ return nullptr; }(obsolete)*/
        stack(control)();
                                       //pattern:  [Class]Init, when [Class]
        self->l = stack(arg)(size_t); //is used with:  new([Class])(this, ...)
        self->w = stack(arg)(size_t);//as [Class] becomes a token thats
                                    //concatenated with more text to generate
        return self;               //the identifier:      [Class]Init
    }                             //                     RectangleInit

    explicit size_t Rectangle(GetArea)(Rectangle * self)
    {
        return self->l * self->w;
    }


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**          SMALL FACTORY TABLE CLASS INCLUDED             **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    static ctorPtr Rectangle(Ctor)();

    explicit ctorPtr Rectangle(Ctor)(){return new(Rectangle);}


    static struct class(FactoryTable)

        Rectangle(Factory) = //non-extended registration style interface
    {
        & class(FactoryTable)(Type),

        Rectangle(Ctor),

        0
    };


    #define defineRectangleOut(Type,Print,End)\
    \
      /*static int*/ Rectangle(Type##Out)(Rectangle *);\
    \
      explicit int Rectangle(Type##Out)(Rectangle * self)\
      {\
          Print "%u", virtual(self, Shape)->getArea(this) End ;\
      }

    static int typename(RectangleOut)(Console, _cPrint(), cEnd());

    static struct class(ConsoleTable)

        Rectangle(Console) =
    {
        & class(ConsoleTable)(Type),

        0,

        & Rectangle(ConsoleOut)
    };


    static Interface

        Rectangle(InterfaceHeap)[two] =

    {/*(by int_it:) abcdefghijklmnopqrstuvwxyz*/
        & Rectangle(Console),

        & Rectangle(Factory),

        nullptr
    };
    static Interface
    typename(ClassFactoryMethod)(Rectangle,0,1);//singleton method


    static void typename(Setup)(Rectangle){}

    static void typename(Abort)(Rectangle){}


                                                          //CWP
#endif // RECTANGLE_H_INCLUDED
