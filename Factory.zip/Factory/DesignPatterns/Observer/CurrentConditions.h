#ifndef CURRENTCONDITIONS_H_INCLUDED
#define CURRENTCONDITIONS_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #include "WeatherStation.h"

    #define CurrentConditions(Member)  CurrentConditions##Member

    #define WeatherStationCurrentConditions(Member)\
    \
        WeatherStationCurrentConditions##Member

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct CurrentConditions;

    typedef struct CurrentConditions CurrentConditions;


    typedef struct CurrentConditions(VirtualTable)
    {   Observer(VirtualTable) base;
    }CurrentConditions(VirtualTable);


    struct CurrentConditions
    {   Observer base;

        double       temperature,

                     humidity;
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static CurrentConditions * CurrentConditions(Init)( CurrentConditions * );

    static void CurrentConditions(Dtor)( CurrentConditions * );

    static cstring CurrentConditions(Type)();


    explicit void CurrentConditions(Dtor)( CurrentConditions * self ) {}

    explicit cstring CurrentConditions(Type)(){ return "CurrentConditions"; }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                ///just an extra setter for when not Observer ...
    static void CurrentConditions(Update)( CurrentConditions *, ... );


    static CurrentConditions * WeatherStation(CurrentConditions)(Init)

        ( CurrentConditions *, ... ) ;


    static void WeatherStation(CurrentConditions)(Dtor)( CurrentConditions * );

    explicit void WeatherStation(CurrentConditions)(Dtor)( CurrentConditions * self )

    { AdapterTable(Interface).remove( atable, self ); }


    static void WeatherStation(CurrentConditions)(Update)

        ( CurrentConditions *, ... ) ;

    static ctorPtr WeatherStation(CurrentConditions)(Ctor)();

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static CurrentConditions(VirtualTable)

        CurrentConditions(Interface) =
    {
        {
            {
                &CurrentConditions(Type),

                &CurrentConditions(Init),

                &CurrentConditions(Dtor)
            },

            &CurrentConditions(Update)
        }
    };
    static ctorPtr typename(Ctor)(CurrentConditions);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static CurrentConditions(VirtualTable) ///i have adjusted the Observer pattern
                                    ///so they may or may not be used as observers
        WeatherStation(CurrentConditions)(Interface) =///and incorporate ideas
    {                     ///from Adapter and use an instance of one of its tables
        {                ///(updated to use only a single atable for now)
            {
                &CurrentConditions(Type),

                &WeatherStation(CurrentConditions)(Init),

                &WeatherStation(CurrentConditions)(Dtor)
            },

            &WeatherStation(CurrentConditions)(Update) ///Observer update
        }
    };
    explicit ctorPtr WeatherStation(CurrentConditions)(Ctor)()
    { return adapter(WeatherStation,CurrentConditions); }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /**
     * TODO: write a factory constructor that uses a case number for a switch thats
     *       always the second parameter or argument (arg). so, case 0 would be
     *       a default constructor, case 1 needs to be a copy constructor for
     *       there to be a uniform way to access the copy constructor (ctor) for
     *       every object of every class. case 2 afterwards can be to take plain
     *       values or variables for initializing data members. no cleanup is
     *       needed after making a control() call and calls to arg(stack, type).
     */

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit CurrentConditions * CurrentConditions(Init)

        ( CurrentConditions * self )
    {
        if( self == nullptr ){ return nullptr; }

        self->temperature       =        0.0f;

        self->humidity          =        0.0f;

        return self;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit CurrentConditions * WeatherStation(CurrentConditions)(Init)

        ( CurrentConditions * self, ... )/** factory function (ctor) since (...) */
    {
        if( self == nullptr ){ return nullptr; }

        Stack * stack = control();


        WeatherStation * host = arg(stack, Object *);


        self->temperature       =        0.0f;

        self->humidity          =        0.0f;

            ///uses the atable singleton (AdapterTable)
        AdapterTable(Interface).insert( atable, self, host );

        WeatherStation(InsertObserver)(host, self);

        return self;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CurrentConditions(Update)

        ( CurrentConditions * self, ... )
    {
        Stack * stack = control();

        self->temperature   =   arg(stack, double);

        self->humidity      =   arg(stack, double);
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void WeatherStation(CurrentConditions)(Update)

        ( CurrentConditions * self, ... )
    {
        Stack * stack = control();


        if( Subject(Flag) == true )  //2) notified from Subject
        {printf("ON/");



            self->temperature = arg(stack, double);

            self->humidity =    arg(stack, double);




        }
        if( Subject(Flag) == false ) //1) raise a flag for the Subject to notify all
        {printf("OFF/");         //Subject(Flag) = true; (in set())


                            //this is like an on/off switch or an on/off function
                                   //this isn't part of the observer pattern but makes
            virtual( *AdapterTable(Interface).search( atable, self ), Subject )
                                    //it what i thought it would be when
                                                       //i heard of it
                ->assign( this, arg(stack, double),

                      arg(stack, double), arg(stack, double) );

            virtual( *AdapterTable(Interface).search( atable, self ), Subject )

                ->notify( this );//dynamic
                                                              //now display is closer to being
                                                             //for something else too

            //WeatherStationSet( (*self).base.self, temperature, humidity, pressure );//non-dynamic

            //WeatherStationNotify( (*self).base.self );//non-dynamic function call
        }
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit int CurrentConditions(Display)( CurrentConditions * self )
    {
        printf("\n\n      << CURRENT CONDITIONS DISPLAY >>\n\n");

        printf("temperature:\t\t\t\t%.3f F\n\n", self->temperature);

        printf("humidity:\t\t\t\t%.3f %% \n\n", self->humidity);

        return 0;
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    static Virtual  /**Table(Name, Pos, Default)**/

        CurrentConditions(VirtualHeap)[four] = /**CLASS VIRTUAL TABLE TABLE**/
    {/**A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P  Q  R  S  T  U  V  W  X  Y  Z**/
        { "dtor",             2,      &CurrentConditions(Dtor)             },
        { "init",             1,      &CurrentConditions(Init)             },
        { "type",             0,      &CurrentConditions(Type)             },
        { "update",           3,      &CurrentConditions(Update)           },

        { "", 0, 0 }
    };static Virtual *
    typename(SubFactoryMethod)(CurrentConditions,Virtual,Virtual,0,3);


    static struct class(VirtualHeap)
        CurrentConditions(Virtual) =

    { &class(VirtualHeap)(Type),
    &CurrentConditions(VirtualSearch),
    CurrentConditions(VirtualHeap) };


    static struct class(FactoryTable)

        CurrentConditions(Factory) =
    {
        &class(FactoryTable)(Type),
        &CurrentConditions(Ctor),0 };


    static struct class (AdapterTable)
        WeatherStation(CurrentConditions)(Adapter) =

    {&WeatherStation(AdapterTable)(Type),&WeatherStation(CurrentConditions)(Init),
     &WeatherStation(CurrentConditions)(Interface)};


    static struct class (ConsoleTable)
        CurrentConditions(Console) =

    {&class(ConsoleTable)(Type),0,
     &CurrentConditions(Display)};

   # define CurrentConditionsSecurity(Member)CurrentConditionsSecurity ## Member
    static cstring typename(PassNumber)(CurrentConditions, Security);

    extern struct pass(SecurityHeap)

        CurrentConditions(Security) ;


    static Interface CurrentConditions(InterfaceHeap)[six] =
    {
      &CurrentConditions(Security),

      &CurrentConditions(Interface),//capital H

      &WeatherStation(CurrentConditions)(Adapter),// capital W with WeatherStation

      &CurrentConditions(Console),

      &CurrentConditions(Factory),//lowercase c then F with class(FactoryTable)

      &CurrentConditions(Virtual),

      nullptr
    };

    ///class construction/template macro
    static Interface typename(ClassFactoryMethod)(CurrentConditions,0,5);


    struct pass(SecurityHeap)

        CurrentConditions(Security) =

    { { & CurrentConditions(Security)(ID), 0,

          CurrentConditions(InterfaceHeap) },

        & pass(SecurityHeap)(Type) } ;


    static void typename(Setup)(CurrentConditions)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


    static void typename(Abort)(CurrentConditions)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static struct class(FactoryTable)

        WeatherStation(CurrentConditions)(Factory) =
    {
        &class(FactoryTable)(Type),

        &WeatherStation(CurrentConditions)(Ctor),

        /*should include virtual + def at least*/

        0   };


    static Interface WeatherStation(CurrentConditions)(InterfaceHeap)[one] =

    { & WeatherStation(CurrentConditions)(Factory), nullptr };


    static Interface typename(ClassFactoryMethod)(WeatherStation(CurrentConditions), 0, 0);


    static void typename(Setup)(WeatherStation(CurrentConditions)) {}

    static void typename(Abort)(WeatherStation(CurrentConditions)) {}


#endif // CURRENTCONDITIONS_H_INCLUDED
