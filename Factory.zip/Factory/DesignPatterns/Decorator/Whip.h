#ifndef WHIP_H_INCLUDED
#define WHIP_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "defineCondimentDecorator.h" // Decorator pattern

    /*
        encapsulate what varies...

        now all the concrete decorator classes can be easily
        maintained by one implementation stored inside:

        defineCoffeeDecorator.h       (encapsulated concrete design pattern (concrete) class)


        define(param)    (define)  param ...

        define(CoffeeDecorator)(...);


        define  (   (define)    CoffeeDecorator   )
                             defineCoffeeDecorator  ( ... )


        if that doesn't help anything make sense (line 15-20) then forget it.


        Mocha, Milk, Soy, Whip are parallel implementations so macro encapsulation

        is desirable...
    */

    #define Whip(Member)  Whip##Member

    #define BeverageWhip(Member) BeverageWhip##Member
    typename(CondimentDecorator)(Whip, .12); ///look at everything that varies there.

            /// also the class name is converted into a cstring with: ( # param )
            /// like the class name is concatenated onto global declarations with: ( param ## token )

                                                        //CWP
#endif // WHIP_H_INCLUDED
