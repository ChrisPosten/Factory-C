#ifndef DEFINECONDIMENTDECORATOR_H_INCLUDED
#define DEFINECONDIMENTDECORATOR_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for Factory C (OOC)>*
 *                                                                   *
 * THIS SOFTWARE IS NOT COPYRIGHTED                                  *
 *                                                                   *
 * This source code is offered for use in the static domain.         *
 * You may use, modify or distribute it freely.                      *
 *                                                                   *
 * This code is distributed in the hope that it will be useful, but  *
 * WITHOUT ANY WARRANTY.  ALL WARRANTIES, EXPRESS OR IMPLIED ARE     *
 * HEREBY DISCLAIMED.  This includes but is not limited to           *
 * warranties of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.*
 *                                                                   *
 * <jb.bee250@gmail.com> <Christopher Posten>                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "CondimentDecorator.h" // Decorator pattern

    /**
     * @brief Concrete Decorator Pattern Encapsulation Macro (X-MACRO)
     *
     *                   - - X - Level Macro - X - -
     *
     * @author willy      (12/23/2021)   (01/26/2022)
     *///typename(CondimentDecorator)(Name, cent);                                 //.10
    #define defineCondimentDecorator(Name, Cent)\
    \
        struct Name ;\
    \
        typedef struct Name Name;\
    \
    \
        typedef struct Name(VirtualTable)\
        {   CondimentDecorator(VirtualTable)base;\
        } Name(VirtualTable);\
    \
    \
        struct Name\
        {   CondimentDecorator base;\
        };\
    \
    \
        static Name * Name(Init)( Name *, String * );\
    \
        static void Name(Dtor)( Name * )  ;\
    \
        static cstring Name(Type)();\
    \
        static ctorPtr Name(Ctor)();\
    \
    \
        static void Beverage(Name)(Setup)(void);\
    \
        static void Beverage(Name)(Abort)(void);\
    \
    \
        explicit cstring Name(Type)(){ return #Name; }\
    \
    \
        static String * Name(GetDescription)( Name * );\
    \
        static double Name(Cost)( Name * );\
    \
    \
    \
        static Name * Beverage(Name)(Init)( Name *, Beverage * );\
    \
        static void Beverage(Name)(Dtor)( Name * );\
    \
        static ctorPtr Beverage(Name)(Ctor)();\
    \
    \
        static String * Beverage(Name)(GetDescription)( Name * );\
    \
        static double Beverage(Name)(Cost)( Name * );\
    \
    \
        static Interface Name(Heap)( cstring );    \
    \
        static Interface Beverage(Name)(Search)( cstring );\
    \
    \
        static Name(VirtualTable) \
    \
            Name(Interface) =\
        {\
            {\
                {\
                    {\
                        & Name(Type),\
    \
                        & Name(Init),\
    \
                        & BeverageDtor\
                    },\
    \
                    & Name(GetDescription),\
    \
                    & Name(Cost)\
                }\
            }\
        };\
        explicit ctorPtr Name(Ctor)(){ return new( Name ); }\
    \
    \
        static Name(VirtualTable) \
    \
            Beverage(Name)(Interface) =\
        {\
            {\
                {\
                    {\
                        & Name(Type),/**LOOK IN Adapter TABLE FOR BOTH typeid(obj)*/\
    \
                        & Beverage(Name)(Init),\
    \
                        & Beverage(Name)(Dtor)\
                    },\
    \
                    & Beverage(Name)(GetDescription),\
    \
                    & Beverage(Name)(Cost)\
                }\
            }\
        };\
        explicit ctorPtr Beverage(Name)(Ctor)(){return adapter(Beverage,Name);}\
    \
    \
        /**
         * @brief basic initializer
         *
         * @param self, description
         *
         * @return instance from new(Name)
         */\
        explicit Name * Name(Init)( Name * self, String * description )\
        {   self = Beverage(Init)( self );\
    \
            if( self == nullptr ){ return nullptr; }\
    \
    \
            ((Beverage*)self)->description = description;\
    \
    \
            return self;\
        }\
    \
        /**
         * @brief non-Adapter get description
         *
         *        case 1 for String copy constructor
         *        case 2 for copy from cstring or ""
         *
         * @param self
         *
         * @return new(String)(this,...)
         */\
        explicit String * Name(GetDescription)( Name * self )\
        {\
            return new (String)( this, 1, ((Beverage*)self)->description );\
        }\
    \
        /**
         * @brief return cost
         *
         * @param self
         *
         * @return the amount of cents is a parameter for the macro
         */\
        explicit double Name(Cost)( Name * self )/**DEFAULT PARAMETER (NOT USED)**/\
        {\
            return Cent;/**  **/\
        }\
        /**TODO: MAYBE DECLARE A DATAMEMBER FOR Cent**/\
        /**
         * @brief decorator initializer
         *
         * @param self, host (for self pointer data member)
         *
         * @return instance from decorator(Beverage, Name)
         */\
        explicit Name * Beverage(Name)(Init)( Name * self, Beverage * host )\
        {   self = Beverage(Init)( self );\
    \
            if( self == nullptr ){ return nullptr; }\
    \
    \
            ((Beverage*)self)->description = host->description;\
    \
    \
            AdapterTable(Interface).insert( atable, self, host ); \
    \
    \
            return self;\
        }\
    \
    \
        explicit void Beverage(Name)(Dtor)( Name * self )\
        { /*printf("%s destructor\n", typeid(self));\
            delete(((Beverage*)self)->description);\
    \
            AdapterTable(Interface).remove( atable, self );*/ \
    \
    \
        }\
    \
        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * @brief wrap around the getDescription and concatenate it             *
         *                                                                      *
         * @param self                                                          *
         *                                                                      *
         * @return new(String)(this,...)                                        *
         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/\
        explicit String * Beverage(Name)(GetDescription)( Name * self )\
        {\
            String * temp = virtual( friend( self ), Beverage )\
    \
                    ->getDescription(this);\
    \
            /*printBeverageDescription(temp);*/\
    \
            String * str1 = new(String)( this, 1, temp );\
    \
            /*printBeverageDescription(temp);*/\
    \
            String * str2 = new(String)(this, 2, ", " #Name);\
    \
            /*printBeverageDescription(temp);*/\
    \
            delete(temp);\
    \
            if( !StringConcat( str1, str2 ) )\
            { \
                delete(str1);\
    \
                delete(str2);\
    \
                return nullptr; \
            }\
            else \
            {  \
                delete(str2); \
    \
                return str1; \
            }\
        }\
    \
        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * @brief return self cost + cost                                       *
         *                                                                      *
         * @param self                                                          *
         *                                                                      *
         * @return the amount of cents is a parameter for the macro             *
         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/\
        explicit double Beverage(Name)(Cost)( Name * self )\
        {\
            return  virtual( friend( self ) ,\
    \
                Beverage)->cost(this) + Cent;\
        }\
    \
    /** */\
        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * FACTORY TABLE CLASS COMPONENTS ENOUGH FOR A FULLY DYNAMIC INSTANCE   *
         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/\
    \
        static struct class(FactoryTable)\
    \
            Name(Factory) =\
    \
        { &class(FactoryTable)(Type), &Name(Ctor), 0 };\
    \
    \
        static Interface Name(InterfaceHeap)[one] = \
    \
        { &Name(Factory), nullptr };\
    \
    \
        explicit Interface typename(ClassFactoryMethod)(Name, 0, 0);\
    \
    \
        explicit void Name(Setup)(void) {}\
    \
        explicit void Name(Abort)(void) {}\
    \
        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * FACTORY TABLE CLASS COMPONENTS ENOUGH FOR A FULLY DYNAMIC INSTANCE   *
         *                                                                      *
         * USING: factory("Class(Adapter)")(this, ...);                         *
         *                                                                      *
         * JUST:  register(Class(Adapter)) ;                                    *
         *                                                                      *
         *        INSIDE THE PROGRAM CONSTRUCTOR FOR THE FACTORY TABLE.         *
         *                                                                      *
         *                              CHEERS                                  *
         *                                                                      *
         * @return Object * object = factory("Beverage(Soy)")(this, ...)        *
         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/\
    \
        static struct class(FactoryTable)\
    \
            Beverage(Name)(Factory) =\
    \
        { &class(FactoryTable)(Type), &Name(Ctor), 0 };\
    \
    \
        static Interface Beverage(Name)(InterfaceHeap)[one] =\
    \
        { &Beverage(Name)(Factory), nullptr };\
    \
    \
        explicit Interface typename(ClassFactoryMethod)(Beverage(Name), 0, 0);\
    \
    \
        explicit void Beverage(Name)(Setup)(void) {}\
    \
        explicit void Beverage(Name)(Abort)(void) {}


/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * <library that defines void-Oriented essentials in C (Factory C)>  *
 *                                                                   *
 * Copyright (C) <2017 - 2022>  <Christopher Posten>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
#endif // DEFINECONDIMENTDECORATOR_H_INCLUDED
