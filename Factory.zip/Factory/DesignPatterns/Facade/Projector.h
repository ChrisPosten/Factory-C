#ifndef PROJECTOR_H_INCLUDED
#define PROJECTOR_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "StreamingPlayer.h"

    #define Projector(Member)  Projector##Member

    typedef struct Projector
    {   struct class base;

        String * description;

    }Projector;


    typedef struct Projector(VirtualTable)
    {   struct class(VirtualTable) base;

        void (*on) ( Projector * );

        void (*off)( Projector * );

        void (*wideScreenMode)( Projector * );

        void (*tvMode)( Projector * );

        cstring () (*toString)( Projector * );

    }Projector(VirtualTable);


    static Projector * ProjectorInit( Projector *, String *, ... );

    static void ProjectorDtor( Projector * );

    static cstring ProjectorType();


    explicit cstring ProjectorType(){ return "Projector"; }


    static void ProjectorOn ( Projector * );

    static void ProjectorOff( Projector * );

    static void ProjectorWideScreenMode( Projector * );

    static void ProjectorTvMode( Projector * );

    static cstring ProjectorToString( Projector * );


    static Projector(VirtualTable)

        Projector(Interface) =

    {
        {
            &ProjectorType,

            &ProjectorInit,

            &ProjectorDtor
        },

        &ProjectorOn,

        &ProjectorOff,

        &ProjectorWideScreenMode,

        &ProjectorTvMode,

        &ProjectorToString
    };


    /**
     * @brief   initializer
     *
     * @param   self, desc
     *
     * @return  *
     */
    explicit Projector * ProjectorInit( Projector * self,

        String * description, ... )
    {
        if( !self ){ return 0; }

        self->description = description;

        return self;
    }

    /**
     * @brief   destructor
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ProjectorDtor( Projector * self )
    {
        delete(self->description);
    }


    /**
     * @brief   on
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ProjectorOn ( Projector * self )
    {
        printf("%s is on\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief   off
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ProjectorOff( Projector * self )
    {
        printf("%s is off\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief   wideScreenMode
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ProjectorWideScreenMode( Projector * self )
    {
        printf("%s in widescreen mode (16x9 aspect ratio)\n",

            virtual( self->description, String )->toString(this));
    }

    /**
     * @brief   TvMode
     *
     * @param   self
     *
     * @return  void
     */
    explicit void ProjectorTvMode( Projector * self )
    {
        printf("%s in tv mode (4x3 aspect ratio)\n",

            virtual( self->description, String )->toString(this));
    }

    /**
     * @brief   toString(this)
     *
     * @param   self
     *
     * @return  cstring
     */
    explicit cstring ProjectorToString( Projector * self )
    {
        return virtual( self->description, String )->toString(this) ;
    }


#endif // PROJECTOR_H_INCLUDED
