#ifndef TURKEY_H_INCLUDED
#define TURKEY_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    struct Turkey;

    typedef struct Turkey Turkey;

    #define Turkey(Member)  Turkey##Member

    typedef struct Turkey(VirtualTable)
    {   struct class (VirtualTable) base;

        void (*fly)(Turkey *);

        void (*gobble)(Turkey *);

        void (*swim)(Turkey *);

    } Turkey(VirtualTable);


    struct Turkey
    {   struct class base;

        size_t weight;
    };


    static Turkey * Turkey(Init)(Turkey *, .../*size_t*/);

    static void Turkey(Dtor)(Turkey *);

    static cstring Turkey(Type)();


    static ctorPtr Turkey(Ctor)();


    explicit cstring Turkey(Type)(){ return "Turkey"; }


    static void Turkey(Fly)(Turkey *);

    static void Turkey(Gobble)(Turkey *);

    static void Turkey(Swim)(Turkey *);


    static Turkey(VirtualTable)

        Turkey(Interface) =
    {
        {
            &Turkey(Type),

            &Turkey(Init),

            &Turkey(Dtor)
        },

        &Turkey(Fly),

        &Turkey(Gobble),

        &Turkey(Swim)    };

    explicit ctorPtr Turkey(Ctor)(){return new(Turkey);}






    explicit Turkey * Turkey(Init)

        (Turkey * self, .../*size_t weight*/)

    { stack(control)();

        self->weight = stack(arg)(size_t);

      return self;}




    explicit void Turkey(Dtor)(Turkey * self)
    {
        printf("<< TURKEY DESTRUCTOR >>");
    }

    explicit void Turkey(Fly)(Turkey * self)
    {
        printf("<< TURKEY FLYING SHORT DISTANCE >>");
    }

    explicit void Turkey(Gobble)(Turkey * self)
    {

        printf("<< TURKEY GOBBLING >>");
    }

    explicit void Turkey(Swim)(Turkey * self)
    {
        printf("<< TURKEY SWIMMING >>");
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* note: these are overloads similar to the ones found in

             FactoryObject.h (factory function overloads included)

             the ones there include cases for multiple parameters

             that can be overloaded using a class(StrategyHeap)

             in conjunction with a class(VirtualHeap) (these aren't).

       also: these are execute style methods (all of them) and

             so they are strategically interchangeable by override.

             (i know we are looking at overload functions but

             im thinking of the method calls encapsulated inside

             these functions) (function vs method).
     */
    static void fly(Object *);

    static void gobble(Object *);

    static void swim(Object *);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Virtual
        Turkey(VirtualHeap)[six] = //(0-5)

    {/*a b c d e f g h i j k l m n o p q r s t u v w x y z*/
     {"dtor",2,&Turkey(Dtor)},
     {"fly",3,&Turkey(Fly)},
     {"gobble",4,&Turkey(Gobble)},
     {"init",1,&Turkey(Init)},
     {"swim",5,&Turkey(Swim)},
     {"type",0,&Turkey(Type)},{"",0,0}
    };
    static Virtual *
    typename(SubFactoryMethod)(Turkey,Virtual,Virtual,0,5);
            //Turkey(SearchVirtual)

    static struct class(VirtualHeap)
        Turkey(Virtual) =

    {&class(VirtualHeap)(Type),
     &Turkey(VirtualSearch), Turkey(VirtualHeap) };

    /**
     * @brief  fly
     *
     * @param  self
     */
    explicit void fly(Object * self)
    {
        ((void(*)(Object*))*function(self, "fly"))(this);
    }

    /**
     * @brief  gobble
     *
     * @param  self
     */
    explicit void gobble(Object * self)
    {
        ((void(*)(Object*))*function(self, "gobble"))(this);
    }

    /**
     * @brief  swim
     *
     * @param  self
     */
    explicit void swim(Object * self)
    {
        ((void(*)(Object*))*function(self, "swim"))(this);
    }

    static struct class(FactoryTable)
        Turkey(Factory) =

    { &class(FactoryTable)(Type),
      &Turkey(Ctor), 0 };


    static Adapter
        Turkey(AdapterHeap)[one] =

    { {"Duck","Turkey(Duck)"},{"",""} };//type_info heap
                //(adaptee responsibility)
    static Adapter *
    typename(SubFactoryMethod)(Turkey,Adapter,Adapter,0,0);


    static struct class(AdapterHeap)
        Turkey(Adapter) =

    {&class(AdapterHeap)(Type),
     &Turkey(AdapterSearch),
      Turkey(AdapterHeap)};


    static Interface
        Turkey(InterfaceHeap)[three] = //(0-2)

    {
        &Turkey(Adapter),

        &Turkey(Factory),

        &Turkey(Virtual),

        nullptr
    };
    static Interface
    typename(ClassFactoryMethod)(Turkey,0,2);//(0-2)


    static void typename(Setup)(Turkey){}

    static void typename(Abort)(Turkey){}


#endif // TURKEY_H_INCLUDED
