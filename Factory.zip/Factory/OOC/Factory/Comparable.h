#ifdef FACTORYTABLESINGLETON
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<library that defines Object-Oriented essentials in C (Factory C)> *
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #ifndef COMPARABLE_H_INCLUDED
    #define COMPARABLE_H_INCLUDED
/*
        1) register a Class:  register(Class)


        2) this is the game plan: the fTable checks to

           see if a Class is registered by "ClassName"

           and if it is, it iterates (p++) the automatic

           ClassTables[n] array where n is the amount of

           "Interface" registrations in a null terminated

           array of pointers to those interfaces. The first

           data field position of each "interface"

           registration is reserved for the type() function

           that returns its "interface" type as a cstring.

           the fTable is going to find the registration

           called "classCompareTable" and use it for the impl

           of these two global functions that, will work for

           every object of every class that is found in the

           fTable


        X) that is what they meant in ooc to have an Object that

           is... registered? they register their Objects too there

           don't they?


        X) from here on we just have objects (Object *), and

           its not up to inheritance anymore, but its up to

           using a registered Class and its "interface"

           registrations, accessed through a null terminated

           global-static-automatic variable array (non-dynamic)

           (non-pointer type) A.K.A. static class tables


        X) again, so from here on we use equal to compare two

           objects, throw exceptions from the registered interfaces

           when we need, we have Java grade exception classes

           and an x-macro that encapsulates their implementations


            THE REGISTRATION CAN GIVE ITS DESCRIPTION FOR SOMETHING

            ELSE MAYBE BUT ONLY NEEDS TO GIVE ITS DESCRIPTION

            AS ITS BASE TYPE EVER AND THE SPECIFIC REGISTRATION

            NEEDED FOR THESE FUNCTIONS WONT NEED TO BE EXTENDED

            EVEN THO THERE IS THE POSSIBILITY THATS THERE.
         */

        /**
            THIS IS EQUAL AND GREATER FOR COMPARING TWO

            OBJECTS, IT WILL CHECK IF BOTH OBJECTS ARE

            REGISTERED WITH THE SAME DESCRIPTION AND

            WILL RETURN TRUE IF THEY ARE. THIS IS A FUNCTION

            YOU PASS A FACTORY OBJECT INTO. A FACTORY

            OBJECT IS A VIRTUAL TABLE OBJECT AND AN OBJECT

            OF A FACTORY TABLE CLASS. THE typeid OF THE

            OBJECT IN THE VIRTUAL TABLE IS THE KEY TO THE

            SLOT IN THE FACTORY TABLE FOR THAT CLASS. FROM

            THERE THERE IS A CLASS FACTORY METHOD THAT CAN

            BE USED TO LOOK FOR THE FACTORY REGISTRATION

            THAT SHOULD GIVE ITS DESCRIPTION ALWAYS AS

            "class(CompareTable)" FROM THE SAME REGISTRATION

            LIST FOR THAT CLASS NAME'S STRING SUBMISSION.



        NOT ONLY DO THESE IMPLEMENTATIONS NEED "class(CompareTable)"

        BUT THEY NEED "class(PolymorphHeap)" AS THE INHERITANCE

        TABLE, SO CHECK IF A FACTORY TABLE CLASS HAS BOTH AND

        USE THEM, IF NOT THEN COMPARE THEM JUST AS THE SAME

        CLASS, THEN COMPARE WITH "class(CompareTable)", IF NOT

        FOUND, THEN RETURN FALSE. IF FULL CHECK INCLUDES EMPTY

        IMPLEMENTATIONS THAT ARE CALLED, THEN FULL CHECK COMPLETE

        AND RETURN TRUE IF THEY ARE. (EQUAL OR GREATER)


        WHEN COMPARING TWO DATATYPES WHERE THEY BOTH HAVE A

        MATCHING CLASS TYPE IN THEIR INTERFACE HEAPS IT MIGHT

        BE A DESIREABLE FAILSAFE TO IMPLEMENT A COMPLEX HEAP

        TO USE THE COMPLEX METHOD TO ACCESS DATAMEMBERS.
         */

            ;//(chicken scratch)

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *       1) call is_polymorphic(a,b) to fill the typeid stack.*
     *                                                           *
     *       2) call equal(a,b) or others inside a while().      *
     *                                                           *
     *       3) call tPop() inside a while().                    *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    # define polymorphic tTop ()

    static size_t is_polymorphic( const Object *, const Object * );

    volatile static size_t num_polymorphs = 0;// + tstk

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief        equal(a, b)   &&   greater(a, b)            *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #define definecompare(num)\
    {\
        if( polymorphic )\
        {   return ((compPtr*)multimap(false)\
            (*polymorphic)("class(CompareTable)"))[ num ](a,b);\
        }\
        else\
        {   if(string(equal)(typeid(a),typeid(b)))\
            {   return ((compPtr*)multimap(false)\
                (typeid(a))("class(CompareTable)"))[ num ](a,b);\
            }\
            else\
            {   throw(new(IllegalOperation))\
                (this, "TypeIDNotMatching\n"\
                 "call:/t/t is_polymorphic(a,b)");\
            }\
        }\
    }

    explicit bool  equal( const Object * a, const Object * b )
  #if 1 // 0 DEBUG
    typename(compare)(1);
  #else
    {
        if (polymorphic)
        {   return ((compPtr*)multimap(false)
            (*polymorphic)("class(CompareTable)"))[1](a,b);
        }
        else
        {   if(string(equal)(typeid(a),typeid(b)))
            {   return ((compPtr*)multimap(false)
                (typeid(a))("class(CompareTable)"))[1](a,b);
            }
            else
            {   throw(new(IllegalOperation))
                (this, "TypeIDNotMatching\n"
                 "call:/t/t is_polymorphic(a,b)");
            }
        }
    }
  #endif // 1 DEBUG 0
    explicit bool  greater( const Object * a, const Object * b )

    typename(compare)(2);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                   less(a,b)                        *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /* note: less implements itself (so not part of class(CompareTable))
     */
    explicit bool  less( const Object * a, const Object * b )
    {
        return !equal(a, b) && !greater(a, b);
    }

    static bool () (*const compare)( const Object *, const Object * )
        = & equal;/*multi def error without static*/

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief              is_polymorphic(a, b)                  *
     *                                                           *
     * - - this polymorphic function implementation will be the  *
     * one i am keeping, since it uses a stack (tstk) TypeIDStack*
     *                                                           *
     * - -to be used in a loop involving tTop(), tPop() to compare
     * two objects in each way they are comparable together - -  *
     *                                                           *
     * - - a proper Object-Oriented Iterator would make this     *
     * function like 1/4 size, but an Iterator would help here,  *
     * the Vector Iterator would work, just an extended Heap     *
     * Iterator is needed and would do nicely - -                *
     *                                                           *
     * @return amount of polymorphs                              *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit size_t is_polymorphic( const Object * a, const Object * b )
    {
        if( tTop() ){throw(new(IllegalOperation))
                    (this, "ResolveTypeIDStackFirst");}
    if( num_polymorphs > 0 ){ num_polymorphs = 0; }

        if( string(equal)(typeid(a), typeid(b)) )
        {
            if( !tPush(typeid(a)) ){throw(new(OutOfMemory))
            (this, "TypeIDStackFailure");} }

    /*** * * * * * * * * * * * * *1* * * * * * * * * * * * * * ***/
        multimap(-1)(typeid(b));
        multimap(-1)(typeid(a));
        if( !map("builder(PolymorphHeap)") && !map("builder(PolymorphHeap)") )
        {  /// (for factory object A.K.A. struct class both a and b)

            Polymorph * iterator_a = ((tblePtr*)multimap(false)
                (typeid(a))("class(PolymorphHeap)"))[2] ,

                      * iterator_b = ((tblePtr*)multimap(false)
                (typeid(b))("class(PolymorphHeap)"))[2] ,

                      * p_a = iterator_a, * p_b = iterator_b;

            /* note: check every possibility with obj b typeid
             */
            while( !string(equal)(p_a->key, "") )
            {if( string(equal)(p_a->key, typeid(b)) ){
             num_polymorphs++;
             if( !tPush(p_a->key) ){throw(new(OutOfMemory))
                (this, "TypeIDStackFailure");}}p_a++;}

            /* note: check every possibility with obj a typeid
             */
            while( !string(equal)(p_b->key, "") )
            {if( string(equal)(p_b->key, typeid(a)) ){
             num_polymorphs++;
             if( !tPush(p_b->key) ){throw(new(OutOfMemory))
                (this, "TypeIDStackFailure");}}p_b++;}

            /* note: check every possibility in the arrays
             */
            p_b = iterator_b;
            while( !string(equal)(iterator_a->key, "") )
            {iterator_b = p_b;
             while( !string(equal)(iterator_b->key, "") )
             {if( string(equal)(iterator_a->key, iterator_b->key) )
              {num_polymorphs++;

                if( !tPush(iterator_a->key) )
                {throw(new(OutOfMemory))
                (this, "TypeIDStackFailure");}}
                    iterator_b++;
                }iterator_a++;}
        }
    /*** * * * * * * * * * * * * *2* * * * * * * * * * * * * * ***/
        multimap(-1)(typeid(b));
        multimap(-1)(typeid(a));
        if( map("builder(PolymorphHeap)") && map("builder(PolymorphHeap)") )
        ///else  ///(for complex object A.K.A. class builder class a and b)
        {
            pHeapNode(Polymorph) p_a, p_b;

            Heap(Polymorph) * heap_a = ((tblePtr*)multimap(false)
                (typeid(a))("builder(PolymorphHeap)"))[2] ,

                      * heap_b = ((tblePtr*)multimap(false)
                (typeid(b))("builder(PolymorphHeap)"))[2] ;


            Stk(pHeapNode(Polymorph)) stk_a;
            Stk(pHeapNode(Polymorph))(Init)(& stk_a);
            HeapNode(Polymorph)(InOrder)( heap_a->top, & stk_a );

            Stk(pHeapNode(Polymorph)) stk_b;
            Stk(pHeapNode(Polymorph))(Init)(& stk_b);
            HeapNode(Polymorph)(InOrder)( heap_b->top, & stk_b );


            /* note: check every possibility with obj b typeid
             */
            while( Stk(pHeapNode(Polymorph))(Top)(& stk_a) )
            {p_a = Stk(pHeapNode(Polymorph))(Pop)(& stk_a);
                if( string(equal)(p_a->info.key, typeid(b)) )
                {num_polymorphs++;
                    if( !tPush(p_a->info.key) )
                        {throw(new(OutOfMemory))
                    (this, "TypeIDStackFailure");}}}

            /* note: check every possibility with obj a typeid
             */
            while( Stk(pHeapNode(Polymorph))(Top)(& stk_b) )
            {p_b = Stk(pHeapNode(Polymorph))(Pop)(& stk_b);
                if( string(equal)(p_b->info.key, typeid(a)) )
                {num_polymorphs++;
                    if( !tPush(p_b->info.key) )
                        {throw(new(OutOfMemory))
                    (this, "TypeIDStackFailure");}}}

            HeapNode(Polymorph)(InOrder)( heap_a->top, & stk_a );

            /* note: check every possibility in the heap containers
             */
            while( Stk(pHeapNode(Polymorph))(Top)(& stk_a) )
            {p_a = Stk(pHeapNode(Polymorph))(Pop)(& stk_a);
                HeapNode(Polymorph)(InOrder)( heap_b->top, & stk_b );
                while( Stk(pHeapNode(Polymorph))(Top)(& stk_b) )
                {p_b = Stk(pHeapNode(Polymorph))(Pop)(& stk_b);
                    if( string(equal)(p_a->info.key, p_b->info.key ) )
                    {num_polymorphs++;
                        if( !tPush(p_a->info.key) )
                            {throw(new(OutOfMemory))
                        (this, "TypeIDStackFailure");}}}}
        }
    /*** * * * * * * * * * * * * *3* * * * * * * * * * * * * * ***/
        multimap(-1)(typeid(b));
        multimap(-1)(typeid(a));
        if( !map("builder(PolymorphHeap)") && map("builder(PolymorphHeap)") )
        {  /// (for factory object A.K.A. struct class a)
            ///(for complex object A.K.A. builder class b)
            Polymorph * iterator_a = ((tblePtr*)multimap(false)
                (typeid(a))("class(PolymorphHeap)"))[2] ,

                * p_a = iterator_a;


            Heap(Polymorph) * heap_b = ((tblePtr*)multimap(false)
                (typeid(b))("builder(PolymorphHeap)"))[2] ;

            pHeapNode(Polymorph) p_b;

            Stk(pHeapNode(Polymorph)) stk_b;
            Stk(pHeapNode(Polymorph))(Init)(& stk_b);
            HeapNode(Polymorph)(InOrder)( heap_b->top, & stk_b );

            /* note: check every possibility with obj b typeid
             */
            while( !string(equal)(p_a->key, "") )
            {if( string(equal)(p_a->key, typeid(b)) )
             {num_polymorphs++;
              if( !tPush(p_a->key) ){throw(new(OutOfMemory))
                (this, "TypeIDStackFailure");}}p_a++;}

            /* note: check every possibility with obj a typeid
             */
            while( Stk(pHeapNode(Polymorph))(Top)(& stk_b) )
            {p_b = Stk(pHeapNode(Polymorph))(Pop)(& stk_b);
                if( string(equal)(p_b->info.key, typeid(a)) )
                {num_polymorphs++;
                    if( !tPush(p_b->info.key) )
                        {throw(new(OutOfMemory))
                    (this, "TypeIDStackFailure");}}}

            /* note: check every possibility in the array + heap container
             */
            while( !string(equal)(iterator_a->key, "") )
            {HeapNode(Polymorph)(InOrder)( heap_b->top, & stk_b );
                while( Stk(pHeapNode(Polymorph))(Top)(& stk_b) )
                {p_b = Stk(pHeapNode(Polymorph))(Pop)(& stk_b);
                    if( string(equal)(p_a->key, p_b->info.key ) )
                    {num_polymorphs++;
                        if( !tPush(p_a->key) )
                            {throw(new(OutOfMemory))
                        (this, "TypeIDStackFailure");}}}iterator_a++;}

        }
    /*** * * * * * * * * * * * * *4* * * * * * * * * * * * * * ***/
        multimap(-1)(typeid(b));
        multimap(-1)(typeid(a));
        if( map("builder(PolymorphHeap)") && !map("builder(PolymorphHeap)") )
        ///else  ///(for complex object A.K.A. builder class a)
        {///        (for factory object A.K.A. struct class b)
            pHeapNode(Polymorph) p_a;

            Heap(Polymorph) * heap_a = ((tblePtr*)multimap(false)
                (typeid(a))("builder(PolymorphHeap)"))[2] ;

            Stk(pHeapNode(Polymorph)) stk_a;
            Stk(pHeapNode(Polymorph))(Init)(& stk_a);
            HeapNode(Polymorph)(InOrder)( heap_a->top, & stk_a );

            Polymorph * iterator_b = ((tblePtr*)multimap(false)
                (typeid(a))("class(PolymorphHeap)"))[2] ,

                      * p_b = iterator_b;

            /* note: check every possibility with obj b typeid
             */
            while( Stk(pHeapNode(Polymorph))(Top)(& stk_a) )
            {p_a = Stk(pHeapNode(Polymorph))(Pop)(& stk_a);
                if( string(equal)(p_a->info.key, typeid(b)) )
                {num_polymorphs++;
                    if( !tPush(p_a->info.key) )
                        {throw(new(OutOfMemory))
                    (this, "TypeIDStackFailure");}}}

            /* note: check every possibility with obj a typeid
             */
            while( !string(equal)(p_b->key, "") )
            {if( string(equal)(p_b->key, typeid(a)) )
             {num_polymorphs++;
                if( !tPush(p_b->key) ){throw(new(OutOfMemory))
                (this, "TypeIDStackFailure");}}p_b++;}

            p_b = iterator_b;
            HeapNode(Polymorph)(InOrder)( heap_a->top, & stk_a );

            /* note: check every possibility in the heap container + the array
             */
            while( Stk(pHeapNode(Polymorph))(Top)(& stk_a) )
            {p_a = Stk(pHeapNode(Polymorph))(Pop)(& stk_a);
                iterator_b = p_b;
                while( !string(equal)(iterator_b->key, "") )
                {if( string(equal)(p_a->info.key, iterator_b->key) )
                 {num_polymorphs++;
                    if( !tPush(p_a->info.key) )
                        {throw(new(OutOfMemory))
                        (this, "TypeIDStackFailure");}}iterator_b++;}}
        }

        if(num_polymorphs > 0){return num_polymorphs;}else{return 0;}
    }
    /* note: this could be further implemented to use a list of polymorph
             types and/or an IsPolymorphic object that uses the num var
     */

        /**
         * (#define final const) THAT IS WHAT A FINAL FUNCTION POINTER
         *
         * LOOKS LIKE, THAT CAN BE TAKEN TO THE CLASS VIRTUAL TABLE
         *
         * ALONG WITH volatile THAT WOULD BE PLACED AT THE SAME POINT
         *///thats obviously (after thinking about it)
         //how a const return type looks
        ///const X bool (*compare)(const Object *,const Object *) = &equal;
    //#define equal(self, obj, type) type##Equal
        ///void func3(){ compare = & greater; }///"error: assignment of read-
                                      ///only variable 'compare' " - compiler
    //#define greater(...)

    /// !equal && !greater  == less

    /// !greater            == less || equal

    /// !equal              == not equal

    ///                        equal

    ///                        greater

    ///                        greater || equal

    /*

    */

    //!      - - funky comment block - -
    /*
        heres a question, would this pointer be declared as volatile

        even though it may never get re-initialized?  (compare)

        (see vTable.h, fTable.h, aTable.h for proper use of volatile)
    */


    #endif // COMPARABLE_H_INCLUDED
                                                    //CWP
#endif // FACTORYTABLESINGLETON
