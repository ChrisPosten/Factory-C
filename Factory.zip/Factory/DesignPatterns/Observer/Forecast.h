#ifndef FORECAST_H_INCLUDED
#define FORECAST_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "WeatherStation.h"

    #define Forecast(Member)   Forecast##Member ///Class namespace macro

                                                ///this is a macro for name spacing
                                                ///use it everywhere there is a member
                                                ///of the name space if desired.
                                                ///front-end macros like these are why
                                                ///macros are considered an art form
                                                ///that make source code as satisfying
                                                ///to look at as possible

    #define WeatherStationForecast(Member)\
    \
        WeatherStationForecast##Member
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    struct Forecast;///declare class

    typedef struct Forecast Forecast;///class name

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                             ///class virtual table///
    typedef struct Forecast    (VirtualTable)
    {   Observer    (VirtualTable) base;//notice the use of Forecast() macro for readability

        ///declare function pointers to be provided by interface

    }Forecast    (VirtualTable);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                    ///class///
    struct Forecast
    {   Observer base;


        ///declare data members and strategic functions

        double       current_pressure,

                     last_pressure;
    };
                                            //not only that but no use so dont declare (below)
    ///static ForecastVirtualTable ForecastInterface = { { {0,0,0},0 } } (only if abstract)

    /// /// /// /// /// /// all classes need these: /// /// /// /// /// /// /// ///
    static Forecast * Forecast(Init)(Forecast *);///for object

    static void Forecast(Dtor)(Forecast *);

    static cstring Forecast(Type)();


    explicit void Forecast(Dtor)(Forecast * self){ }  ///for object  IMPLEMENTED

    explicit cstring Forecast(Type)(){ return "Forecast"; }/// class key (factory table)
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                    ///pointers declared inside Base base can be implemented here and
    static void ForecastUpdate( Forecast *, ... );
    ///prototyped first so ClassInterface knows what they are before being implemented

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static void WeatherStation(Forecast)(Update)( Forecast *, ... );

    static Forecast * WeatherStation(Forecast)(Init)( Forecast *, ... );

    static void WeatherStation(Forecast)(Dtor)( Forecast * );

    explicit void WeatherStation(Forecast)(Dtor)( Forecast * self )

    { AdapterTable(Interface).remove( atable, self ); }

    static ctorPtr WeatherStation(Forecast)(Ctor)();
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                     ///class virtual table instance A.K.A. class interface///
    static Forecast(VirtualTable)

        Forecast(Interface) =
    {///Forecast   (VirtualTable)             ///class interface or ClassInterface
        {///Observer   (VirtualTable)
            {///struct class (VirtualTable)
                &Forecast(Type),

                &Forecast(Init),

                &Forecast(Dtor)
            },

            &Forecast(Update)  ///the address can be 0 if not implemented here
        }                           ///thats where a class would still be considered
    };                      ///abstract and so consider that before allocating memory
    static ctorPtr typename(Ctor)(Forecast);
    /// /// /// /// /// OBSERVER PATTERN (second static instance) /// /// /// /// ///
    static Forecast(VirtualTable)

        WeatherStation(Forecast)(Interface) =
    {
        {
            {
                &Forecast(Type),
                         /// /// /// /// /// /// /// /// ///
                &WeatherStation(Forecast)(Init), /// ///
                         /// /// /// /// /// /// /// /// ///
                &WeatherStation(Forecast)(Dtor)
            },
             /// /// /// /// /// /// /// /// /// /// /// ///
            &WeatherStation(Forecast)(Update)/// /// ///
        }    /// /// /// /// /// /// /// /// /// /// /// ///
    };
    explicit ctorPtr WeatherStation(Forecast)(Ctor)()
    { return adapter(WeatherStation,Forecast); }
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                    ///  constructor (global initializer also)  ///

    explicit Forecast * Forecast(Init)( Forecast * self )
    {                                                           ///IMPLEMENT
        if( self == nullptr ){ return nullptr; }


        self->current_pressure      =       0.0f;

        self->last_pressure         =       0.0f;


        return self;
    }


    explicit Forecast * WeatherStation(Forecast)(Init)( Forecast * self, ... )
    {                                                              ///IMPLEMENT
        if( self == nullptr ){ return nullptr; }

        Stack * stack = control();

        WeatherStation * host = arg(stack, Object *);


        self->current_pressure      =       0.0f;

        self->last_pressure         =       0.0f;


        AdapterTable(Interface).insert( atable, self, host );

        WeatherStation(InsertObserver)(host, self);//Observer pattern

        return self;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                      /// implement functions (concrete) ///
    explicit void Forecast(Update)( Forecast * self, ... )
    {
        Stack * stack = control();


        self->last_pressure = self->current_pressure;

        self->current_pressure = arg(stack, double);///pressure
    }




    explicit void WeatherStation(Forecast)(Update)( Forecast * self, ... )
    {
        Stack * stack = control();

        if( Subject(Flag) == true )  //2) notified from Subject
        {printf("ON/");

            arg(stack, double);
            arg(stack, double);///... (increment)

            self->last_pressure = self->current_pressure;

            self->current_pressure = arg(stack, double);///pressure


        }
        if( Subject(Flag) == false ) //1) raise a flag for the Subject to notify all
        {printf("OFF/");      //this function-level pattern divides a function
                              //or a set of functions into two parts each, think of it
                                            //as a BASE CASE ON/BASE CASE OFF function
                                                 //(indirectly recursive)

            virtual( friend( self ), Subject )

                ->assign( this, arg(stack, double),

                      arg(stack, double), arg(stack, double) );

            virtual( friend( self ), Subject ) //use the new friend "keyword"

                ->notify( this );
        }
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    ///there is a strategic Display object identical to Command that uses this function
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    explicit int Forecast(Display)( Forecast * self )
    {
        printf("\t    << FORECAST DISPLAY >>\n\n");

        printf("forecast:\t\t\t\t");

        if( self->current_pressure > self->last_pressure )
        {
            printf("GOOD (>)\n\n");
        }
        else

        if( self->current_pressure == self->last_pressure )
        {
            printf("SAME (==)\n\n");
        }
        else

        if( self->current_pressure < self->last_pressure )
        {
            printf("RAIN (<)\n\n");
        }
        return 0;
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    static Virtual  /**Table(Name, Pos, Default)**/

        Forecast(VirtualHeap)[four] = /**CLASS VIRTUAL TABLE TABLE**/
    {/**A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P  Q  R  S  T  U  V  W  X  Y  Z**/
        { "dtor",             2,      &Forecast(Dtor)             },
        { "init",             1,      &Forecast(Init)             },
        { "type",             0,      &Forecast(Type)             },
        { "update",           3,      &Forecast(Update)           },

        { "", 0, 0 }
    };static Virtual *
    typename(SubFactoryMethod)(Forecast,Virtual,Virtual,0,3);


    static struct class(VirtualHeap)
        Forecast(Virtual) =

    { &class(VirtualHeap)(Type),
    &Forecast(VirtualSearch),
    Forecast(VirtualHeap) };


    static struct class(FactoryTable)

        Forecast(Factory) =
    {
        &class(FactoryTable)(Type),
        &Forecast(Ctor),0 };


    static struct class (AdapterTable)
        WeatherStation(Forecast)(Adapter) =

    {&WeatherStation(AdapterTable)(Type),&WeatherStation(Forecast)(Init),
     &WeatherStation(Forecast)(Interface)};


    static struct class (ConsoleTable)
        Forecast(Console) =

    {&class(ConsoleTable)(Type),0,
     &Forecast(Display)};

   # define ForecastSecurity(Member)ForecastSecurity ## Member
    static cstring typename(PassNumber)(Forecast, Security);

    extern struct pass(SecurityHeap)

        Forecast(Security) ;


    static Interface Forecast(InterfaceHeap)[six] =
    {
      &Forecast(Security),

      &Forecast(Interface),//capital H

      &WeatherStation(Forecast)(Adapter),// capital W with WeatherStation

      &Forecast(Console),

      &Forecast(Factory),//lowercase c then F with class(FactoryTable)

      &Forecast(Virtual),

      nullptr
    };

    ///class construction/template macro
    static Interface typename(ClassFactoryMethod)(Forecast,0,5);


    struct pass(SecurityHeap)

        Forecast(Security) =

    { { & Forecast(Security)(ID), 0,

          Forecast(InterfaceHeap) },

        & pass(SecurityHeap)(Type) } ;


    static void typename(Setup)(Forecast)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


    static void typename(Abort)(Forecast)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static struct class(FactoryTable)

        WeatherStation(Forecast)(Factory) =
    {
        &class(FactoryTable)(Type),

        &WeatherStation(Forecast)(Ctor),

        0   };


    static Interface WeatherStation(Forecast)(InterfaceHeap)[one] =

    { & WeatherStation(Forecast)(Factory), nullptr };


    static Interface typename(ClassFactoryMethod)(WeatherStation(Forecast), 0, 0);


    static void typename(Setup)(WeatherStation(Forecast)) {}

    static void typename(Abort)(WeatherStation(Forecast)) {}


#endif // FORECAST_H_INCLUDED
