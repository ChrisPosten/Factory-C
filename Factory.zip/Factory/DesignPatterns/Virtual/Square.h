#ifndef SQUARE_H_INCLUDED
#define SQUARE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "Shape.h"

    #define Square(Member) Square##Member
       //this makes a namespace out of the structure datatype
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct Square ;

    typedef struct Square Square;


    typedef struct Square(VirtualTable)
    {   Shape(VirtualTable) base;
    } Square(VirtualTable);


    struct Square          //typedefine structure in declaration
    {   Shape base;       //so the object list inbetween the end
                         //block separator (curly bracket) and
                        //statement terminator (semicolon)
        size_t n;      //transformes into a list of ClassNames
                      //(list of variables/objects otherwise)
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Square * Square(Init)(Square *, .../*size_t*/); //factory initializer

    static void Square(Dtor)(Square *) ;

    static cstring Square(Type)();


    explicit void Square(Dtor)(Square * self) {}

    explicit cstring Square(Type)(){ return "Square"; }


    static size_t Square(GetArea)(Square *);


    static Square(VirtualTable) Square(Interface) =
    {
        {
            &Square(Type),

            &Square(Init),

            &Square(Dtor)
        },
        &Square(GetArea)
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                  //even though the constructor pointer
                                 //used by the vTable can point to any
    explicit Square * Square(Init)(Square * self, ... /*size_t n*/)
    {                          //function of a similar prototype with
        /*if(self == nullptr){ return nullptr; }*/
        stack(control)();
                             //any amount of parameters or none after
        self->n = stack(arg)(size_t);//the first parameter, a factory function
                           //is the only real way to get multiple uses
        return self;      //out the the constructor, a technical overload
                         //using the instance method, or an overload possibly.
    }
                        //so the first parameter and the return type are
                       //always the same thing (constructor/initializer)
    explicit size_t Square(GetArea)(Square * self)
    {
        return self->n * self->n;
    }


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**          SMALL FACTORY TABLE CLASS INCLUDED             **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static ctorPtr Square(Ctor)();

    explicit ctorPtr Square(Ctor)(){return new(Square);}


    static struct class(FactoryTable)

        Square(Factory) = //non-extended registration style interface
    {
        & class(FactoryTable)(Type),

        Square(Ctor),  //factory("Square")(this, ...)

        0 //helper
    };


    #define defineSquareOut(Type,Print,End)\
    \
      /*static int*/ Square(Type##Out)(Square *);\
    \
      explicit int Square(Type##Out)(Square * self)\
      {\
          Print "%u", virtual(self, Shape)->getArea(this) End ;\
      }

    static int typename(SquareOut)(Console, _cPrint(), cEnd());

    static struct class(ConsoleTable)

        Square(Console) =
    {
        & class(ConsoleTable)(Type),

        0, //in

        & Square(ConsoleOut) //out
    };


    static Interface

        Square(InterfaceHeap)[two] =

    {/*(by int_it:) abcdefghijklmnopqrstuvwxyz*/
        & Square(Console),

        & Square(Factory),

      /*& Square(Compare),*////next one i would recommend or
                            ///class(VIrtualHeap)
        nullptr
    };
    static Interface
    typename(ClassFactoryMethod)(Square,0,1);//singleton method
    /// Class(HeapSearch)("...")

    static void typename(Setup)(Square){}

    static void typename(Abort)(Square){}


                                                            //CWP
#endif // SQUARE_H_INCLUDED
