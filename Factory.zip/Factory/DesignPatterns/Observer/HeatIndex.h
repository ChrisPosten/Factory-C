#ifndef HEATINDEX_H_INCLUDED
#define HEATINDEX_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #include "WeatherStation.h"


    #define HeatIndex(Member)  HeatIndex##Member


    #define WeatherStationHeatIndex(Member)\
    \
        WeatherStationHeatIndex##Member

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct HeatIndex;

    typedef struct HeatIndex HeatIndex;


    typedef struct HeatIndex (VirtualTable)
    {   Observer (VirtualTable) base;
    }HeatIndex (VirtualTable);


    struct HeatIndex
    {   Observer base;

        double   heat_index;
    };

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static HeatIndex * HeatIndex(Init)(HeatIndex *);

    static void HeatIndex(Dtor)(HeatIndex *)  ;

    static cstring HeatIndex(Type)();


    explicit void HeatIndex(Dtor)(HeatIndex * self)       {}

    explicit cstring HeatIndex(Type)(){ return "HeatIndex"; }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static void HeatIndex(Update)( HeatIndex *, ... );

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static double HeatIndex(Compute)( double, double );

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static HeatIndex * WeatherStation(HeatIndex)(Init)(HeatIndex *, ... );

    static void WeatherStation(HeatIndex)(Update)( HeatIndex *, ... );

    static void WeatherStation(HeatIndex)(Dtor)( HeatIndex * );

    explicit void WeatherStation(HeatIndex)(Dtor)( HeatIndex * self )

    { AdapterTable(Interface).remove( atable, self ); }

    static ctorPtr WeatherStation(HeatIndex)(Ctor)();

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static HeatIndex (VirtualTable)

        HeatIndex(Interface) =
    {
        {
            {
                &HeatIndex(Type),

                &HeatIndex(Init),

                &HeatIndex(Dtor)
            },

            &HeatIndex(Update)
        }
    };
    static ctorPtr typename(Ctor)(HeatIndex);

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static HeatIndex (VirtualTable)

        WeatherStation(HeatIndex)(Interface) =
    {
        {
            {
                &HeatIndex(Type),

                &WeatherStation(HeatIndex)(Init),

                &WeatherStation(HeatIndex)(Dtor)
            },

            &WeatherStation(HeatIndex)(Update)
        }
    };
    explicit ctorPtr WeatherStation(HeatIndex)(Ctor)()
    { return adapter(WeatherStation,HeatIndex); }
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit HeatIndex * HeatIndex(Init)

        ( HeatIndex * self)
    {
        if( self == nullptr ){ return nullptr; }

        self->heat_index         =       0.000f;

        return self;
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit HeatIndex * WeatherStation(HeatIndex)(Init)

        ( HeatIndex * self, ... )
    {
        if( self == nullptr ){ return nullptr; }

        Stack * stack = control();

        WeatherStation * host = arg(stack, Object *);


        self->heat_index         =       0.000f;


        AdapterTable(Interface).insert( atable, self, host );

        WeatherStation(InsertObserver)(host, self);

        return self;
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void HeatIndex(Update)( HeatIndex * self, ... )
    {
        Stack * stack = control();

        self->heat_index = HeatIndex(Compute)

            (arg(stack, double), arg(stack, double));
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void WeatherStation(HeatIndex)(Update)( HeatIndex * self, ... )
    {
        Stack * stack = control();

        if( Subject(Flag) == true )  //2) notified from Subject
        {printf("ON/");



            self->heat_index = HeatIndex(Compute)

                (arg(stack, double), arg(stack, double));


        }
        if( Subject(Flag) == false ) //1) raise a flag for the Subject to notify all
        {printf("OFF/");     ///Subject(Flag) = true;

            virtual( *AdapterTable(Interface).search( atable, self ), Subject )

                ->assign( this, arg(stack, double),

                      arg(stack, double), arg(stack, double) );

            virtual( *AdapterTable(Interface).search( atable, self ), Subject )

                        ->notify( this );
        }
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit int HeatIndex(Display)( HeatIndex * self )
    {
        printf("\t   << HEAT INDEX DISPLAY >>\n\n");

        printf("heat_index:\t\t\t\t%.3f\n\n", self->heat_index);

        return 0;
    }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

	explicit double HeatIndex(Compute)(double t, double rh)
	{
		double index = (double)((16.923 + (0.185212 * t) + (5.37941 * rh) - (0.100254 * t * rh)
			+ (0.00941695 * (t * t)) + (0.00728898 * (rh * rh))
			+ (0.000345372 * (t * t * rh)) - (0.000814971 * (t * rh * rh)) +
			(0.0000102102 * (t * t * rh * rh)) - (0.000038646 * (t * t * t)) + (0.0000291583 *
			(rh * rh * rh)) + (0.00000142721 * (t * t * t * rh)) +
			(0.000000197483 * (t * rh * rh * rh)) - (0.0000000218429 * (t * t * t * rh * rh)) +
			0.000000000843296 * (t * t * rh * rh * rh)) -
			(0.0000000000481975 * (t * t * t * rh * rh * rh)));
		return index;
	}

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    static Virtual  /**Table(Name, Pos, Default)**/

        HeatIndex(VirtualHeap)[four] = /**CLASS VIRTUAL TABLE TABLE**/
    {/**A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P  Q  R  S  T  U  V  W  X  Y  Z**/
        { "dtor",             2,      &HeatIndex(Dtor)             },
        { "init",             1,      &HeatIndex(Init)             },
        { "type",             0,      &HeatIndex(Type)             },
        { "update",           3,      &HeatIndex(Update)           },

        { "", 0, 0 }
    };static Virtual *
    typename(SubFactoryMethod)(HeatIndex,Virtual,Virtual,0,3);


    static struct class(VirtualHeap)
        HeatIndex(Virtual) =

    { &class(VirtualHeap)(Type),
    &HeatIndex(VirtualSearch),
    HeatIndex(VirtualHeap) };


    static struct class(FactoryTable)

        HeatIndex(Factory) =
    {
        &class(FactoryTable)(Type),
        &HeatIndex(Ctor),0 };


    static struct class (AdapterTable)
        WeatherStation(HeatIndex)(Adapter) =

    {&WeatherStation(AdapterTable)(Type),&WeatherStation(HeatIndex)(Init),
     &WeatherStation(HeatIndex)(Interface)};


    static struct class (ConsoleTable)
        HeatIndex(Console) =

    {&class(ConsoleTable)(Type),0,
     &HeatIndex(Display)};

   # define HeatIndexSecurity(Member)HeatIndexSecurity ## Member
    static cstring typename(PassNumber)(HeatIndex, Security);

    extern struct pass(SecurityHeap)
        HeatIndex(Security) ;


    static Interface HeatIndex(InterfaceHeap)[six] =
    {
      &HeatIndex(Security),

      &HeatIndex(Interface),//capital H

      &WeatherStation(HeatIndex)(Adapter),// capital W with WeatherStation

      &HeatIndex(Console),

      &HeatIndex(Factory),//lowercase c then F with class(FactoryTable)

      &HeatIndex(Virtual),

      nullptr
    };

    ///class construction/template macro
    static Interface typename(ClassFactoryMethod)(HeatIndex,0,5);


    struct pass(SecurityHeap)
        HeatIndex(Security) =

    { { & HeatIndex(Security)(ID), 0,
          HeatIndex(InterfaceHeap) },
        & pass(SecurityHeap)(Type) } ;


    static void typename(Setup)(HeatIndex)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


    static void typename(Abort)(HeatIndex)
    {try{
        } catch(Exception * e)
     {printStackTrace(e);delete(e);}}


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static struct class(FactoryTable)

        WeatherStation(HeatIndex)(Factory) =
    {
        &class(FactoryTable)(Type),

        &WeatherStation(HeatIndex)(Ctor),

        0   };


    static Interface WeatherStation(HeatIndex)(InterfaceHeap)[one] =

    { & WeatherStation(HeatIndex)(Factory), nullptr };


    static Interface typename(ClassFactoryMethod)(WeatherStation(HeatIndex), 0, 0);


    static void typename(Setup)(WeatherStation(HeatIndex)) {}

    static void typename(Abort)(WeatherStation(HeatIndex)) {}


#endif // HEATINDEX_H_INCLUDED
