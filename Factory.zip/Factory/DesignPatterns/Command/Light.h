#ifndef LIGHT_H_INCLUDED
#define LIGHT_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../../OOC/Virtual/vTable.h"

    #include "../../OOC/Library/String.h"

    #define Light(Member)   Light##Member
    typedef struct
    {   struct class base;  /** class responsibility (extension) (update: not needed)
                                but the vTable was modified to accept primitives/arrays
     **/String * location;  /** so there is no further need to extend from the empty
                                struct class by simple inheritance **/
    }Light;///class responsibility  (class name)


    typedef struct
    {   struct class (VirtualTable) base; ///class responsibility (extension)

        void (*on) (Light *);

        void (*off) (Light *);

    } Light(VirtualTable);


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Light * LightInit( Light *, String * );

    static void LightDtor( Light * ) ;

    static cstring LightType() ;


    explicit void LightDtor( Light * self ) { delete(self->location); }///

    explicit cstring LightType() { return "Light"; }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static void LightOn( Light * );

    static void LightOff( Light * );

    /// /// /// /// /// /// /// /// /// /// /// ///

    static LightVirtualTable LightInterface =
    {
      { &LightType, &LightInit, &LightDtor },

        &LightOn,

        &LightOff };

    /// /// /// /// /// /// /// /// /// /// /// ///

    explicit Light * LightInit

        ( Light * self, String * location )

    { if (!self) {return 0;}

        self->location = location;

      return self; }


    explicit void LightOn( Light * self )

    { if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sLight is on.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    explicit void LightOff( Light * self )

    { if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sLight is off.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    #define defineFunc( onOrOff )\
    \
    { if(!self->location)\
      { printf("\"UNKNOWN LOCATION\"\n"); }\
        printf("%sLight is " #onOrOff ".\n",\
            virtual(self->location, String)\
            ->toString(this) ); }

    ///inline void LightOff( Light * self )

    ///typename(Func)(on)      //defineFunc(off)


#endif // LIGHT_H_INCLUDED
