#ifndef STREAMINGPLAYER_H_INCLUDED
#define STREAMINGPLAYER_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "Amplifier.h"

    struct Amplifier;///declare structured datatype (not implemented)

    typedef struct Amplifier Amplifier;///typedef
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    ///THIS IS A (SMALL) FACTORY TABLE CLASS
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define StreamingPlayer(Member)StreamingPlayer##Member
    typedef struct StreamingPlayer
    {   struct class  base;

        String *      description,

               *      movie;

        size_t        chapter;

    }StreamingPlayer;

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    typedef struct StreamingPlayer(VirtualTable)
    {   struct class(VirtualTable) base;

        void (*on) ( StreamingPlayer * );

        void (*off)( StreamingPlayer * );
        /// /// /// /// /// /// /// /// /// /// /// /// ///
        void (*play)( StreamingPlayer *, ... ); ///
        /// /// /// /// /// /// /// /// /// /// /// /// ///
        void (*stop)( StreamingPlayer * );

        void (*pause)( StreamingPlayer * );

        void (*setTwoChannelAudio)( StreamingPlayer * );

        void (*setSurroundAudio)( StreamingPlayer * );

        cstring () (*toString)( StreamingPlayer * );

    }StreamingPlayer(VirtualTable);


    typedef struct StreamingPlayer(FactoryTable)
    {   struct class (FactoryTable) base;

        void (*playerPlayString)( StreamingPlayer *, String * );

        void (*playerPlayInt)( StreamingPlayer *, int * );

    }StreamingPlayer(FactoryTable);

/// /// /// /// /// CLASS FACTORY METHOD // /// /// /// /// /// /// ///
    static Interface StreamingPlayer(Heap)( cstring ); /// /// /// ///
    /// /// /// /// /// /// /// /// ///
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static StreamingPlayer * StreamingPlayer(Init)
         ( StreamingPlayer *,String *,String *, ... ); /// /// ///

    static void StreamingPlayer(Dtor)( StreamingPlayer * );
 /// ///         /// /// /// /// ///           /// /// /// ///
    static cstring StreamingPlayer(Type)();

 /// /// ///                  /// /// /// /// ///        /// /// /// ///
    static Object * StreamingPlayer(StrategyHeap)( cstring );


    explicit cstring StreamingPlayerType(){ return "StreamingPlayer"; }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static void StreamingPlayerOn ( StreamingPlayer * );

    static void StreamingPlayerOff( StreamingPlayer * );


    static void String(Setup) (void);

    static void String(Abort) (void);

 /// /// /// /// /// /// ///CENTRAL FUNCTION/// /// /// /// /// /// /// ///
    static void StreamingPlayerPlayOverload( StreamingPlayer *, ... );///
   /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static void StreamingPlayerPlayString( StreamingPlayer *, String * );

    static void StreamingPlayerPlayInt( StreamingPlayer *, int * );
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static void StreamingPlayerStop( StreamingPlayer * );

    static void StreamingPlayerPause( StreamingPlayer * );


    static void StreamingPlayerSetTwoChannelAudio( StreamingPlayer * );

    static void StreamingPlayerSetSurroundAudio( StreamingPlayer * );


    static cstring StreamingPlayerToString( StreamingPlayer * );

 /// /// /// /// /// /// /// /// /// /// /// ///
    static StreamingPlayer(VirtualTable)

        StreamingPlayer(Interface) =
 /// /// /// /// /// /// /// /// /// /// /// ///
    {
        {
            &StreamingPlayerType,

            &StreamingPlayerInit,

            &StreamingPlayerDtor
        },

        &StreamingPlayerOn,

        &StreamingPlayerOff,
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        &StreamingPlayerPlayOverload,///overloaded///
 /// /// /// /// /// /// /// /// /// /// /// /// ///
        &StreamingPlayerStop,

        &StreamingPlayerPause,

        &StreamingPlayerSetTwoChannelAudio,

        &StreamingPlayerSetSurroundAudio,

        &StreamingPlayerToString
    };
    static ctorPtr StreamingPlayer(Fact)();
 /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit StreamingPlayer * StreamingPlayerInit( StreamingPlayer * self,

        String * description,  String * movie, ... )
    {
        if( !self ){ return 0; }

        self->description       =       description;

        self->movie             =       movie;

        self->chapter           =       0;

        return self;
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerDtor( StreamingPlayer * self )
    {
        delete(self->description);

        delete(self->movie);
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerOn ( StreamingPlayer * self )
    {
        printf("%s is on\n", virtual( self->description, String )

               ->toString(this)  );
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerOff( StreamingPlayer * self )
    {
        printf("%s is off\n", virtual( self->description, String )

               ->toString(this));
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerPlayString

        ( StreamingPlayer * self, String * movie )
    {
        if( self->movie ) { delete(self->movie); }

        self->movie = movie;


        self->chapter = 0;

        printf("%s playing %s \n",

            virtual( self->description, String )->toString(this),

            virtual( self->movie, String )->toString(this));
    }
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    explicit void StreamingPlayerPlayInt

        ( StreamingPlayer * self, int * chapter )
    {
        if(!self->movie)
        {
            printf("%s can't chapter %u no movie selected",

                virtual ( self->description, String )

                   -> toString(this), self->chapter);
        }
        else
        {
            self->chapter = (*chapter) ;// ref(chapter)

            printf("%s playing chapter %u of \\%s\\",

                virtual ( self->description, String )

                   -> toString(this), self->chapter,

                virtual ( self->movie, String ) -> toString(this));
        }
    }

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerStop( StreamingPlayer * self )
    {
        self->chapter = 0;

        printf("%s stopped %s \n",

            virtual( self->description, String )->toString(this),

            virtual( self->movie, String )->toString(this));
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerPause( StreamingPlayer * self )
    {
        printf("%s paused %s \n",

            virtual( self->description, String )->toString(this),

            virtual( self->movie, String )->toString(this));
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerSetTwoChannelAudio

        ( StreamingPlayer * self )
    {
        printf("%s set two channel audio\n",

            virtual( self->description, String )->toString(this));
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerSetSurroundAudio

        ( StreamingPlayer * self )
    {
        printf("%s set surround audio\n",

               virtual( self->description, String )

               ->toString(this));
    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit cstring StreamingPlayerToString( StreamingPlayer * self )
    {
        return virtual( self->description, String )->toString(this) ;
    }

 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
 /**
    FACTORY TABLE CLASS


  */
 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

 /// /// /// /// /// /// /// /// /// /// /// ///


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit ctorPtr StreamingPlayer(Fact)()
        { return new(StreamingPlayer); }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    static StreamingPlayer(FactoryTable)

        StreamingPlayer(Factory) =

    { &class(FactoryTable)(Type),

      &StreamingPlayer(Fact), 0 };

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

    static Strategy

        StreamingPlayer(PlayHeap)[two] =

    {   {"String", & StreamingPlayer(PlayString)},

        {"int", & StreamingPlayer(PlayInt)},

        {"",0}   };

    static Strategy *
    typename(SubFactoryMethod)(StreamingPlayer, Strategy, Play, 0, 1)

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief   overloaded function example                     *
     *                                                          *
     * @param   String * or int *                               *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void StreamingPlayerPlayOverload

        ( StreamingPlayer * self, ... )

    {   Stack * stack = control();

        Object * object = arg(stack, Object*);

        Strategy * p = StreamingPlayer(PlaySearch)(typeid(object));

        if( p ){ return ((factPtr)p->val)(self, object);; }
        else { throw( new(Exception) )(this, "InvalidDataType");}}

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

   # define StreamingPlayerPlayHeap(Member)\
        StreamingPlayerPlayHeap ## Member
    static cstring StreamingPlayer(PlayHeap)(Type)();
    explicit cstring StreamingPlayer(PlayHeap)(Type)()
             { return "StreamingPlayer(Play)"; }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    static struct class(StrategyHeap)

        StreamingPlayer(Play) =

    {   & StreamingPlayer(PlayHeap)(Type),

        & StreamingPlayer(PlaySearch),

          StreamingPlayer(PlayHeap)   };

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/


    static Interface StreamingPlayer(InterfaceHeap)[two] =

    { & StreamingPlayer(Factory),

      & StreamingPlayer(Play),

      nullptr };

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    static Interface typename(ClassFactoryMethod)(StreamingPlayer,0,1);

    /*explicit Reg StreamingPlayer(Search)( cstring reg )

    {   Reg iterator[3] =  { & VolatileType, 0, 0 }; ///SLOT

        fSizeType    i;        volatilewhat = reg;

        RegList p = RegSearch( StreamingPlayer(Regs), iterator, & i, 0, 1 );

        if( p ){ return (*p); } else { return 0; }   }*/
         //ClassFactoryMethod
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                   *
     *                                                          *
     * @param                                                   *
     *                                                          *
     * @return                                                  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/


    /**
     * register(Class) base types here + sort check + ...
     */
    explicit void StreamingPlayer(Setup) (void) {}

    explicit void StreamingPlayer(Abort) (void) {}

    //void (*play)( StreamingPlayer *, ... );///void (*play)( StreamingPlayer *, ... );

    ///void (*play)( StreamingPlayer *, size_t ); MUST BE A FACTORY TABLE CLASS


    ///void play( StreamingPlayer * self, ... ) {} FOR FACTORY TABLE CLASS

    ///THIS SHOULD EVEN GO INSIDE THE FILE FactoryObject.h   X  NO

    ///THERE ARE 2 LEVELS OF OVERLOADED FUNCTION OR JUST OVERLOADED FUNCTIONS

    ///AND FACTORY OBJECT FUNCTIONS

#endif // STREAMINGPLAYER_H_INCLUDED
