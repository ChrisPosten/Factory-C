#ifndef DEFINEBEVERAGE_H_INCLUDED
#define DEFINEBEVERAGE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "Beverage.h" // Decorator pattern

    /**
     * @brief Concrete Beverage Pattern Encapsulation Macro (X-MACRO)
     *
     *      - - X - Level Macro - X - -
     *
     * @author willy      (12/23/2021)
     */                      //  .99
    #define defineBeverage(Name, Cent)\
    \
        struct Name ;\
    \
        typedef struct Name Name;\
    \
    \
        typedef struct Name (VirtualTable)\
        {   Beverage(VirtualTable)base;\
        } Name (VirtualTable);\
    \
    \
        struct Name\
        {   Beverage base;\
        };\
    \
    \
        static Name * Name(Init)( Beverage *, ... );\
    \
        static void Name(Dtor)( Beverage * self )  {}\
    \
        static cstring Name(Type)();\
    \
    \
        explicit cstring Name(Type)(){ return #Name; }\
    \
    \
        explicit double Name(Cost)( Name * self ){ return Cent; }\
    \
    \
        static Name * Beverage(Name)(Init)( Beverage *, ... );\
    \
        static void Beverage(Name)(Dtor)( Beverage * );\
    \
    \
        static Name(VirtualTable) \
    \
            Name(Interface) =\
        {\
            {\
                {\
                    & Name(Type),\
    \
                    & Name(Init),\
    \
                    & BeverageDtor\
                },\
    \
                & BeverageGetDescription,\
    \
                & Name(Cost)\
            }\
        };\
    \
    \
        static Name(VirtualTable) \
    \
            Beverage(Name)(Interface) =\
        {\
            {\
                {\
                    & Name(Type),\
    \
                    & Beverage(Name)(Init),\
    \
                    & Beverage(Name)(Dtor)\
                },\
    \
                & BeverageGetDescription,\
    \
                & Name(Cost)\
            }\
        };\
    \
        /**
         * @brief normal constructor  (dont decorate)
         *
         * @param self
         *
         * @return ...
         */\
        explicit Name * Name(Init)( Beverage * self, ... )\
        {   self  = BeverageInit(  self  ) ;\
    \
            if( self == nullptr ){ return nullptr; }\
    \
            if( self->description )\
            {\
                delete(self->description);\
    \
                self->description = new(String)(this, 2, #Name);\
            }\
            if( self->description == nullptr ){ return nullptr; }\
    \
                /**...*/\
    \
            return self;\
        }\
    \
        /**
         * @brief ***decorated*** constructor
         *
         * @param self
         *
         * @return instance of object, following the virtual pattern
         */\
        explicit Name * Beverage(Name)(Init)( Beverage * self, ... )\
        {   self  = BeverageInit(  self  ) ;\
    \
            if( self == nullptr ){ return nullptr; }\
    \
            if( self->description )\
            {\
                delete(self->description);\
    \
                self->description = new(String)(this, 2, #Name);\
            }\
            if( self->description == nullptr ){ return nullptr; }\
    \
    \
    \
                AdapterTable(Interface).insert( atable, self, self );\
                /**PREFERENCE TO HAVE ***DECORATED*** COME
                       WITH LOOP TERMINATION CONDITION**/\
    \
    \
            return self;\
        }\
    \
    \
        explicit void Beverage(Name)(Dtor)( Beverage * self )  \
        { }


#endif // DEFINEBEVERAGE_H_INCLUDED
