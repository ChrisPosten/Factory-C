#ifdef CHOCOLATEBOILERSINGLETON
    #ifndef DRAIN_H_INCLUDED
    #define DRAIN_H_INCLUDED

    explicit bool      drain(void)

    { return ChocolateBoiler(Drain)(cboiler); }

    #endif // DRAIN_H_INCLUDED
#endif // CHOCOLATEBOILERSINGLETON
