#ifndef DUCK_H_INCLUDED
#define DUCK_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #include "../../OOC/Adapter/aTable.h"

    #include "Turkey.h"//class to adapt to

    #define Duck(Member)  Duck##Member

    #define TurkeyDuck(Member)  TurkeyDuck##Member

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct Duck;

    typedef struct Duck Duck;

    typedef struct Duck (VirtualTable)
    {   struct class  (VirtualTable) base;

        void (*fly)(Duck *);    //execute style method(s)

        void (*quack)(Duck *);  //strategically suitable

        void (*swim)(Duck *);   //to be called from a factory

    } Duck (VirtualTable);      //function, function pointer


    struct Duck
    {   struct class base;

        size_t weight;
    };


    static Duck * Duck(Init)(Duck *, size_t);

    static void Duck(Dtor)(Duck *);

    static cstring Duck(Type)();   /// cstring str = typeid(duck)


    static ctorPtr Duck(Ctor)();   /// Duck * d = factory("Duck")(this, ...)


    explicit cstring Duck(Type)(){ return "Duck"; }


    static void Duck(Fly)(Duck *);

    static void Duck(Quack)(Duck *);

    static void Duck(Swim)(Duck *);

        /*

            there is room to be optimistic about what implementation

            of a type() method initializes what interfaces first

            data member (also first data field position using it as array).

            or more specifically, what type() function initializes the

            type() pointer for the adapter interface. that would determine

            what the object gets identified as for what registration

            list it would use for any kind of function like if there

            was a:

                    fly() function from a Flyable.h

            with a:

                    struct class (FlyableTable) {} from structclass.h


            -i would recommend using a class(VirtualHeap) for overloads

             involving interface methods


            and the object gets passed into that function, to be searched

            for in the vtable for its assigned interface to give its

            description from there, from there its description would be

            used to search for a matching entry in the ftable, where it

            (the object) would use the appropriate registration (interface)

            there from the assigned registration list, (null terminated

            array of pointers to registrations) to use everything from there.


            also, considering using typeid(object) for returning a string

            description into factory("ClassName")(this, ...) for a new object,

            if its an adapter, as in a Duck serving the purpose as an adapter

            for a Turkey, then it would need to have its assigned interface

            use the TurkeyDuckType() function from there or it will just create

            an instance of a normal Duck, not a "TurkeyDuck"




        */

    static Duck * Turkey(Duck)(Init)(Duck *, .../*Turkey * */);

    static void Turkey(Duck)(Dtor)(Duck *) ;


    static ctorPtr Turkey(Duck)(Ctor)() ;


    static void Turkey(Duck)(Fly)(Duck *);

    static void Turkey(Duck)(Quack)(Duck *);

    static void Turkey(Duck)(Swim)(Duck *);


    static Duck (VirtualTable)

        Duck(Interface) =
    {
        {
            &Duck(Type),

            &Duck(Init),

            &Duck(Dtor)
        },

        &Duck(Fly),

        &Duck(Quack),

        &Duck(Swim)    };

    explicit ctorPtr Duck(Ctor)(){return new(Duck);}


    static Duck(VirtualTable) ///still Duck Virtual Table
    /* we don't want to know if its a decorator, adapter or observer */
        Turkey(Duck)(Interface) =  ///declare a second instance of Duck vTable
    {
        {
            &Duck(Type), /// (transparent adapter)  this is perfect.
                        ///type_info(obj) can tell us if its an adapter
            &Turkey(Duck)(Init),///by checking the atable,vtable,ftable

            &Turkey(Duck)(Dtor)
        },

        &Turkey(Duck)(Fly),

        &Turkey(Duck)(Quack),

        &Turkey(Duck)(Swim)    };

    explicit ctorPtr Turkey(Duck)(Ctor)(){return adapter(Turkey, Duck);}


    explicit Duck * Duck(Init)

        ( Duck * self, size_t weight )

    { if(!self){return 0;}

        self->weight = weight;///don't forget this being there or not being there
                             ///for consistency this should be re-initialized
      return self;}         ///


    explicit Duck * Turkey(Duck)(Init)

        ( Duck * self, .../*Turkey * host*/ )

    { stack(control)();

        Turkey * host = stack(arg)(Turkey*);

        /* note: if factory c fortifies the adapter table here,

                 its with union, default 12 assigned true would

                 be recursive so watch out for that. the workspace

                 example uses union where the object is so

                 you can also assign variables like weight there,

                 a complex heap class(ComplexHeap) would look nice

                 there so then factory methods are used to access

                 the data members also (entry level Complex C is high

                 level Factory C).
         */
    #if 1
        AdapterTable(Interface).insert( atable, self, host );
    #else
        default(12) = false;

        union(true)(typeid(host),typeid(self))(self, host);
    #endif // 1

        self->weight = host->weight;

      return self;}


    explicit void Duck(Dtor)(Duck * self)
    {
        printf("<< DUCK DESTRUCTOR >>");
    }

    explicit void Duck(Fly)(Duck * self)
    {
        printf("<< DUCK FLYING >>");
    }

    explicit void Duck(Quack)(Duck * self)
    {
        printf("<< DUCK QUACKING >>");
    }

    explicit void Duck(Swim)(Duck * self)
    {
        printf("<< DUCK SWIMMING >>");
    }




    explicit void Turkey(Duck)(Dtor)(Duck * self)
    {
        printf("<< ADAPTER DESTRUCTOR >>");

        delete( friend( self ) );
        ///delete what its an adapter for

        AdapterTable(Interface).remove( atable, self );///remove from atable
    }

    explicit void Turkey(Duck)(Fly)(Duck * self)
    {
        for( int i = 0; i < 3; i++ )
        {
            Turkey(Fly)( friend( self ) );
        }
    }

    explicit void Turkey(Duck)(Quack)(Duck * self)
    {
        Duck(Quack)( self );

        printf("<< ADAPTER FUNCTION >>");

        Turkey(Gobble)( friend( self ) );
    }

    explicit void Turkey(Duck)(Swim)(Duck * self)
    {
        Duck(Swim)( self );

        printf("<< ADAPTER FUNCTION >>");

        Turkey(Swim)( friend( self ) );
    }



/**
        THIS IS FOR A FACTORY OBJECT BUT STILL INCOMPLETE AS

        ClassSearch AND ClassMeth ARE NOT NAMESPACES THAT HAVE

        BEEN FILLED WITH THE PROPERLY DATATYPED COMPONENTS TO

        THE FACTORY OBJECT CLASS (FACTORY TABLE CLASS)

        (COMPLETED)


        THESE IMPLEMENTATIONS ARE FOR WHERE AN Object IS NOT ONLY

        A VIRTUAL TABLE Object BUT AN Object OF A FACTORY TABLE

        CLASS (FACTORY OBJECT). A FACTORY TABLE CLASS IS A CLASS

        THAT HAS A CLASS FACTORY METHOD.
*/
    //explicit ctorPtr Duck(Ctor)(){ return new(Duck); } (previously)

    static void quack(Object *);

    static Virtual
        Duck(VirtualHeap)[six] = //(0-5)

    {/*a b c d e f g h i j k l m n o p q r s t u v w x y z*/
     {"dtor",2,&Duck(Dtor),""}, //KEY, VAL, END
     {"fly",3,&Duck(Fly),""},
     {"init",1,&Duck(Init),""},
     {"quack",4,&Duck(Quack),""},
     {"swim",5,&Duck(Swim),""},
     {"type",0,&Duck(Type),""},{"",0,0,""}
    };
    static Virtual *
    typename(SubFactoryMethod)(Duck,Virtual,Virtual,0,5);
            //Duck(SearchVirtual)

    /**
     * @brief  quack
     *
     * @param  self
     */
    explicit void quack(Object * self)
    {
    #if 1
        ((void(*)(Object*))*function(self, "quack"))(this);
    #else
        ((void(*)(Object*))((Interface)virtual(self,class))

        [ ((virtual*)multimap(true)(type_info(self))("quack"))

         ->val ])(this);
    #endif // THE_FUNCTION_METHOD
    }

    static struct class(VirtualHeap)
        Duck(Virtual) =

    {&class(VirtualHeap)(Type),
     &Duck(VirtualSearch), Duck(VirtualHeap) };


    static struct class(FactoryTable)
        Duck(Factory) =
    {
        &class(FactoryTable)(Type),
        &Duck(Ctor), 0, };

    # define TurkeyAdapterTable(Member)\
        TurkeyAdapterTable ## Member
    static cstring Turkey(AdapterTable)(Type)();

    explicit cstring Turkey(AdapterTable)(Type)()
        {return"Turkey(AdapterTable)";}

    static struct class (AdapterTable)

        Turkey(Duck)(Adapter) =

    {
        &Turkey(AdapterTable)(Type),
        &Turkey(Duck)(Init),
        &Turkey(Duck)(Interface) };

    ///... (open for extension)

    static Interface
        Duck(InterfaceHeap)[four] = //(0-3)
    {/*a b c d e f g h i j k l m n o p q r s t u v w x y z*/
        &Duck(Interface),  //Duck                 [0]

        &Turkey(Duck)(Adapter), //Turkey          [1]

        &Duck(Factory),//class(...)               [2]

        &Duck(Virtual),     //                    [3]

        ///... (open for extension)

        nullptr ///null termination required here
    };

    ///class construction/template macro
    static Interface
    typename(ClassFactoryMethod)(Duck,0,3);//(0-3)
/**
       this typename is equivalent to:

    explicit Interface DuckSearch( cstring reg )
    {
        Interface iterator[3] = { &Volatile(Type), 0, 0 };

        fSizeType i;               volatiletype = reg;

        InterfaceHeap p = InterfaceSearch(

            DuckInterfaceHeap, iterator, &i, 0, 1 );

        if( p ){ return ((*p)) ; } else { return 0; }
    }
*/
    static void typename(Setup)(Duck) {}

    static void typename(Abort)(Duck) {}

    /*
        "my ideas for these declarations/initializations is that

        they go so close to the implementations in a way that filling

        them out is filling out the responsibilities of the class

        and that corners should never be cut when it comes to that.

        so a corner was cut above when &DuckType...

        there are no corners being cut when there is an Adapter

        table in use for object adapters and two-way object adapters"
    *//**
        WHEN THE DUCK IS USED AS AN ADAPTER IT STILL HAS A typeid(duck)

        THAT RETURNS "Duck" NOT ANYTHING ELSE EVEN THOUGH ITS AN ADAPTER

        FOR SOMETHING. YOU CAN CHECK AND SEE IF ITS AN ADAPTER FOR

        SOMETHING AT THE ADAPTER TABLE TO GET THE typeid(obj) FROM

        BOTH ADAPTER AND ADAPTEE (SINCE BOTH WILL BE OBJECTS). AND SO

        THERE WILL BE TWO OBJECTS IN THE VIRTUAL TABLE AND ONE ADAPTER

        IN THE ADAPTER TABLE BY THE TIME WE HAVE AN OBJECT AND AN ADAPTER.

        THIS WAY WHEN WE GO TO CREATE ANOTHER INSTANCE OF A DUCK AND

        COPY IT FROM OUR DUCK THATS USED AS AN ADAPTER, IT GETS COPIED

        JUST AS A STRAIGHT DUCK AND NOT ANYTHING ELSE. THIS WAY WE CAN

        BE OPTIMISTIC THAT OUR ADAPTERS ARE A COMPLETE MECHANISM AND

        THAT BY THE TIME AN ADAPTER IS CREATED, USED TO CREATE

        A COPY OF ANOTHER OBJECT OF THAT TYPE THE ADAPTER IS, FOR

        THE ADAPTEE, THAT BY THEN OUR ADAPTER HAS SERVED ITS PURPOSE

        AND WE CAN CONTINUE ON WITH OUR NEW OBJECT JUST COPIED FROM

        AN ADAPTER, JUST THAT THE FIRST OBJECT (THE ADAPTER) WAS BEING USED

        AS AN ADAPTER FOR SOMETHING ELSE. SO OUR ADAPTERS HERE ARE

        TRANSPARENT ENOUGH TO NOT BE NOTICED EVER IN A FLOWING

        PROGRAM AND IF WE EVER WANT TO KNOW WE CAN CHECK AND SEE IF

        AN OBJECT IS AN ADAPTER BY LOOKING IN THE ADAPTER TABLE

        FOR IT. THATS WHEN THE ADAPTER HAS SERVED ITS PURPOSE AND

        CAN JUST GO AWAY THEN. (GOODBYE) TO OUR ADAPTER THEN

        BECAUSE WE NEVER WANTED IT. THEY ARE ONLY AN OO SOLUTION

        TO A PROBLEM THAT OCCURS WHEN USING A STRUCTURED DATATYPE

        (STRUCT) VARIABLE. BECAUSE STRUCTUED DATATYPES NEED A

        WELL DEVELOPED ADAPTER PATTERN TO DO EVERYTHING BEING

        THAT THEY ARE STRUCTURED DATATYPES WITH STRUCT VARIABLES

        USING NAMED DATAMEMBERS. I WOULD CONSIDER ADAPTER TO BE

        A CRITICAL DESIGN PATTERN AND THE SUCCESS OF THE ADAPTER

        PATTERN WOULD THEN BE THE "POINT OF BEND OR BREAK" FOR

        OBJECT ORIENTED PROGRAMMING USING ONLY STRUCTURED DATATYPES

        AND THIER (STRUCT) VARIABLES.


        BASED ON THE SUCCESS ON MY MODIFIED ADAPTER PATTERN THAT

        WAS INTRODUCED TO ME THROUGH Head First: Design Patterns

        (in java) WHERE I GOT RID OF THE MIDDLEMAN CLASS THAT HAS

        THE NAME ADAPTER IN IT AND JUST REASSIGNED THE INTERFACE,

        AND HOW QUICKLY THAT INTERFACE CAN BE REASSIGNED, HAVING

        TWO OBJECTS IN A VIRTUAL TABLE AND ONE ADAPTER IN THE

        ADAPTER TABLE BY THE TIME THERE'S AN ADAPTER AND ADAPTEE

        IS WHATS REQUIRED. DECORATOR AND OBSERVER CAN FALL UNDER

        THE CATEGORY OF "ADPATER PATTERNS" OR ADAPTER CONFIGURATIONS

        AS I WILL UPDATE THEIR PATTERNS FROM HERE, TO USE THE

        SAME CONFIGURATION AND TO BE ABLE TO PUT DOWN THEIR

        INTERFACE USED FOR THAT PATTERN (WHICH ECSPECIALLY MAKES

        DECORATORS ALOT MORE VALUABLE TO ME).


        WHEN I SAY STRUCTURED DATATYPES TRY AND CONSIDER OR

        TRY AND UNDERSTAND WHY I WAS OPTIMISTIC ABOUT IMPLEMENTING

        THE CONCRETE CLASS TYPE. THE CONCRETE CLASS WAS FOR AN

        OBJECT THATS A VIRTUAL TABLE OBJECT BUT AN OBJECT THAT WILL

        HAVE NO FURTHER CLASS DESCRIPTION. NOW TRY AND UNDERSTAND

        WHAT A COMPLEX DATATYPE MIGHT BE OVER A STRUCTURED ONE

        USING (STRUCT) IMPLEMENTATIONS AS IMPLEMENTED STRUCTURED

        DATATYPES USING STRUCT VARIABLES. BECAUSE A COMPLEX DATATYPE

        COULD HAVE BEEN A SOLUTION FOR ADAPTER BUT WILL NOT BE

        NECCESSARY. SINCE I FURTHER IMPLEMENTED MY OOC LIBRARY

        (@AUTHOR) WITH A FACTORY TABLE AFTER THE VIRTUAL TABLE

        AND WAS OPTIMISTIC ENOUGH ABOUT IMPLEMENTING THE CONCRETE

        CLASS (WHICH WAS A SMALL IMPLEMENTATION) THAT USES AN EXTRA

        PARAMETER IN ITS CONSTRUCTOR FOR AN EXTRA AMOUNT OF BYTES

        TO ALLOCATE THE OBJECT WITH, AFTER I IMPLEMENTED THE VIRTUAL

        TABLE - THAT SINCE THE FACTORY TABLE HAS BEEN IMPLEMENTED,

        AND THAT EVERY STATIC TABLE AND EVERY RESPONSIBILITY OF

        A REGISTRATION INTERFACE GETS ADDED AND EVERYTHING ABSOLUTELY

        EVERYTHING WILL BE DONE, THAT THERE WILL BE ENOUGH ROOM

        AFTERWARDS, ROOM FOR OPTIMISM, ENOUGH OPTIMISM TO ANNOUNCE

        THAT THERE WILL BE AN IMPLEMENTATION FOR A SMALL "CLASS BUILDER"

        THAT WILL JUST BE A SMALL IMPLEMENTATION BUT SOMETHING YOU

        CAN GO AHEAD AND CREATE A COMPLEX DATATYPE AT RUNTIME AND

        PICK-AND-PULL FROM EXISTING STRUCTURED DATATYPES AND THIER

        INTERFACES/TABLES AT RUNTIME FOR YOUR RUNTIME OBJECT BEING

        AN OBJECT OF A COMPLEX DATATYPE THAT WILL BE BUILT ON THE

        FOUNDATION OF THE CONCRETE CLASS AND MAKE USE OF THE STATIC

        TABLES THAT EACH FACTORY TABLE CLASS COMES COMPLETE WITH.

        (THOSE ARE ALL CLASS LEVEL RESPONSIBILITIES)
     */
    /**
        THIS IS FOR THE USE OF A SUBSTITIUTE FOR new(Class) TO BE

        ENCAPSULATED FOR A FULLY DYNAMIC INSTANCE OF AN ADAPTER TO

        BE CREATED USING factory("Class") SO THIS IS A CASE WHERE

        ITS NOT A Class SUBMITTING ITS ClassName AS A STRING TO

        THE FACTORY TABLE BUT ITS AN INSTANCE CREATION FUNCTION

        TO BE GIVEN ITS OWN SLOT THERE (adapter(Turkey, Duck)).

        OR "Turkey(Duck)". DONT FORGET TO:

        register(Turkey(Duck)) INSIDE FACTORY TABLE PROGRAM

        CONSTRUCTOR.

        (01/21/2022)
     */

    //# define TurkeyDuck(Member)TurkeyDuck ## Member

    //explicit ctorPtr Turkey(Duck)(Fact)(void)
    //    { return adapter(Turkey, Duck); }

    static Virtual
        Turkey(Duck)(VirtualHeap)[six] = //(0-5)

    {/*a b c d e f g h i j k l m n o p q r s t u v w x y z*/
     {"dtor",2,&Turkey(Duck)(Dtor),""}, //KEY, VAL, END
     {"fly",3,&Turkey(Duck)(Fly),""},
     {"init",1,&Turkey(Duck)(Init),""},
     {"quack",4,&Turkey(Duck)(Quack),""},
     {"swim",5,&Turkey(Duck)(Swim),""},
     {"type",0,&Duck(Type),""},{"",0,0,""}
    };
    static Virtual *
    typename(SubFactoryMethod)(Turkey(Duck),Virtual,Virtual,0,5);

    static struct class(VirtualHeap)
        Turkey(Duck)(Virtual) =

    {&class(VirtualHeap)(Type),
     &Turkey(Duck)(VirtualSearch),
     Turkey(Duck)(VirtualHeap) };

    ///this is for registering "Turkey(Duck)"
    ///so creating an instance can be fully-dynamic

    static struct class(FactoryTable)

        Turkey(Duck)(Factory) =
    {
        &class(FactoryTable)(Type),

        &Turkey(Duck)(Ctor),

        0,
    };


    static Interface Turkey(Duck)

        (InterfaceHeap)[three] =
    {
        & Turkey(Duck)(Interface),

        & Turkey(Duck)(Factory),

        & Turkey(Duck)(Virtual),

        nullptr
    };
    static Interface
    typename(ClassFactoryMethod)(Turkey(Duck), 0, 2);


    static void typename(Setup)(Turkey(Duck)) {}

    static void typename(Abort)(Turkey(Duck)) {}

#endif // DUCK_H_INCLUDED
