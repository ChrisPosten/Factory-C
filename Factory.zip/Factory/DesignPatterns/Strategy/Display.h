#ifndef DISPLAY_H_INCLUDED
#define DISPLAY_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../../OOC/OOC.h" // (Factory C)

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *                                                           *
     *      Display                                              *
     *      Display (VirtualTable)                               *
     *                                                           *
     *                                                           *
     *      Display(Interface)                                   *
     *      Display(Factory)                                     *
     *      Display(DisplayHeap)                                 *
     *      Display(Display)                                     *
     *      Display(VirtualHeap)                                 *
     *      Display(Virtual)                                     *
     *                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../Observer/CurrentConditions.h"

    #include "../Observer/Forecast.h"

    #include "../Observer/HeatIndex.h"

    #include "../Observer/Statistics.h"

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                /// STRUCTURES ///
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
   # define Display(Member)Display ## Member
    /**+---------------------------------+
     * @brief Strategic Display          |
     * +---------------------------------+
     *///this structure is identical to Command in Command.h just display not execute
    struct Display();

    typedef struct
    {   struct class (VirtualTable) base;
    }Display (VirtualTable);
        ///factory method to initialize strategic pointer dynamically #4///
    static Method * display( cstring );

    typedef struct
    {   struct class base; // = {} (using struct variable not object)

        Object * self;

        void (*display)( Object * ); /// strategic function pointer

    }Display();

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                /// PROTOTYPES  ///
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
            /// CLASS FACTORY METHOD #1
            /// Reg   ///easy to tell if factory table class if prototype(s) here
    static Interface Display(HeapSearch) ( cstring );
            /// SUB-FACTORY METHODS UNDER CLASS FACTORY METHOD: #2, #3 ///
    static Virtual * Display(VirtualSearch) ( cstring );

    static Strategy * Display(DisplaySearch) ( cstring );

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Display * Display(Init)( Display * self, .../*Object *, void(*)(Object *)*/ );

    static void Display(Dtor)(Display *) ;

    static cstring Display(Type)(void);

    static ctorPtr Display(Ctor)(void);

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static int CurrentConditions(Display)( CurrentConditions * );

    static int Forecast(Display)( Forecast * );

    static int HeatIndex(Display)( HeatIndex * );

    static int Statistics(Display)( Statistics * );


    static int Display(Null)( Object * ); //these last three are technical cases

    static int Display(Empty)( Object * );

    static int Display(Not)( Object * );

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void Display(Dtor)(Display * self)  {}

    explicit cstring Display(Type)(void){ return "Display"; }

    static void Display(Overload)( Object * );

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                        /// INTERFACE (CLASS TABLES) ///
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /**VIRTUAL TABLE OBJECT INTERFACE**/
    static Display(VirtualTable)
     /*  Class##Interface  */
        Display(Interface) =
    {
        {
            &Display(Type),

            &Display(Init),

            &Display(Dtor)
        }
    };
    explicit ctorPtr Display(Ctor)(void){ return new(Display); }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *  THIS IS FOR A FULLY DYNAMIC INSTANCE OF A Display OBJECT. *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

    static struct class (FactoryTable)
     ///Display * d = factory("Display")(this, ...)
        Display(Factory) =

    { &class(FactoryTable)(Type), &Display(Ctor), 0 };

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *   THIS IS ONE OF THE static TABLES NEEDED FOR 100% FULLY   *
     *                                                            *
     *   DYNAMIC PROGRAMMING. THIS TABLE (HEAP) IS USED BY A      *
     *                                                            *
     *   FACTORY METHOD AND COULD BE REPLACED BY A BUILDER VERSION*
     *                                                            *
     *   THAT IS DYNAMIC IN MORE WAYS (LIKE ITS SIZE)             *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    static Strategy

        Display(DisplayHeap)[four] =

    {   /**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z**/
        { "CurrentConditions",      &CurrentConditions(Display) },
        { "Forecast",               &Forecast(Display)          },
        { "HeatIndex",              &HeatIndex(Display)         },
        { "Statistics",             &Statistics(Display)        },

/**these were commented out because i have to figure out what order alphabetically**/
   /*   { "(null)",                 &Statistics(Display)        },
        { "(!instance)",            &Statistics(Display)        },   */

        { "", 0 }
    };
    static Strategy * typename(SubFactoryMethod) (Display,Strategy,Display,0,3) ;

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *   OVERLOAD FUNCTION FOR FUNCTION(S)                        *
     *                                                            *
     *   THIS IS AN ALTERNATIVE TO USING                          *
     *   A STRATEGIC FUNCTION POINTER                             *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void Display(Overload)

        ( Object * self )

    {  Strategy * p = Display(DisplaySearch) (typeid(self));

        if( p ){ return ((factPtr)p->val)(self); }//NotAWeatherStationObserverType
        else { throw( new(Exception) )(this, "NotAnOverloadDataType");  } }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
   # define classDisplayHeap(Member)classDisplayHeap ## Member
    static cstring class(DisplayHeap)(Type)(void);

    static struct class(StrategyHeap)

        Display(Display) =

    { &class(StrategyHeap)(Type),//&class(DisplayHeap)(Type),

      &Display(DisplaySearch),

/*& X*/Display(DisplayHeap) }; /** REMEMBER ITS AN AUTOMATIC ARRAY **/

  explicit cstring class(DisplayHeap)(Type)(void)
    { return "class(DisplayHeap)"; }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *   THIS IS A SUB-FACTORY METHOD FOR THE METHODS TABLE       *
     *                                                            *
     *   USED BY v(obj)->meth(this,...)                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

    static Virtual

        Display(VirtualHeap)[three] =
    {
        {"dtor", 2, & Display(Dtor)},
        {"init", 1, & Display(Init)},
        {"type", 0, & Display(Type)},

        {"",0,0}
    };
    static Virtual * typename(SubFactoryMethod) (Display,Virtual,Virtual,0,2) ;


    static class(VirtualHeap)

        Display(Virtual) =

    {
        &class(VirtualHeap)(Type),

        &Display(VirtualSearch),

         Display(VirtualHeap)
    };


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *  THIS FUNCTION IS REQURED BY register(Class) ALONG WITH  *
     *                                                          *
     *  Display(Method) (Display(Setup))                        *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    static void typename(Setup)(Display) {}

    static void typename(Abort)(Display) {}

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     *  THIS IS THE CLASS FACTORY METHOD AKIN TO THE ONES FROM EARLIER,      *
     *                                                                       *
     *  BUT AS THE CLASS FACTORY METHOD, ALL OTHER FACTORY METHODS           *
     *                                                                       *
     *  ARE SUB-FACTORY METHODS TO THIS (FOR SEARCHING THE CLASS             *
     *                                                                       *
     *  INFO HEAP(S)).                                                       *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

    /**FACTORY TABLE CLASS INTERFACE HEAP**/
    static Interface Display(InterfaceHeap)[three] =
    /*A B C D E F G H I J K L M N O P Q R S T U V W X Y Z*/
    {   &Display(Factory),

        &Display(Display),//class(StrategyHeap)

        &Display(Virtual), /*..., */ nullptr };

    static Interface typename(ClassFactoryMethod)(Display,0,2);


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                            /// IMPLEMENTATIONS ///
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

                   /*  Class##Init  */
    explicit Display * Display(Init)( Display * self, ...

    /*Object * host, void(* display )(Object *)*/ )
    {
        if(!self) {return 0;}

        Stack * stack = control();

        self->self    = arg(stack, Object *);

        self->display = arg(stack, Object *);

        return self;   }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static int Display(Null)( Object * self ){}

    static int Display(Empty)( Object * self ){}

    static int Display(Not)( Object * self ){}

/**
    THIS IS WHAT THE typename FOR STRATEGY SEARCH (BINARY SEARCH) LOOKS LIKE:

    THE SEARCH FUNCTION ITSELF IS FOUND INSIDE Template/defineSearch.h


    typename(Search) /// ... moved to structclass.h
    (*//*macro implementation found inside basic define c vector file:

         defineSearch(type, equal, greater)  (moved to defineSearch.h)
        *//**
        Strategy,

        string(equal)(array[*mid].key,key.key),

        string(greater)(array[*mid].key,key.key)
    );
 */
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                        ///STRATEGY FUNCTION EXAMPLE///
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

     ///{ "",                       4 }/** SIZE AT FIRST POS - OR -  */
     ///{ "",                       0 }/** NULL TERMINATED AT THE KEY */

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     *                                                                       *
     *   THIS SEARCH FUNCTION SERVES THE PURPOSE OF BEING THE PLACE          *
     *                                                                       *
     *   WHERE AN AUTOMATIC PAIR VARIABLE IS DECLARED SO IT CAN BE           *
     *                                                                       *
     *   USED MANUALLY WITH THE FUNCTION THAT IS IMPLEMENTED TO TAKE         *
     *                                                                       *
     *   AN AUTOMATIC PAIR AND RETURN A POINTER TO A PAIR IN ITS MEMORY.     *
     *                                                                       *
     *   IT ALSO SERVES THE PURPOSE OF A SEARCH FUNCTION FOR A SINGLE TABLE  *
     *                                                                       *
     *   THATS A CONSTANT VALUE BEING PASSED INTO THE STRATEGY ARRAY         *
     *                                                                       *
     *   SEARCH FUNCTION AND IT SERVES THE PURPOSE OF STORING THE LENGTH     *
     *                                                                       *
     *   OF OUR STATIC TABLE (IN THIS CASE DisplayStrategyTable)             *
     *                                                                       *
     *                                                                       *
     *   THIS IS THE BASIC CONFIGURATION FOR A FACTORY OBJECT THAT USES      *
     *                                                                       *
     *   THE FACTORY TABLE. THE PREVIOUS EXAMPLE IS ADDED TO A STATIC        *
     *                                                                       *
     *   TABLE ITSELF THAT IS A TABLE OF AN INTERFACE TYPE THAT GIVES        *
     *                                                                       *
     *   ITS STRING DESCRIPTION FROM THE ADDRESS OF THE FUNCTION POINTER     *
     *                                                                       *
     *   AT ITS FIRST DATAFIELD POSITION.                                    *
     *                                                                       *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *                                                                       *
     *   THIS IS A BINARY SEARCH FOR A STATIC TABLE THAT IS MANUALLY         *
     *                                                                       *
     *   SORTED, SPECIFICALLY ONE FOR THE STRATEGY TABLE WHICH THIS          *
     *                                                                       *
     *   CLASS HAS THE RESPONSIBILITY OF FILLING OUT SINCE IT                *
     *                                                                       *
     *   USES A SINGLE STRATEGIC FUNCTION POINTER. HERE ARE ALL THE          *
     *                                                                       *
     *   AVAILABLE INITIALIZATIONS IN A SINGLE TABLE HERE. THESE KIND OF     *
     *                                                                       *
     *   STATIC CLASS-LEVEL TABLES GIVE THE PROGRAM THE OPPORTUNITY          *
     *                                                                       *
     *   TO BE FULLY DYNAMIC WHEN THEY ALL MAKE THEIR WAY UP TO ONE OF THE   *
     *                                                                       *
     *   VOLATILE PROGRAM-LEVEL TABLES SPECIFICALLY THE FACTORY TABLE.       *
     *                                                                       *
     *                                                                       *
     *   THIS SEARCH FUNCTION SERVES THE PURPOSE OF BEING THE PLACE          *
     *                                                                       *
     *   WHERE AN AUTOMATIC PAIR VARIABLE IS DECLARED SO IT CAN BE           *
     *                                                                       *
     *   USED MANUALLY WITH THE FUNCTION THAT IS IMPLEMENTED TO TAKE         *
     *                                                                       *
     *   AN AUTOMATIC PAIR AND RETURN A POINTER TO A PAIR IN ITS MEMORY.     *
     *                                                                       *
     *   IT ALSO SERVES THE PURPOSE OF A SEARCH FUNCTION FOR A SINGLE TABLE  *
     *                                                                       *
     *   THATS A CONSTANT VALUE BEING PASSED INTO THE STRATEGY ARRAY         *
     *                                                                       *
     *   SEARCH FUNCTION AND IT SERVES THE PURPOSE OF STORING THE LENGTH     *
     *                                                                       *
     *   OF OUR STATIC TABLE (IN THIS CASE DisplayStrategyTable)             *
     *                                                                       *
     *                  STATIC STRATEGY TABLE PLUS SEARCH:                   *
     *                                                                       *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                    //Display(SearchStrategy)


    explicit Method * display( cstring key )
    {   Strategy * p = Display(DisplaySearch)(key);
        if( p ){ return p->val; }else{ throw(new(NotFound))
            (this, "NotAnOverloadCase", key); } }


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///



/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

        //was Observer * but better with Object * so it can be used
        //with any object and is identical to Command then, only
        //Commands would come in sets of two or three i thought
        //but at the same time there is Error printing with Console
        //and File printing so Displays should come in sets of two or three

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

#endif // DISPLAY_H_INCLUDED

