#ifndef DEFINEPIZZA_H_INCLUDED
#define DEFINEPIZZA_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    //#include "PizzaFactory.h"
    /**
     * @author willy (01/23/2022)
     *
     *         Class##List
     */
    #define Pizza(City, Type, Member)          City##Type##Pizza##Member

    #define definePizza(City, Type) \
    \
        typedef struct Pizza( City, Type, )\
        {   Pizza base;\
    \
            /*Container * toppings;*/\
            /*
                what if the Tokens used were data types themselves?

                (City, Type)

                especially Type should be a Topping or Recipe Type

                i would prefer Recipe over a single ingredient

                or whatever. (either way)


                Type recipe;

                //Type topping;

                in my opinion a recipe Type should be a base Recipe

                that contains a Container * for Toppings

                or toppings (not an interface type then: toppings)

                then a Recipe is used here for its Container toppings

                Type recipe; .. ... ... ... ... (in struct CityTypePizza)



                self->recipe->toppings-> ...    (in function)


                ... = virtual( self->recipe->toppings, Container )->at(this, ...);

                *virtual( self->recipe->toppings, Container )->at(this, ...) = ...
            */\
        }Pizza( City, Type, );\
    \
    \
        typedef struct Pizza( City, Type, VirtualTable )\
        {   PizzaVirtualTable base;\
        /**
            non-strategic functions are place here


        */\
        }Pizza( City, Type, VirtualTable );\
    \
        static Pizza( City, Type, ) * Pizza( City, Type, Init )\
    \
            ( Pizza( City, Type, ) *, ... );\
    \
        static void Pizza( City, Type, Dtor )( Pizza( City, Type, ) * );\
    \
        static cstring Pizza( City, Type, Type )() ;\
    \
    \
        explicit Pizza( City, Type, ) * Pizza( City, Type, Init )\
    \
            ( Pizza( City, Type, ) * self, ... )\
    \
            { if(!self){return 0;}\
    \
                /** ClassInit here */\
    \
                return self; } \
    \
    \
        explicit void Pizza( City, Type, Dtor )( Pizza( City, Type, ) * self ) {}\
    \
        explicit cstring Pizza( City, Type, Type )() { return #City #Type "Pizza"; }\
    \
    \
        static void Pizza( City, Type, Prepare )( Pizza * )   ;\
    \
        static void Pizza( City, Type, Bake )( Pizza * )    ;\
    \
        static void Pizza( City, Type, Cut )( Pizza * )   ;\
    \
        static void Pizza( City, Type, Box )( Pizza * )   ;\
    \
    \
        static Interface Pizza( City, Type, Heap ) ( cstring );\
    \
    \
        static Pizza( City, Type, VirtualTable ) \
                        /**ClassInterface here*/\
            Pizza( City, Type, Interface ) = \
        {/*City##Type##Pizza*/\
            { /*Pizza*/\
                { /*class(VirtualTable)*/\
                    &Pizza( City, Type, Type ), \
    \
                    &Pizza( City, Type, Init ), \
    \
                    &Pizza( City, Type, Dtor ) \
    \
                } ,\
    \
                    &Pizza( City, Type, Prepare ),\
    \
                    &Pizza( City, Type, Bake ),\
    \
                    &Pizza( City, Type, Cut ),\
    \
                    &Pizza( City, Type, Box ) \
            }\
        }  ;              \
    \
        /**
            THESE ARE THE BASIC COMPONENTS FOR A FACTORY TABLE CLASS BELOW

            THAT INCLUDES A BINARY SEARCH FOR A REGISTRATION LIST OF A SINGLE

            REGISTRATION. NEVERMIND ALL OF IT RIGHT NOW JUST TRY AND FOCUS ON

            JUST THE SINGLE LINE OF CODE BELOW. THAT IS WHERE A CLASS ENCAPSULATES

            ITS USE OF new (Class) INSIDE OF A FUNCTION THAT RETURNS THE

            CONSTRUCTORS DATATYPE ctorPtr. THAT IS ALL THAT IS NEEDED OF A

            FACTORY TABLE CLASS RIGHT NOW BUT AS OF NOW register(Class) IS BEING

            USED IN A PROGRAM CONSTRUCTOR AFTER typename(Class)(...) HOPEFULLY

            ALSO IN A PROGRAM CONSTRUCTOR (WHERE ALL THE FACTORY OBJECTS ARE)

            A FACTORY OBJECT IS A VIRTUAL TABLE OBJECT AND AN OBJECT OF

            A FACTORY TABLE CLASS. THIS WILL BE ALL THATS NEEDED AT LEAST FOR

            FULLY-DYNAMIC INSTANCES BUT NOT MUCH SUPPORT FOR MUCH ELSE

            FROM THE FACTORY TABLE. (FOR NOW) REMEMBER THAT THE FACTORY TABLE

            IS THE SINGLE MOST EXTENSIBLE TABLE OF THE 3 VOLATILE PROGRAM

            LEVEL TABLE (s). IT CAN BE CONSIDERED A DATATYPE TABLE FOR COMMON

            DATA TYPES AND AN OVERLOAD TABLE FOR FUNCTION OVERLOADS, LIKE

            class(VirtualHeap) AND class(CompareTable) AND class(ConsoleTable).

            ALLTHOUGH, USING THE VIRTUAL TABLE AND ADAPTER TABLE TOGETHER CAN

            BE USED IN CONJUNCTION WITH ONE ANOTHER TO SOLVE CERTAIN PROBLEMS

            WITHOUT THE FACTORY TABLE, ONLY WITH USING A RUNTIME STRING WITH THE

            FACTORY TABLES FACTORY METHODS TO ACCESS YOUR IMPORTANT POINTERS

            AND CLASS INFO IS A PROGRAM FULLY DYNAMIC AT RUNTIME.
        */\
        explicit ctorPtr Pizza( City, Type, Fact )() { return new(City##Type##Pizza); }\
    \
    \
        static struct class (FactoryTable)\
    \
            Pizza( City, Type, Factory ) = \
    \
        { &class(FactoryTableType), &Pizza( City, Type, Fact ), 0 };\
    \
    \
        static void Pizza( City, Type, Setup )();\
    \
        explicit void Pizza( City, Type, Setup )() {}\
    \
    \
        static void Pizza( City, Type, Abort )();\
    \
        explicit void Pizza( City, Type, Abort )() {}\
    \
    \
        static Interface Pizza( City, Type, InterfaceHeap )[one] = \
    \
        { & Pizza( City, Type, Factory ), nullptr };\
    \
    \
        explicit Interface typename(ClassFactoryMethod)(Pizza( City, Type, ),0,0);\
    \
    /**   JUST FUNCTION IMPLEMENTATIONS BELOW   **/\
    \
        explicit void Pizza( City, Type, Prepare )( Pizza * self )     {}\
    \
        explicit void Pizza( City, Type, Bake )( Pizza * self )        {}\
    \
        explicit void Pizza( City, Type, Cut )( Pizza * self )         {}\
    \
        explicit void Pizza( City, Type, Box )( Pizza * self )         {}



/**
    if i could make an observation that would be that: (Composite)

    as a design pattern could be used here for a Cheese Pizza

    versus a Deluxe Pizza where the Deluxe would be a Container

    or something acting as one (i know the Head First: Design Patterns

    book doesn't include Container but Container is the Factory C

    primary interface so i would recommend using it.) Cheese there

    for a CheesePizza wouldn't be a Container (so Composite)
 **/


#endif // DEFINEPIZZA_H_INCLUDED
