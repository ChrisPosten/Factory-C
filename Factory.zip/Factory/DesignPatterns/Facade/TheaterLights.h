#ifndef THEATERLIGHTS_H_INCLUDED
#define THEATERLIGHTS_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #define TheaterLights(Member)  TheaterLights##Member

    typedef struct TheaterLights
    {   struct class base;

        String * description;

    }TheaterLights;


    typedef struct TheaterLights(VirtualTable)
    {   struct class(VirtualTable) base;

        void (*on) ( TheaterLights * );

        void (*off)( TheaterLights * );

        void (*dim)( TheaterLights *, size_t );

        cstring () (*toString)( TheaterLights * );

    }TheaterLights(VirtualTable);


    static TheaterLights * TheaterLightsInit( TheaterLights *, String *, ... );

    static void TheaterLightsDtor( TheaterLights * );

    static cstring TheaterLightsType();


    explicit cstring TheaterLightsType(){ return "TheaterLights"; }


    static void TheaterLightsOn ( TheaterLights * );

    static void TheaterLightsOff( TheaterLights * );

    static void TheaterLightsDim( TheaterLights *, size_t );

    static cstring TheaterLightsToString( TheaterLights * );


    static TheaterLights(VirtualTable)

        TheaterLights(Interface) =

    {
        {
            &TheaterLightsType,

            &TheaterLightsInit,

            &TheaterLightsDtor
        },

        &TheaterLightsOn,

        &TheaterLightsOff,

        &TheaterLightsDim,

        &TheaterLightsToString
    };


    /**
     * @brief  init
     *
     * @param  self, desc
     *
     * @return *
     */
    explicit TheaterLights *

        TheaterLightsInit( TheaterLights * self,

        String * description, ... )
    {
        if( !self ){ return 0; }

        self->description = description;

        return self;
    }

    /**
     * @brief   destructor
     *
     * @param   self
     *
     * @return  void
     */
    explicit void

        TheaterLightsDtor( TheaterLights * self )
    {
        delete(self->description);
    }


    /**
     * @brief   on
     *
     * @param   self
     *
     * @return  void
     */
    explicit void TheaterLightsOn ( TheaterLights * self )
    {
        printf("%s is on\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief   off
     *
     * @param   self
     *
     * @return  void
     */
    explicit void TheaterLightsOff( TheaterLights * self )
    {
        printf("%s is off\n", virtual( self->description, String )

               ->toString(this));
    }

    /**
     * @brief   dim
     *
     * @param   self, level
     *
     * @return  void
     */
    explicit void TheaterLightsDim( TheaterLights * self, size_t level )
    {
        printf("%s dimming to %d%%\n", virtual( self->description, String )

               ->toString(this), level);
    }

    /**
     * @brief   toString
     *
     * @param   self
     *
     * @return  cstring (toString(this))
     */
    explicit cstring TheaterLightsToString( TheaterLights * self )
    {
        return virtual( self->description, String )

        ->toString(this) ;
    }

#endif // THEATERLIGHTS_H_INCLUDED
