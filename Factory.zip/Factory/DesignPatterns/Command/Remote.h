#ifndef REMOTE_H_INCLUDED
#define REMOTE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../../OOC/Control/Command.h"

    /**

            this is the Control interface implementation. an abstract

            version of this that would only be used for a pointer could

            be thought up and placed inside the OOC project folder



                                Command/Control



            the Control interface could have a couple Containers of Commands

            to start off. a problem that arises from this idea is how

            a Control interface could really be any kind of interface

            not just an interface with On/Off Commands but commands like

            Low/Med/High... (might be better to leave undefined)

    */



    Command() * RemoteOnCommands[8] = { -1,-1,-1,-1,-1,-1,-1,0 };

    Command() * RemoteOffCommands[8] = { -1,-1,-1,-1,-1,-1,-1,0 };

    typedef struct
    {   ///struct class base;
    }Remote;


    #define Remote(Member) Remote##Member
    typedef struct
    {   struct class (VirtualTable) base;

        void (*setCommand)(size_t, ...);

        void (*onButtonWasPushed)(size_t);

        void (*offButtonWasPushed)(size_t);

    }Remote(VirtualTable);


    static Remote * RemoteInit( Remote * );

    static void RemoteDtor( Remote * );

    static cstring RemoteType();


    explicit cstring RemoteType(){ return "Remote"; }


    static void RemoteSetCommand(size_t, Command() *, Command() * );

    static void RemoteOnButtonWasPushed(size_t);

    static void RemoteOffButtonWasPushed(size_t);


    static RemoteVirtualTable RemoteInterface =
    {
        {
            &RemoteType,

            &RemoteInit,

            &RemoteDtor
        },

        &RemoteSetCommand,

        &RemoteOnButtonWasPushed,

        &RemoteOffButtonWasPushed
    };


    explicit Remote * RemoteInit( Remote * self )

    { if(!self){return 0;}

        Command() * * pOn = RemoteOnCommands;

        Command() * * pOff = RemoteOffCommands;

        while( *pOn && *pOff )
        {
            *pOn = new(Command)(this, nullptr, &CommandDefault);

            *pOff = new(Command)(this, nullptr, &CommandDefault);

            pOn++; pOff++;
        }

      return self;}


    explicit void RemoteDtor( Remote * self )
    {
        Command() * * pOn = RemoteOnCommands;

        Command() * * pOff = RemoteOffCommands;

        while( *pOn && *pOff )
        {
            delete( *pOn );

            delete( *pOff );

            pOn++; pOff++;
        }
    }


    explicit void RemoteSetCommand

        (size_t slot, Command() * on, Command() * off )
    {
        delete ( RemoteOnCommands[slot] );

        delete ( RemoteOffCommands[slot] );

        RemoteOnCommands[slot] = on;

        RemoteOffCommands[slot] = off;
    }

    explicit void RemoteOnButtonWasPushed(size_t slot)
    {
        RemoteOnCommands[slot]

            ->execute( RemoteOnCommands[slot]->self );
    }

    explicit void RemoteOffButtonWasPushed(size_t slot)
    {
        RemoteOffCommands[slot]

            ->execute( RemoteOffCommands[slot]->self );
    }

#endif // REMOTE_H_INCLUDED
