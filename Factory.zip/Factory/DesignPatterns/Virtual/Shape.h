#ifndef SHAPE_H_INCLUDED
#define SHAPE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "../../OOC/Virtual/vTable.h"
    /**
        @brief BASIC OOP IN C (OOC) USING A VIRTUAL TABLE OBJECT.

        THIS EXAMPLE IS FOR THE BASIC CONFIGURATION OF AN INTERFACE

        TYPE THAT USES 3 EXTENDED CLASS TYPES THAT ALL DISPLAY THE

        USE OF THE DYNAMIC BINDING OF A BASE POINTER THAT POINTS

        TO DERIVED MEMORY IN A WAY THAT OBJECT-ORIENTED POLYMORPHISM

        IS ACHIEVED HERE USING SIMPLE INHERITANCE.


        WHAT THIS DOES NOT INCLUDE SO FAST BUT IS NEEDED FOR ANYONE

        WHO USES A STEPPING STONE, IS A FULL-SIZED FACTORY TABLE

        CLASS THAT USES A CLASS FACTORY METHOD WITH AN ASSEMBLY OF

        OTHER STATIC TABLES INCLUDING BUT NOT LIMITED TO AUTOMATIC

        ARRAYS THAT ARE GLOBAL LIKE THE CLASS VIRTUAL TABLE HERE.

        (THE CLASS VIRTUAL TABLE HERE MAY NOT HAVE A GLOBAL STRUCT

        VARIABLE FOR IT CONSIDERING AN INTERFACE TYPE OVER A CLASS

        TYPE BUT THE 3 CONCRETE STRUCT CLASSES WILL).


        THESE ARE GOOD FILES TO USE AS STEPPING STONES PAST OOC OR

        OOP IN C (OOC), INTO FACTORY C. FACTORY C USES SOMETHING

        DEFINED AND DECLARED AND IMPLEMENTED AS A FACTORY OBJECT.


        A FACTORY OBJECT IN (FACTORY) C IS NOT ONLY A VIRTUAL TABLE

        OBJECT BUT AN OBJECT OF A FACTORY TABLE CLASS. FROM THERE

        IS SUPPORT FOR ALL DYNAMIC RUN-TIME COMPONENTS OF FACTORY

        LEVEL C OBJECTS. SUPPORT FOR MULTIPLE INHERITANCE USING A

        UNION STACK OR STACK UNION. SUPPORT FOR FULLY DYNAMIC

        INSTANCES OF Objects INCLUDING FULLY DYNAMIC INSTANCES

        OF Adapters USING FACTORY REGISTRATIONS INSIDE THE FACTORY

        TABLE WITH THE AdapterTable AS A TABLE-OF-SELF-POINTER-DATA-

        MEMBERS. OR JUST BY USING factory("Class")(this, ...) INSTEAD

        OF new(Class). SUPPORT FOR FUNCTIONS THAT HAVE FULL CONTROL OVER

        THEIR DATATYPES THEY HAVE PASSED - IN A WAY THAT THE CENTRAL

        OVERLOAD FUNCTION FOR A SET OF FUNCTIONS HAS ACCESS TO EACH

        VERSION OF THAT FUNCTION FROM EACH FACTORY TABLE CLASS.

        DONT FORGET THAT ANY CENTRAL OVERLOAD FUNCTION IS A CENTRAL

        OVERLOAD FUNCTION AND NOT THE CENTRAL OVERRIDE METHOD ITSELF

        THAT IS CAPABLE OF A RUNTIME OVERRIDE ON ANY DATAFIELD

        POSITION OF ANY INTERFACE THAT IS OF A FACTORY TABLE Class,

        FOR THAT INTERFACE METHOD TO BE RE-INITIALIZED TO THE ADDRESS

        OF ANY OTHER FUNCTION IN THE PROGRAM THAT THE FACTORY TABLE

        HAS RUNTIME ACCESS TO FROM THE CLASS FACTORY METHOD FOR A

        CLASS... (OR WE CAN BE CREATIVE ABOUT SOMETHING ELSE OTHER

        THAN A CLASS)




        HERE WE HAVE BASIC OBJECT-ORIENTED PROGRAMMING THAT USES

        A VIRTUAL TABLE, IF vTable.h IS ALL THAT IS INCLUDED.




        THIS POLYMORPHISM EXAMPLE IS USING A STRATEGICALLY-INCLINED

        Class + Class(VirtualTable) FOR A VIRTUAL TABLE OBJECT.




        FROM HAVING AN AUTOMATIC STRUCT VARIABLE NAMED BASE AT THE

        FIRST DATA FIELD POSITION INSIDE STRUCT DERIVED. struct class base

        INSIDE SHAPE ITSELF IS NOT COMPLETELY NECESSARY BUT WORKS.

        struct class (VirtualTable) base IS NEEDED FOR EXTENSION TO

        HAVE A VIRTUAL TABLE OBJECT. A CLASS NAME BY typedef IS REQUIRED

        FOR BOTH. DONT FORGET TO USE: new, delete, this, typeid, virtual...



            Shape * shape = new(Square)(this, ...);

                virtual( shape, Shape ) -> ...

                printf( typeid(shape) );

            delete(shape);


        I WANT THIS EXAMPLE TO INCLUDE THE class(ConsoleTable) AND

        class(FactoryTable) FROM THE FACTORY TABLE CLASS SO:


            Shape * shape = factory("Square")(this, ...);

                virtual( shape, Shape ) -> ...

                cout("Shape: ")( shape )("\n");

            delete(shape);


        CAN BE THE BASIC OBJECT-ORIENTED PACKAGE FOR FACTORY C. ANY

        FURTHER IMPLEMENTATION OF A FACTORY TABLE CLASS WOULD INCLUDE

        A VIRTUAL HEAP (class(VirtualHeap)).


        SO:  multimap(true-false)()()(), (()function())() AND


        OVERLOAD FUNCTION(S) ARE SOME OF THE THINGS THAT REPLACE

        virtual() -> AS THE DEFAULT WAY OR THE VIRTUAL TABLES WAY TO

        ACCESS THE CLASS VIRTUAL TABLE ASSIGNED TO AN OBJECT.


        THIS IS FOR DYNAMIC INPUT-OUTPUT AND I FELT LIKE WE SHOULD

        THROW IN DYNAMIC INSTANCES. IF FACTORY C WAS TO FEEL LIKE

        A PROGRAMMING LANGUAGE NOT JUST A C LIBRARY THEN IT NEEDED

        SOMETHING TO REPLACE printf(). new()() IS THE SAME AS IT IS

        IN C++ SO I WANTED TO FOCUS ON THE FACTORY METHOD factory()()

        EARLY AND THE ACTUAL FACTORY METHOD EXAMPLE LIKE THE ONE

        FROM THE BOOK WILL INCLUDE MY SECURITY PATTERN USING A SET

        (OR SETS) OF KEYS.


     */
    #define Shape(Member)     Shape##Member /** COMPILER STRING TOKEN CONCAT ## */
    struct  Shape ;

    typedef struct Shape { struct class base; } Shape;

    typedef struct Shape (VirtualTable)  //always use automatic memory for
    {   struct class (VirtualTable) base;//base and make sure the base object
                                 //you create has struct class for a base
                                //if its going to be used by the vtable
        size_t () (*getArea)(Shape *); /// = 0 (pure abstract)
                              //if there is automatic memory for base
                             //at the first datafield position then the
                            //starting address of the derived object
    }Shape (VirtualTable);       //is the starting address of the base object
                          //nested inside derived and so a pointer
                         //pointing to derived memory can be passed into
                        //a function as base or derived

                       //update: struct class base is not needed for the
                      //         Class type only the Class(VirtualTable)
                     //          since primitives and arrays become vtable
                    //           objects.
  #if 0
    static Shape(VirtualTable) Shape(Interface) = {{0,0,0},0};///Runtime Interface
  #endif // 0



  #include "Square.h"

  #include "Rectangle.h"

  #include "Circle.h"


  //static


                                                         //CWP
#endif // SHAPE_H_INCLUDED
