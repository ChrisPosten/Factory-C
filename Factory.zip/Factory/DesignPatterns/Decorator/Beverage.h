#ifndef BEVERAGE_H_INCLUDED
#define BEVERAGE_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../../OOC/Virtual/vTable.h" //include OOP in C (OOC)
        /*         this includes:
        #include "new.h"
        #include "delete.h"
        #include "virtual.h"
        #include "what.h"

        #include "defineVector.h"
        #include "defineHashSet.h"

        #include "structclass.h"

        #include "Object.h"
        #include "Iterator.h"
        #include "Container.h" ...

            just to list the important ones,
        maybe include "Exception.h" or "vArray.h"
        or one of the data structure define macros
        other than the ones listed is all that
        needs to be included separately, oh and "String.h"
        */
    #include "../../OOC/Library/String.h"
        /*
            at the same time, if you are just implementing an
        interface itself, not implementing functions then
        all you need to include is "structclass.h" ...

        ... and make sure an automatic struct class variable is
        allocated at the first data field position inside
        the struct you make an object with, same goes with
        the parallel struct for the interface,
        struct class (VirtualTable) and call those parallel
        automatic variables base:
        */
   # define Beverage(Member)Beverage ## Member
    struct Beverage ;

    typedef struct Beverage Beverage;


    typedef struct Beverage (VirtualTable)
    {   struct class (VirtualTable) base;

        String * (*getDescription)(Beverage *);

        double () (*cost)(Beverage *);

    } Beverage (VirtualTable);


    struct Beverage
    {   struct class base;

        String * description;

        /*Beverage * self; //moved from decorator*/
    };


    static Beverage * Beverage(Init)(Beverage *, ...);

    static void Beverage(Dtor)(Beverage *);

    static cstring Beverage(Type)(void);


    explicit void Beverage(Dtor)(Beverage * self){delete(self->description);}

    explicit cstring Beverage(Type)(){return"Beverage";}


    static String * Beverage(GetDescription)(Beverage *);

    static void printBeverageDescription( String * ) ;


    static Beverage(VirtualTable) Beverage(Interface) =
    {
        {
            & Beverage(Type),

            & Beverage(Init),

            & Beverage(Dtor)
        },

        & Beverage(GetDescription),

        0//cost()- -CONSIDER THIS AN ABSTRACT CLASS- -virtual double cost()=0;(Factory C)
    };


    explicit Beverage * BeverageInit(Beverage * self, ...)
    {
        if( !self ) { return 0; }

        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        self->description = new(String)(this, 2, "\"Unknown Beverage\"");   ///
        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        if(!self->description){ return nullptr; }   /// /// /// /// /// /// ///
        /// /// /// --DONT TOUCH--  /// /// /// /// /// /// /// /// /// /// ///
        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /**self->self = nullptr**/ ;///--DONT TOUCH-- /// --DONT TOUCH -- /// ///
        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /// --DONT TOUCH--  /// /// /// /// --DONT TOUCH -- /// /// /// /// ///
        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * this self pointer is for loop termination while deallocating so DONT TOUCH  *
         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
           //update: the self pointer was moved to the adapter table

        return self;
    }                                             //shouldn't give it a constructor
                                                 //or interface because not fully
                                                //implemented but whatever, since
                                               //it has both things new(Beverage)(this);
                                              //works fine just the class has zeros in
                                             //its instance of a class (VirtualTable)
                                            //is all. (don't create an instance) "Unknown Beverage"

                                          //allocating an object here

    explicit String * BeverageGetDescription(Beverage * self)
    {
        return new(String)(this, 1, self->description);
    }







    explicit void printBeverageDescription( String * self )
    {
        String (VirtualTable) * p = virtual(self, String);

        if( p )
        {
            printf("\n0x%x: %s\n", self, p->toString(this) );

            printf("0x%x->length: %d\n", self, ((Vector(char)*)self)->length );

            printf("0x%x->maxsize: %d\n\n",self,((Vector(char)*)self)->maxsize );
        }
        else
        {
            printf("\n0x%x: %s\n", 0, "No Description" );
        }




    }



/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * <library that defines void-Oriented essentials in C (Factory C)>  *
 *                                                                   *
 * Copyright (C) <2017 - 2022>  <Christopher Posten>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */

#endif // BEVERAGE_H_INCLUDED
