#ifndef CBOILER_H_INCLUDED
#define CBOILER_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**||             C CHOCOLATE BOILER SINGLETON            || *
     *                                                           *
     * ||                by Willy (02/11/2022)                || */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief  Reasons to use:                                   *
     *                                                           *
     *   1)  ...      fill(), drain(), boil()                    *
     *                                                           *
     *   2)  ...                                                 *
     *                                                           *
     *   3)  ...                                                 *
     *                                                           *
     *   4)  ...                                                 *
     *                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                    initial preparation                    */
    #include "../../OOC/OOC.h"

    #define ChocolateBoiler(Member)  ChocolateBoiler##Member

    #define cBoiler(Member)          cBoiler##Member
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                    implement base type                    */
    //typedef struct {} Chocolate ;

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*             central area (singleton interface)            */
    #ifndef CHOCOLATEBOILERSINGLETON
    #define CHOCOLATEBOILERSINGLETON 1 //true

        volatile static struct cBoiler * volatile cboiler = null;///singleton

        static bool                   fill(void);
        static bool                   drain(void); ///singleton "interface"
                                           ///more like general program
        #define   isEmpty()    cboiler->empty///components
        #define   isBoiled()   cboiler->boiled

        static bool      boil(void);

    #endif // CHOCOLATEBOILERSINGLETON
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /**
        THE NAMESPACE HAS BEEN RESERVED FOR MORE IMPORTANT THINGS

        WHEN IT COMES TO fill() AND empty() , BUT NOT boiled()

        HERE. IF THE NAMESPACE CHANGES THEN THAT MAY CHANGE, JUST

        NEEDED TO SAY, SINCE THE SINGLE MOST IMPORTANT THING ABOUT

        A SINGLETON IN MY OPINION, WAS SOMETHING NOT COVERED IN

        THE TEXTBOOK (Head First: Design Patterns) PROBABLY BECAUSE

        JAVA DOESNT HAVE FUNCTIONS AND MACROS ONLY METHODS CALLED

        FROM AN OBJECT. THE SINGLE MOST IMPORTANT THING IS HAVING

        GLOBAL FUNCTIONS OR MACROS (MACROS MOSTLY FOR vTable) THAT

        DONT USE A PARAMETER FOR THE OBJECT (SINGLETON) MAKING A

        SINGLETON A HIDDEN OBJECT THAT MAKES A SINGLETON FUNCTION

        OR MACRO A POWERFUL FUNCTION (OR MACRO) FOR THAT IT MIGHT

        NOT EVEN HAVE A PARAMETER AS IT USES AN OBJECT.


        fill() WAS CHANGER TO fillUp() ... (then changed back)


        THE SINGLETON WILL STILL HAVE AN OBJECT-ORIENTED INTERFACE

        AND MAY BE A VIRTUAL TABLE OBJECT ITSELF (BUT NOT LIKELY).


        THE OTHER SINGLE MOST IMPORTANT THING ABOUT THE SINGLETON

        AND A REASON WHY I IMPLEMENTED A C CHOCOLATE BOILER WAS

        USING THE LABEL volatile FOR SINGLETON SUPPORT OF

        MULTI-THREADING OR MULTI-THREADED PROGRAMMING. THIS C BOILER

        WAS, MORE THAN ANYTHING, A COPY-AND-PASTE FROM MY OWN

        CHOICE IMPLEMENTATION OF A SINGLETON HERE IN C, THE MODEL

        IMPLEMENTATION THAT EVERY OTHER SINGLETON IS BASED ON IN

        FACTORY C, THE VIRTUAL TABLE OR vTable (VirtualTable)


        CONSIDERING THAT, AND AT LEAST AFTER THE TEMPLATE PATTERN

        (NOT THE TEMPLATE METHOD FROM THE TEXTBOOK, BUT A PATTERN

        FOR DATA-STRUCTURES PRIMARILY, FOR, BUT NOT LIMITED TO) THE

        SINGLETON PATTERN IS ONE OF THE MOST ENTRENCHED AND FULLY

        DEVELOPED DESIGN PATTERNS USED IN FACTORY C (OOC)


        ALSO: THE TEMPLATE PATTERN CAN BE CONSIDERED BY SOME (AS I

        HAVE NOTICED RECENTLY) A PATTERN THAT YOU CAN CONSIDER ITS

        DEFINITION/IMPLEMENTATION TO BE FOR "POLYMORPHISM OF

        IMPLEMENTATIONS". WHEN THE VIRTUAL TABLE'S BASE TYPE IS

        OF A MACRO IMPLEMENTATION, USING THE TEMPLATE PATTERN,

        THE TEMPLATE (1) PATTERN WAS THE FIRST PATTERN TO BE COVERED,

        THEN SINGLETON (2), THEN VIRTUAL (3), THEN STRATEGY (4).

        IF STRATEGY WAS COVERED SOONER FOR ME THEN I WOULD HAVE

        HAD TO RE-IMPLEMENT THE VIRTUAL TABLE AT LEAST ONE LESS TIME.

        THINK OF THOSE AS MY OWN CHOICE OF WHAT I WOULD CONSIDER

        AS: *//* "FOUNDATIONAL PATTERNS" - author *//**
           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                          implement                        */
    volatile volatile volatile typedef struct cBoiler/**1 STRUCT NAME*/
    {   struct class base; bool empty; bool boiled;
    }ChocolateBoiler, cBoiler;/**2 CLASS NAMES*/


    volatile volatile typedef struct cBoiler(VirtualTable)
    {   struct class(VirtualTable) base;

        bool () (*fill) ( volatile cBoiler * volatile );

        bool () (*drain)( volatile cBoiler * volatile );

        bool () (*boil) ( volatile cBoiler * volatile );

    }ChocolateBoiler(VirtualTable), cBoiler(VirtualTable);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                      prototypes                           */
    static volatile cBoiler * volatile ChocolateBoiler(Init)

         ( volatile cBoiler * volatile, ... );

    static void ChocolateBoiler(Dtor)( volatile cBoiler * volatile );

    static cstring ChocolateBoiler(Type)()  ;

    static ctorPtr ChocolateBoiler(Ctor)();


    explicit cstring ChocolateBoiler(Type)(){ return "ChocolateBoiler"; }

    /** THESE SHOULD BE INCLUDED FOR SINGLETON TO BE CREATED IN

        A PROGRAM CONSTRUCTOR AND DESTROYED IN PROGRAM DESTRUCTOR
     */      ///Attribute((constructor)); ((or destructor))
    /** - - - - - - - - - - - - - - - - - - - - - - - - - - - - **/
    void ChocolateBoiler(Constructor)(void)attribute((constructor));

    void ChocolateBoiler(Destructor)(void)attribute((destructor));
    /** - - - - - - - - - - - - - - - - - - - - - - - - - - - - **/

    static bool ChocolateBoiler(Fill)

        ( volatile cBoiler * volatile );

    static bool ChocolateBoiler(Drain)

        ( volatile cBoiler * volatile );

    static bool ChocolateBoiler(Boil)

        ( volatile cBoiler * volatile );

    /** THESE ARE THE SINGLETON STYLE FUNCTIONS FOR ALLOCATING

        AN INSTANCE AND DEALLOCATING AN INSTANCE. EVERYTHING THING

        ELSE THAT IS HERE OTHER THAN WHAT U SEE BELOW (2 PROTOTYPES)

        IS FOR A VIRTUAL TABLE OBJECT THAT IS A CHOCOLATE BOILER.
     */
    /** - - - - - - - - - - - - - - - - - - - - - - - - - - - - **/
    static volatile cBoiler * volatile ChocolateBoiler(Allocator)

        ( volatile cBoiler * volatile * volatile );//...

    static volatile void ChocolateBoiler(Deallocator)

        ( volatile cBoiler * volatile * volatile );
    /** - - - - - - - - - - - - - - - - - - - - - - - - - - - - **/

    static void printChocolateBoiler(void);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                  declare static interface                 */
    static ChocolateBoiler(VirtualTable)

        ChocolateBoiler(Interface) =

    {
        {
            &ChocolateBoiler(Type),

            &ChocolateBoiler(Init),

            &ChocolateBoiler(Dtor)
        },

        &ChocolateBoiler(Fill),

        &ChocolateBoiler(Drain),

        &ChocolateBoiler(Boil)
    };     ///remember that the cBoiler is volatile here:
    explicit ctorPtr ChocolateBoiler(Ctor)(){return new(ChocolateBoiler);}

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief        chocolate boiler initializer                *
     *                                                           *
     *                      (constructor)                        *
     * @param                 n = size                           *
     *      case 0:                                              *
     *        cBoiler * b = new(ChocolateBoiler)(this, 0);       *
     *      case 1:                                              *
     *        cBoiler * b = new(ChocolateBoiler)(this, 1, obj);  *
     *                                                           *
     *  note: case 1 for copy constructor                        *
     *                                                           *
     *  also: ChocolateBoiler##Init concatenates to              *
     *        ChocolateBoilerInit using new                      *
     *                                                           *
     *   and: ChocolateBoiler##Interface                         *
     *        (both are required for new)                        *
     *                                                           *
     *   this is a factory constructor or factory function for   *
     *   a constructor, this function is used from the           *
     *   constructor pointer with new(Class) so it can be called *
     *   a constructor itself but it is an initializer first.    *
     *                                                           *
     *              - -  (singleton pattern)  - -                *
     *                                                           *
     *  - - as of right now, new(Class) will work for the        *
     *   chocolate boiler, if you dont want that, all u          *
     *   have to do is intentionally mis-label the initializer   *
     *   here so it is not ClassInit or ChocolateBoilerInit.     *
     *   so Class##Init inside new(Class) generates the name of  *
     *   an un-implemented function by compiler string concat    *
     *   and so therefore is a compiler error.              - -  *
     *  (might want to change or just get rid of ClassFact then) *
     *                                                           *
     * @return            chocolate boiler                       *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                     implement functions                   */
    explicit volatile cBoiler * volatile ChocolateBoiler(Init)

        ( volatile cBoiler * volatile self, ... )

    { if(!self) {return null;}

      Stack * stack = control();//factory function

      size_t c = arg(stack, size_t);//switch case

      switch(c) //factory constructor
      {
        case 0: //default constructor case
            self->empty   =  true;

            self->boiled  =  false;
        break;   //copy constructor case
        case 1:                                    ;//(chicken scratch)
            volatile cBoiler * volatile p =
                arg(stack, volatile cBoiler * volatile);

            self->empty   =  p->empty;

            self->boiled  =  p->boiled;
        break;
      }
      return self;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief         chocolate boiler destructor                *
     *                                                           *
     * @param     self                                           *
     *                                                           *
     *               - -   (singleton pattern)   - -             *
     *                                                           *
     * @return             chocolate boiler                      *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit volatile void ChocolateBoiler(Dtor)

        ( volatile ChocolateBoiler * volatile self )

    {}

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief         chocolate boiler fill                      *
     *                                                           *
     * @param     self                                           *
     *                                                           *
     *               - -   (singleton pattern)   - -             *
     *                                                           *
     * @return    void                                           *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit bool ChocolateBoiler(Fill)

        ( volatile cBoiler * volatile self )

    {
        if( !self->empty )
        {
            printf("\n invalid operation \n");

            return false;
        }
        else
        {
            self->empty   =  false;

            self->boiled  =  false;


            printf("\n filling boiler \n");


            return true;
        }
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief         chocolate boiler drain                     *
     *                                                           *
     * @param     self                                           *
     *                                                           *
     *               - -   (singleton pattern)   - -             *
     *                                                           *
     * @return    void                                           *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit bool ChocolateBoiler(Drain)

        ( volatile cBoiler * volatile self )

    {
        if( !self->empty && self->boiled )
        {
            self->empty = true;

            printf("\n emptying boiler \n");

            return true;
        }
        else
        {
            printf("\n invalid operation \n");

            return false;
        }
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief         chocolate boiler boil                      *
     *                                                           *
     * @param     self                                           *
     *                                                           *
     *               - -   (singleton pattern)   - -             *
     *                                                           *
     * @return    void                                           *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit bool ChocolateBoiler(Boil)

        ( volatile cBoiler * volatile self )

    {
        if( !self->empty && !self->boiled )
        {
            self->boiled = true;

            printf("\n boiling chocolate \n");

            return true;
        }
        else
        {
            printf("\n invalid operation \n");

            return false;
        }
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief           get instance of cBoiler                  *
     *                                                           *
     *   - - ( for __attribute__((constructor)) function) - -    *
     * @param             address of cboiler                     *
     * @return      new cBoiler if no existing one               *
     * - - consider cboiler as the only pointer passed here - -  *
     *                  - - for singleton - -                    *
     * - - if another pointer is declared and used for this - -  *
     *    - - function then it will cease being a singleton - -  *
     *- -but the pointer cboiler will still be of significance- -*
     *- - as what pointer is used for its singleton operations- -*
     *                - - and as an iterator - -                 *
     *            - - (see: central area in file) - -            *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*       redefine default prime to alter starting size       */
    explicit volatile cBoiler * volatile ChocolateBoiler(Allocator)

        ( volatile cBoiler * volatile * volatile pself )//...

    { if( *pself != null )
      { return *pself; }

        *pself = (cBoiler*)allocate(sizeof(cBoiler));
        if( *pself == null )
        { return null; }

          *pself = ChocolateBoiler(Init)(*pself);//default_prime
          if( *pself == null )
          { return null; }
            return *pself; }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief      destroy/destruct instance of cBoiler          *
     *      - - ( for __attribute__((destructor)) function) - -  *
     * @param             address of cboiler                     *
     * @return     void                                          *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit volatile void ChocolateBoiler(Deallocator)

        ( volatile cBoiler * volatile * volatile pself )

    {if(*pself == null){return;}

    ChocolateBoiler(Dtor)(*pself); deallocate(*pself); *pself = null;}

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   friend print cboiler                             *
     *                                                           *
     *-- friend function defined by general namespace practice,--*
     *--    not making a method of, and not using a methods    --*
     *-- default parameter: the self pointer function parameter--*
     *                                                           *
     * @param               address of cboiler                   *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** #1 reason friend function here not namespaced with Class */
    explicit void printChocolateBoiler(void)
    {
        if(cboiler)
        {
            printf("< < ChocolateBoiler > >\n\n");

            printf("Full:     %s\n", ( !isEmpty() ? "y" : "n" ) );

            printf("Boiled:   %s\n", ( isBoiled() ? "y" : "n" ) );
        }
        else
        {
            printf("< < NotConstructed > >\n\n");
        }
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/**#include "cBoiler.h"   ///everything needed to implement before main
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/*                          Program Entry Point                      *
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
void ChocolateBoiler(Begin)(void)   { ChocolateBoiler(New)(&cboiler); }
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
int main(void)
{
    fill();

    boil();

    drain();

    return 0;
}
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
void ChocolateBoiler(End)(void) { ChocolateBoiler(Destroy)(&cboiler); }
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*    clipboard

            - - this file can be used as a stepping stone for
                vTable, fTable, and aTable

            - -


            - -

    */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #include "fill.h"

    #include "drain.h"

    #include "boil.h"
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**
           _____             __  __                     __
          /\  __ `\         /\_\/\ \                   /\ \
       ___\ \ \/\ /_     ___\/_/_ \ \    ___   ____    \ \ \___
      / ___\ \  ___ `   / __`\/\ \ \ \  / __`\/\  _`\   \ \  __`\
     /\ \__/_ \ \__/\ \/\ \/\ \ \ \ \ \/\  __/_ \ \_/   _\ \ \/\ \
     \ \_____\ \______/\ \____/\ \_\ \_\ \_____\ \_\   /\_\ \_\ \_\
      \/_____/\/_____/  \/___/  \/_/\/_/\/_____/\/_/   \/_/\/_/\/_/

     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

                                                    //CWP
#endif // CBOILER_H_INCLUDED
