#ifndef TRASHBIN_H_INCLUDED
#define TRASHBIN_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<library that defines Object-Oriented essentials in C (Factory C)> *
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

             case 2:     ;                                       //|
                                                                //|
                /* note: these extra variable being declared */ //|
                /*       is supposed to help with the */        //|
                /*       function arguments stack. */           //|
                /* */                                           //|
                Method * _setup = stack(arg)(Method*);          //|
                Method * _abort = stack(arg)(Method*);          //|
                Object * heap = stack(arg)(Object*);            //|
                Interface intr = stack(arg)(Interface);         //|
                                                                //|
                                                                //|
                meth[2] = _setup;//setup                        //|
                meth[3] = _abort;//abort                        //|
                meth[4] = heap ;                                //|
                meth[5] = intr ;                                //|
                                                                //|
            break;                                              //|



  #if 0
    #define defineStkPrint(t)\
    \
        static int print##t##Stk( Stk(t) *, ... );\
    \
        explicit int print##t##Stk( Stk(t) * self, ... )\
        {\
            N(t) * node = ((Stk(t)*)self)->stktop;\
            while(   node   )\
            {printf("0x%x\n", (void*)node->info);\
                node = node->link;\
            }printf("\n\n");\
            printf( "height: %u\n\n", \
                Stk(t)(GetLength)( ((Stk(t)*)self)->stktop ) );\
            return 0;}
  #endif // 0
  #if 0
    static bool StandardResizeHelper( Object *, size_t ) ;

    explicit bool StandardResizeHelper( Object * self, size_t size )
    {
        String(Resize)( self, size );

        return ((Vector(char)*)self)->array + ((Vector(char)*)self)->length - 1;
    }
  #endif // 0

            register size_type save = (size_type)ConsoleIn(Object)[1];

            register size_type save = (size_type)ConsoleOut(Object)[1];
        /*
            ConsoleOut(Object)[1] += retval;
            if( default(0) ){ default(0) = false; }
            String(Resize)( ConsoleOut(Object),
                ConsoleOut(Object)[2] + (size_type)retval ) ;


            ConsoleOut(String) = ConsoleOut(Object)[0] + (size_type)(
            ConsoleOut(Object)[1] - 1 );

            return ConsoleOut(Object)[1] - (size_type)save;
         */


                                   /*(ConsoleOut(Object)[1] + retval) \
                                    >= ConsoleOut(Object)[2] - 1 ? StandardResizeHelper\
                                   (ConsoleOut(Object),ConsoleOut(Object)[2] + \
                                    ((((size_t)ConsoleOut(Object)[2]) / 2) / 2)) : \
                                    ConsoleOut(Object)[0] + (((size_t)ConsoleOut(Object)[1]) + retval),*/

                                   /*(ConsoleOut(Object)[1] + retval) \
                                    >= ConsoleOut(Object)[2] - 1 ? StandardResizeHelper\
                                   (ConsoleOut(Object),ConsoleOut(Object)[2] + \
                                    ((((size_t)ConsoleOut(Object)[2]) / 2) / 2)) : \
                                    ConsoleOut(Object)[0] + (((size_t)ConsoleOut(Object)[1]) + retval),*/



                /*if( !((Assertion*)*eTop())->cond )
                {
                    if( *((Object**)multimap(false)("struct(Bunker)")
                    ("class(SingletonTable)")[1])[
                    multimap(true)("struct(Bunker)")("class(ComplexHeap)")
                    (((Exception*)*eTop())->text)[1] ] == 0 )
                    {
                        throw(new(Exception))(this, "MemoryFailure");
                    }
                }*/

    #if 0
    {
        if(polymorphic)
        {   return ((compPtr*)multimap(false)
            (*polymorphic)("class(CompareTable)"))[2](a,b);
        }
        else
        {   if(string(equal)(typeid(a),typeid(b)))
            {   return ((compPtr*)multimap(false)
                (typeid(a))("class(CompareTable)"))[2](a,b);
            }
            else
            {   throw(new(IllegalOperation))
                (this, "TypeIDNotMatching\n"
                 "need:/t/t is_polymorphic(a,b)");
            }
        }
    }
    #endif // 0

      #if 0 // DEBUG
             if( self == vtable )
             { if( default(0) ){ default(0) = false; }
               return ((factPtr*)multimap(false)("VirtualTable")
             ("class(ConsoleTable)"))[1](self); }

             if( self == ftable )
             { if( default(0) ){ default(0) = false; }
               return ((factPtr*)multimap(false)("FactoryTable")
             ("class(ConsoleTable)"))[1](self); }

             if( self == atable )
             { if( default(0) ){ default(0) = false; }
               return ((factPtr*)multimap(false)("AdapterTable")
             ("class(ConsoleTable)"))[1](self); }

            return ((factPtr*)multimap(false)
            (typeid(self))
            ("class(ConsoleTable)"))
            [1](self);
      #else
            typename(ConsoleIn)( self, class(ConsoleTable) );
      #endif // DEBUG


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        COMMAND; CENTER;    COMMAND; CENTER;    COMMAND; CENTER;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief         SINGLETON COMPLEX METHOD(S)                *
     *- -these may be used by the struct bunker, class builder- -*
     *                       - - ... - -                         *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        COMMAND; CENTER;    COMMAND; CENTER;    COMMAND; CENTER;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #if 0
   # define Singleton(Member)Singleton ## Member
    except explicit Object * Singleton(Complex)
    (Object * self, cstring key, cstring id)
    { Complex * row = (Complex*)multimap(true)
        (key)("class(ComplexHeap)")(id);
      return self + ( row->val * row->col ) ; }


    except explicit Method * * Singleton(Function)
        (cstring key, cstring meth)
        {   return &( (Method * *) multimap(false)(key)(key) )
            [ ((virtual*)multimap(true)(key)
            ("class(VirtualHeap)")(meth))->val ] ; }
    #endif // 0
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    static void f01();     //data type extravaganza pt.1 (OOC)
    static void f02();     //data type extravaganza pt.2 (OOC)
    static void f03();     //Exception/Assertion (try/throw/catch)
    static void f04();     //Container/Iterator  (stack, vector, ...)
    static void f05();     //Virtual Object pt.1 (...)
    static void f06();     //Factory Object pt.2 (...)
    static void f07();     //Complex Object pt.3 (...)
    static void f08();     //testing (...)

    static void f09();     //testing (...)
    static void f10();     //testing (...)
    static void f11();     //vtabletesting
    static void f12();
    static void f13();
    static void f14();     //
    static void f15();
    static void f16();     //...testing
    explicit void c16()
    {}

    explicit void c17()
    {}

    explicit void c18()
    {}

    explicit void c19()
    {}

    explicit void c20()
    {}

    explicit void c21()
    {}

    explicit void c22()
    {}

    explicit void c23()
    {}

    explicit void c24()
    {}

    explicit void c25()
    {}

    explicit void c26()
    {}

    explicit void c27()
    {}

    explicit void c28()
    {}

    explicit void c29()
    {}

    explicit void c30()
    {}

    explicit void c31()
    {}

    explicit void c32()
    {}

    explicit void c33()
    {}

    explicit void c34()
    {}

    explicit void c35()
    {}

    explicit void c36()
    {}

    explicit void c37()
    {}

    explicit void c38()
    {}

    explicit void c39()
    {}

    explicit void c40()
    {}

    explicit void c41()
    {}

    explicit void c42()
    {}

    explicit void c43()
    {}

    explicit void c44()
    {}

    explicit void c45()
    {}

    explicit void c46()
    {}

    explicit void c47()
    {}

    explicit void c48()
    {}

    explicit void c49()
    {}

    explicit void c50()
    {}

    explicit void c51()
    {}

    explicit void c52()
    {}

    explicit void c53()
    {}

    explicit void c54()
    {}

    explicit void c55()
    {}

    explicit void c56()
    {}


        #define defineHeapNode(type)\
    \
        typedef struct HeapNode(type) HeapNode(type);\
    \
        struct HeapNode(type)\
        {\
            type             info;\
    \
            HeapNode(type) * left,\
                           * right;   };\
    \
    \
        static HeapNode(type) * newHeapNode(type)( type );\
    \
        explicit HeapNode(type) * newHeapNode(type)( type info )\
        { HeapNode(type) * self = (HeapNode(type)*)allocate \
          (sizeof(HeapNode(type)));\
          if( !self ){ return 0; }\
          self->left = 0;\
          self->right = 0;\
    \
          self->info\
           = info;\
          return(self); }


    static size_t HeapMax (size_t, size_t) ;


    #define defineHeap(type, equal, greater, comp)\
    \
        comp ;  \
    \
        typedef struct Heap(type)\
        {   Container base;\
    \
            HeapNode(type) * top;\
    \
            size_type length;\
    \
        } Heap(type);\
    \
        volatile static uint8_t Heap(type)(Imbalance) = 0 ;/*1*/\
    \
        typedef struct Heap(type)(VirtualTable)\
        {   Container(VirtualTable)base;\
    \
            size_type () (*height) ( Heap(type) * );/*[9]*/\
    \
            void (*balance)( Heap(type) * );/*[10]*/\
    \
            size_t imbalance;/*[11]*/\
    \
        }Heap(type)(VirtualTable); ; ;\
    \
    \
        typedef HeapNode(type) * p##type##HeapNode;\
    \
    \
        define(N)(pHeapNode(type));\
    \
        define(Iter)(pHeapNode(type), );\
    \
        define(Stk)(pHeapNode(type), );\
    \
    \
        static Heap(type) * Heap(type)(Init)( Heap(type) *, ... );\
    \
        static cstring typename(Type)(Heap(type));\
    \
        static void Heap(type)(Dtor)(Heap(type) *);\
    \
    \
        static ctorPtr Heap(type)(Ctor)();\
    \
    \
        static bool Heap(type)(Copy)(Heap(type) *, .../*const Heap(type) * */);\
    \
        static bool Heap(type)(Insert)(Heap(type) *, .../*type*/);\
    \
        static bool Heap(type)(Remove)(Heap(type) *, .../*type*/);\
    \
        static type * Heap(type)(Search)(Heap(type) *, .../*type*/);\
    \
        static size_type Heap(type)(Size)(Heap(type) *);\
    \
    \
        static Iter(pHeapNode(type)) * Heap(type)(Begin)(Heap(type) *);\
    \
    \
        static void Heap(type)(Balance)( Heap(type) * );\
    \
        static size_type Heap(type)(Height)( Heap(type) * );\
    \
        static type * Heap(type)(At)(Heap(type) *, .../*size_type*/);\
    \
    \
        static bool Heap(type)(Equal)(const Heap(type) *, const Heap(type) *); \
    \
        static bool HeapNode(type)(Equal)\
            (const HeapNode(type) *, const HeapNode(type) *);\
    \
    \
        static bool HeapNode(type)(Copy)(HeapNode(type) * *, HeapNode(type) *);\
    \
        static bool HeapNode(type)(Insert)(HeapNode(type) * *, type);\
    \
        static bool HeapNode(type)(Remove)(HeapNode(type) * *, type);\
    \
        static type * HeapNode(type)(Search)(HeapNode(type) * *, type);\
    \
    \
        static HeapNode(type) * HeapNode(type)(Min)(HeapNode(type) * *);\
    \
        static HeapNode(type) * HeapNode(type)(Max)(HeapNode(type) * *);\
    \
    \
        static size_type HeapNode(type)(Height)(HeapNode(type) *);\
    \
        static void HeapNode(type)(Balance)( HeapNode(type) * * );\
    \
        static void HeapNode(type)(Destroy)( HeapNode(type) * * );\
    \
    \
        static void HeapNode(type)(LeftRotate)( HeapNode(type) * * );\
    \
        static void HeapNode(type)(DoubleLeft)( HeapNode(type) * * );\
    \
        static void HeapNode(type)(RightRotate)( HeapNode(type) * * );\
    \
        static void HeapNode(type)(DoubleRight)( HeapNode(type) * * );\
    \
    \
        static void HeapNode(type)(InOrder)(HeapNode(type) *,\
            Stk(pHeapNode(type)) * );\
    \
    \
        static Heap(type)(VirtualTable)\
    \
            Heap(type)(Interface) = \
    \
        {\
            {\
                {\
                    & Heap(type)(Type),\
    \
                    & Heap(type)(Init),\
    \
                    & Heap(type)(Dtor)\
                },\
                & Heap(type)(Copy),\
    \
                & Heap(type)(Insert),\
    \
                & Heap(type)(Remove),\
    \
                & Heap(type)(Search),/*or (At)*/\
    \
                & Heap(type)(Size),\
    \
                & Heap(type)(Begin)\
            },\
            & Heap(type)(Height),\
    \
            & Heap(type)(Balance),\
    \
            0\
        };\
        explicit ctorPtr Heap(type)(Ctor)(){return new(Heap(type));}\
    \
    \
        explicit Heap(type) * Heap(type)(Init)\
    \
        ( Heap(type) * self, ... )\
        {\
            Stack * stack = control();\
    \
            size_t c = arg(stack, size_t);\
            switch(c)\
            {\
                case 0: \
                    self->top = nullptr;\
                    self->length = 0; \
                break;\
                case 1:   ;\
    \
                    Heap(type)* heap = arg(stack, Heap(type)*);\
    \
                    self->top = nullptr;\
                    self->length = 0; \
                    Heap(type)(Copy)(self, heap);\
                break;\
            }\
    \
        return self; }\
    \
    \
        explicit void Heap(type)(Dtor)(Heap(type) * self)\
        {\
            HeapNode(type)(Destroy)(&self->top); self->length = 0; }\
    \
    \
        explicit bool Heap(type)(Copy)(Heap(type) * self, .../*const Heap(type) * heap*/)\
        {\
            stack(control)();\
    \
            const Heap(type) * heap = stack(arg)(const Heap(type)*);\
    \
            if( self->top != nullptr )\
            {\
                HeapNode(type)(Destroy)(&self->top);\
                self->length = 0;\
            }\
            if( self != heap )\
            {\
                if( heap->top == nullptr )\
                {\
                    self->top = nullptr;\
                    self->length = 0;\
                }\
                else \
                {\
                    HeapNode(type)(Copy)( self->top, heap->top );\
                    self->length = heap->length;\
                }\
            }\
            return true;\
        }\
    \
    \
        explicit bool Heap(type)(Insert)(Heap(type) * self, .../*type info*/)\
        {\
            stack(control)();\
    \
            type info = stack(arg)(type);\
    \
            if( !HeapNode(type)(Insert)(&self->top, info) )\
            {\
                return false;\
            }\
            self->length++;\
    \
            HeapNode(type)(Balance)( &self->top );\
    \
            return true;\
        }\
    \
    \
        explicit bool Heap(type)(Remove)(Heap(type) * self, .../*type info*/)\
        {\
            stack(control)();\
    \
            type info = stack(arg)(type);\
    \
            if( !HeapNode(type)(Remove)(&self->top, info) )\
            {\
                return false;\
            }\
            self->length--;\
    \
            HeapNode(type)(Balance)( &self->top );\
    \
            return true;\
        }\
    \
    \
        explicit type * Heap(type)(Search)(Heap(type) * self, .../*type info*/)\
        {\
            stack(control)();\
    \
            type info = stack(arg)(type);\
    \
            return HeapNode(type)(Search)(&self->top, info);\
        }\
    \
    \
        explicit size_type Heap(type)(Size)(Heap(type) * self)\
        {\
            return self->length;\
        }\
    \
    \
        explicit Iter(pHeapNode(type)) * Heap(type)(Begin)(Heap(type) * self)\
        {\
            Stk(pHeapNode(type)) stk;\
            Stk(pHeapNode(type))(Init)(&stk);\
            HeapNode(type)(InOrder)( & stk, self->top );\
            return new(Iter(pHeapNode(type)))(this, stk.stktop);\
        }\
    \
    \
        explicit void Heap(type)(Balance)( Heap(type) * self )\
        {\
            HeapNode(type)(Balance)( &(self->top) );\
        }\
    \
    \
        explicit size_type Heap(type)(Height)( Heap(type) * self )\
        {\
            return 1 + HeapNode(type)(Height)(self->top);\
        }\
    \
        /* note: this is an extra override for the at() method.
         *       this is otherwise not used.
         *       an extra strategy heap might be nice for these
         *       then the factory table has access at runtime.
         */\
        explicit type * Heap(type)(At)(Heap(type) * self, .../*size_type index*/)\
        {\
            stack(control)();\
    \
            size_type index = stack(arg)(size_type);\
    \
            if( index >= self->length || index < 0 )\
            {\
                throw(new(OutOfBounds))(this, "Heap(" #type ")(Index)")\
            }\
            Stk(pHeapNode(type)) stk;\
            Stk(pHeapNode(type))(Init)(&stk);\
            HeapNode(type)(InOrder)( self->top, & stk );\
            return( Stk(pHeapNode(type))(At)( & stk, self->length - 1 - index ) );\
        }\
    \
    \
        explicit bool Heap(type)(Equal)\
            (const Heap(type) * self, const Heap(type) * heap)\
        {\
            return (self->top == nullptr && heap->top == nullptr)\
            || (self->top != nullptr && heap->top != nullptr &&\
            HeapNode(type)(Equal)(self->top, heap->top));\
        }\
    \
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    \
        explicit bool HeapNode(type)(Equal)\
            (const HeapNode(type) * lhs, const HeapNode(type) * rhs)\
        {\
    \
            const HeapNode(type) * * pnode = &lhs;\
            const type info = rhs->info;\
    \
            return( equal )/*equal( lhs->info, rhs->info )*/\
    \
            && (( lhs->left == nullptr && rhs->left == nullptr )\
    \
            || ( lhs->left != nullptr && rhs->left != nullptr \
    \
                && HeapNode(type)(Equal)( lhs->left , rhs->left ) ) )\
    \
            && (( lhs->right == nullptr && rhs->right == nullptr )\
    \
            || ( lhs->right != nullptr && rhs->right != nullptr \
    \
                && HeapNode(type)(Equal)( lhs->left , rhs->left ) ));\
        }\
    \
    \
        explicit bool HeapNode(type)(Copy)\
    \
            (HeapNode(type) * * pnode, HeapNode(type) * node)\
        {\
            if( node == nullptr )\
            {\
                (*pnode) = nullptr;\
            }\
            else \
            {\
                (*pnode) = newHeapNode(type)(node->info);\
                if( !(*pnode) ){ return false; }\
                HeapNode(type)(Copy)(&(*pnode)->left, node->left);\
                HeapNode(type)(Copy)(&(*pnode)->right, node->right);\
            }\
            return true;\
        }\
    \
    \
        explicit bool HeapNode(type)(Insert)\
    \
            (HeapNode(type) * * pnode, type info)\
        {\
            if( (*pnode) == nullptr )\
            {\
                (*pnode) = newHeapNode(type)(info);\
                /*length++;*/\
                return true;\
            }\
            else if( equal )/*node->info == info*/\
            {\
                return false;\
            }\
            else if( greater ) /*node->info > info*/\
            {\
                return HeapNode(type)(Insert)( &(*pnode)->left, info );\
            }\
            else/*if( node->info < info )*/\
            {\
                return HeapNode(type)(Insert)( &(*pnode)->right, info );\
            }\
        }\
    \
    \
        explicit bool HeapNode(type)(Remove)\
    \
            (HeapNode(type) * * pnode, type info)\
        {\
            if( (*pnode) == nullptr )\
            {\
                return false;\
            }\
            else if( greater )/*(*pnode)->info > info*/\
            {\
                return HeapNode(type)(Remove)( &(*pnode)->left, info );\
            }\
            else if( !equal && !greater )/*info > (*pnode)->info*/\
            {\
                return HeapNode(type)(Remove)( &(*pnode)->right, info );\
            }\
            else if( (*pnode)->left != nullptr && (*pnode)->right != nullptr )/*==*/\
            {\
                (*pnode)->info = HeapNode(type)(Min)( &(*pnode)->right )->info;\
                return HeapNode(type)(Remove)( &(*pnode)->right, (*pnode)->info );\
            }\
            else \
            {\
                HeapNode(type) * old = (*pnode);\
                (*pnode) = ( (*pnode)->left != nullptr )\
                ? (*pnode)->left : (*pnode)->right;\
                /*length--;*/\
                deallocate( old );\
    \
                return true;\
            }\
        }\
    \
    \
        explicit type * HeapNode(type)(Search)\
    \
            (HeapNode(type) * * pnode, type info)\
        {\
            if( (*pnode) == nullptr )\
            {\
                return nullptr;\
            }\
            if( equal )  /*node->info == info*/\
            {\
                return (*pnode);\
            }\
            if( greater )  /*node->info > info*/\
            {\
                return HeapNode(type)(Search)(&(*pnode)->left, info);\
            }\
            else \
            {\
                return HeapNode(type)(Search)(&(*pnode)->right, info);\
            }\
        }\
    \
    \
        explicit HeapNode(type) * HeapNode(type)(Min)(HeapNode(type) * * pnode)\
        {\
            if( (*pnode) == nullptr )\
            {\
                return nullptr;\
            }\
            if( (*pnode)->left == nullptr )\
            {\
                return (*pnode);\
            }\
            return HeapNode(type)(Min)(&(*pnode)->left);\
        }\
    \
    \
        explicit HeapNode(type) * HeapNode(type)(Max)(HeapNode(type) * * pnode)\
        {\
            if( (*pnode) == nullptr )\
            {\
                return nullptr;\
            }\
            if( (*pnode)->right == nullptr )\
            {\
                return (*pnode);\
            }\
            return HeapNode(type)(Max)(&(*pnode)->right);\
        }\
    \
    \
        explicit size_type HeapNode(type)(Height)(HeapNode(type) * node)\
        {\
            if( node == nullptr )\
            {\
                return 0; /* -1 */\
            } /*return 0 */\
            else \
            {\
                return 1 + HeapMax(\
                HeapNode(type)(Height)(node->left),\
                HeapNode(type)(Height)(node->right) );\
            }\
        }\
    \
    \
        explicit void HeapNode(type)(Balance)( HeapNode(type) * * pnode )\
        {\
            if( (*pnode) == nullptr )\
            {\
                return;\
            }\
            if( HeapNode(type)(Height)( (*pnode)->left ) - \
    \
                HeapNode(type)(Height)( (*pnode)->right )\
    \
               > Heap(type)(Imbalance) )\
            { /*height might still need to return - 1 (done)*/\
                if( (*pnode)->left ){if( HeapNode(type)(Height)( (*pnode)->left->left )\
    \
                   >= HeapNode(type)(Height)( (*pnode)->left->right ) )\
                {  /*rotatewithleftchild*/\
                    HeapNode(type)(LeftRotate)(pnode);\
                }\
                else \
                { /*doublewithleftchild*/\
                    HeapNode(type)(DoubleLeft)(pnode);\
                }}\
            }\
            else if( HeapNode(type)(Height)( (*pnode)->right )\
    \
               - HeapNode(type)(Height)( (*pnode)->left ) > Heap(type)(Imbalance) )\
            {\
                if( (*pnode)->right ){if( HeapNode(type)(Height)( (*pnode)->right->right )\
    \
                   >= HeapNode(type)(Height)( (*pnode)->right->left ) )\
                { /*rotatewithrightchild*/\
                    HeapNode(type)(RightRotate)(pnode);\
                }\
                else \
                { /*doublewithrightchild*/\
                    HeapNode(type)(DoubleRight)(pnode);\
                }}\
            }\
        }\
    \
    \
        explicit void HeapNode(type)(Destroy)( HeapNode(type) * * pnode )\
        {\
            if( (*pnode) == nullptr )\
            {\
                return;\
            }\
            HeapNode(type)(Destroy)(&(*pnode)->left);\
            HeapNode(type)(Destroy)(&(*pnode)->right);\
            deallocate( (*pnode) );/*dtor works in postorder*/\
            (*pnode) = nullptr;\
        }\
    \
    \
        explicit void HeapNode(type)(LeftRotate)( HeapNode(type) * * pk2 )\
        {\
            HeapNode(type) * k1 = (*pk2)->left;\
    \
            (*pk2)->left = k1->right;\
    \
            k1->right = (*pk2);\
    \
            (*pk2) = k1;\
        }\
    \
    \
        explicit void HeapNode(type)(DoubleLeft)( HeapNode(type) * * pk3 )\
        {\
            HeapNode(type)(RightRotate)(&(*pk3)->left);\
            HeapNode(type)(LeftRotate)(pk3);\
        }\
    \
    \
        explicit void HeapNode(type)(RightRotate)( HeapNode(type) * * pk2 )\
        {\
            HeapNode(type) * k1 = (*pk2)->right;\
    \
            (*pk2)->right = k1->left;\
    \
            k1->left = (*pk2);\
    \
            (*pk2) = k1;\
        }\
    \
    \
        explicit void HeapNode(type)(DoubleRight)( HeapNode(type) * * pk3 )\
        {\
            HeapNode(type)(LeftRotate)(&(*pk3)->right);\
            HeapNode(type)(RightRotate)(pk3);\
        }\
    \
    \
        explicit void HeapNode(type)(InOrder)(HeapNode(type) * node,\
    \
            Stk(pHeapNode(type)) * stk )\
        {\
            if( node == nullptr )\
            {\
                return;\
            }\
            HeapNode(type)(InOrder)( ( node->left ), (stk) );\
    \
            Stk(pHeapNode(type))(Push)( stk, node );\
    \
            HeapNode(type)(InOrder)( ( node->right ), (stk) );\
        }\
    \





    N(Except) * node = estk->stktop;

    while(node)
    {
        if( ((Assertion*) node->info )-> cond == false )
        {
            if( string(equal)( node->info->text, "vtable" ) ){  }
            if( string(equal)( node->info->text, "ftable" ) ){}
            if( string(equal)( node->info->text, "atable" ) ){}

            if( string(equal)( node->info->text, "vstk" ) ){}
            if( string(equal)( node->info->text, "estk" ) ){}
            if( string(equal)( node->info->text, "jstk" ) ){}

            if( string(equal)( node->info->text, "istk" ) ){}
            if( string(equal)( node->info->text, "pstk" ) ){}

            if( string(equal)( node->info->text, "cstk" ) ){}
            if( string(equal)( node->info->text, "fstk" ) ){}
            if( string(equal)( node->info->text, "mstk" ) ){}
            if( string(equal)( node->info->text, "tstk" ) ){}
            if( string(equal)( node->info->text, "hstk" ) ){}
            if( string(equal)( node->info->text, "(*struct(bunker))" ) ){}
            if( string(equal)( node->info->text, "(*class(builder))" ) ){}


            if( string(equal)( node->info->text, "vtable" ) ){if(!vtable){VirtualTable(Allocator)(&vtable,101);}}
            if( string(equal)( node->info->text, "ftable" ) ){FactoryTable(Allocator)(&ftable,123);}
            if( string(equal)( node->info->text, "atable" ) ){AdapterTable(Allocator)(&atable,7);}

            if( string(equal)( node->info->text, "vstk" ) ){vstk = Class(Stk)(Init)(allocate(sizeof(Stk(Class))));}
            if( string(equal)( node->info->text, "estk" ) ){estk = Except(Stk)(Init)(allocate(sizeof(Stk(Except))));}
            if( string(equal)( node->info->text, "jstk" ) ){jstk = Jump(Stk)(Init)(allocate(sizeof(Stk(Jump))));}

            if( string(equal)( node->info->text, "istk" ) ){istk = Interface(Stk)(Init)(allocate(sizeof(Interface(Stk))));}
            if( string(equal)( node->info->text, "pstk" ) ){pstk = Pass(Stk)(Init)(allocate(sizeof(Pass(Stk))));}

            if( string(equal)( node->info->text, "cstk" ) ){cstk = ControlFactory(Stk)(Init)
                                                            (allocate(sizeof(ControlFactory(Stk))));}
            if( string(equal)( node->info->text, "fstk" ) ){fstk = Flag(Stk)(Init)(allocate(sizeof(Flag(Stk))));}
            if( string(equal)( node->info->text, "mstk" ) ){mstk = Map(Stk)(Init)(allocate(sizeof(Map(Stk))));}
            if( string(equal)( node->info->text, "tstk" ) ){tstk = Type(Stk)(Init)(allocate(sizeof(Type(Stk))));}
            if( string(equal)( node->info->text, "hstk" ) ){hstk = Heap(Stk)(Init)(allocate(sizeof(Heap(Stk))));}
            if( string(equal)( node->info->text, "(*struct(bunker))" ) ){}
            if( string(equal)( node->info->text, "(*class(builder))" ) ){}

        }

    }


    #if 1
        static Security * Search(Security)

            ( Security *, const Security,

            size_type *, size_type, size_type );


        explicit Security * Search(Security)

            ( Security * array, const Security key,

            size_type * mid, size_type first, size_type last )
        {
            bool found = false;

            while( first <= last && !found )
            {


printf("f: %d, l: %d\n", first, last);

                * mid = (first + last) / 2;

                if( string(equal)

                    (array[*mid].key,key.key) )
                {
                    found = true;

                    break;
                }
                else
                {
                    if( first == 0 && last == 0

                       && !found )
                    {
                        return nullptr;
                    }
                    if( string(greater)

                        (array[*mid].key,key.key) )
                    {
                        last = *mid - 1;
                    }
                    else
                    {
                        first = *mid + 1;
                    }
                }
            }
            if( found )
            {
                return & array [*mid];
            }
            else
            {
                return nullptr;
            }
        }

    #else
    #if 0
        explicit Overstructor FactoryTable(Override)(bool flag)
        {if( string(equal)( (*pTop())->base.text, struct(Bunker)(ID)() ) )
         {
            Object * pass = pPop();
            deaccumulate(pass);//


                accumulate(InformationSecurity)(this, ...);


            bool * f = accumulate(bool)(this, flag);
            if( (*f) != flag ){ (*f) = flag; }//DEBUG (ASSERT)

            if( !fPush( f ) )///<---push flag
                { throw( new(OutOfMemory) )
                (this, "FlagStackFailure"); }//

         else{ throw(new(RestrictedAccess))
            (this, "/// RESTRICTED AREA ///"); }

          return overstructor; }
    #endif // SECURITY_PATTERN_RESTRICT_ACCESS 0
        #else
            while(iter)
            {
                /* note: reallocate
                 *
                 *       the problem with this was that reallocate, reallocates
                 *       to a different address so the runtime objects reallocated here
                 *       cease being virtual table objects
                 */
                *(Object**)iter->info =
                    reallocate(*(Object**)iter->info, bytes(key));

                if( !*(Object**)iter->info ){throw(new(OutOfMemory))
                    (this, "ObjectReallocationFailure");}

                ((Object***)iter->info)[0][ ( bytes(key) / sizeof(void*) ) - 1 ] = 0;

                iter = iter->link;
            }
        #endif // 1 WORKS_WHILE_DEBUGGING ?

#if 0
 void FactoryTable(Constructor)(void)

 { FactoryTable(Allocator)(&ftable,71); Assert( ftable );///#3 (table)


    if( 1 ){ new(Assertion)(this, assert( ftable )); } //

    if( !mstk ){mstk = Map(Stk)(Init)(allocate(sizeof(Map(Stk))));}///#7 (stack)
    if( 1 ){ new(Assertion)(this, assert( mstk )); } //

    if( !fstk ){fstk = Flag(Stk)(Init)(allocate(sizeof(Flag(Stk))));}///#8 (stack)
    if( 1 ){ new(Assertion)(this, assert( fstk )); } //

    if( !tstk ){tstk = Type(Stk)(Init)(allocate(sizeof(Type(Stk))));}///#9 (stack)
    if( 1 ){ new(Assertion)(this, assert( tstk )); } //

    if( !hstk ){hstk = Class(Stk)(Init)(allocate(sizeof(Class(Stk))));}///#10 (stack)
    if( 1 ){ new(Assertion)(this, assert( hstk )); } //


    register(FactoryTable);

    register(VirtualTable);

    register(AdapterTable);




    register(String); // register(Vector(char));


    register(intmax_t);  register(intmax_t);//DOES NOTHING 2ND TIME
                            ///(check for return true or false also if desired)




    /*
    consider adding Container/Iterator with virtual heaps,
    factory heaps, just no factory table *//**register(Container);

                                              register(Iterator);**//*

    consider this including the stacks, so implement them as factory
    table classes (minimal ones) starting with class(FactoryTable)

    register(Stk(Class))
    register(Stk(Jump))
    register(Stk(Map))
    register(Stk(Flag))
    register(Stk(Interface))
    register(Stk(Pass))
    register(Stk(ControlFactory))           +7

    register(Stk(Type));
    register(Stk(Heap));
    register(Stk(Except));                  +3 = 10


    if you get the time you can do this, ...

    all the Exceptions/Assertions/Certificates

                                    +10 or more */

    register(Exception);           register(OutOfBounds);

    register(OutOfMemory);         register(NullPointer);

    register(EmptyString);         register(IllegalOperation);

    register(InputMismatch);       register(RestrictedAccess);

    register(PassNumber);          register(Override);

    register(NotFound) ;           register(Assertion) ;

    register(InformationSecurity);

    /*register(TypeInfo);          register(IsPolymorphic)*/

                                    /*


    Factory/Command array            +2  */register(Command);/*



    StrategicCommand                 +1

    string                           +1

    File                             +1 (of course)   */register(File);/*

    hash table bases, vector bases,  +6 or more +Iterators +6

    all the Heaps                    +8

    (all the Heap types)             +8 NO . . . (yes?) +1 Adapter +1 Interface

    Heap Array Types (YES)   ACTUAL ARRAY DATATYPE TABLE +10-1(Command)-1(Factory)
                                    ____
                                     +36 (estimate)(still)(or 44)

    jumpBuf                          +45
     */


register(int8_t);   register(int16_t);  register(int32_t);  register(int64_t);

register(uint8_t);  register(uint16_t); register(uint32_t); register(uint64_t);// +8


    register(size_t);                                                          // +1


    register(int);

    register(char);     register(bool);

    register(short);    register(long);

    register(unsigned); register(signed);

    register(float);    register(double);                                     // +9


    register(uintmax_t);

    register(wctype_t); register(wchar_t) ;






    register(intptr_t); register(uintptr_t);                                 // +2



    register(clock_t); register(time_t);                                     // +2 (missing string, File...)


 register(atomic_ulong);    register(atomic_llong);   register(atomic_ullong);

 register(atomic_wchar_t);  register(atomic_long);    register(atomic_uint);

 register(atomic_uintptr_t);register(atomic_size_t);  register(atomic_ptrdiff_t);

 register(atomic_char16_t); register(atomic_intmax_t);register(atomic_uintmax_t);

 register(atomic_intptr_t); register(atomic_bool);    register(atomic_char32_t);

 register(atomic_int);      register(atomic_char);    register(atomic_short);

 register(atomic_schar);    register(atomic_uchar);   register(atomic_ushort); //+3 x +7 = +21


        //register(Display);//same as Command just display() not execute()

        ///register(Command) if u want it
 }
/// + fully-dynamic instances support + central overload functions support +
/// + central override method support + multiple inheritance support +
/// + dynamic IO support + assign a factory method with interface heap to a class +
/// + complex object (class builder) support + fully dynamic programming +

 void StrategicCommand(01)(void)
 {
      if( !pstk ){pstk = Pass(Stk)(Init)(allocate(sizeof(Pass(Stk))));}///#5 (stack)
      if( 1 ){ new(Assertion)(this, assert( pstk )); } //Pass (break)


      if( !cstk ){cstk = ControlFactory(Stk)(Init)
        (allocate(sizeof(ControlFactory(Stk))));} ///#6 (stack)
      if( 1 ){ new(Assertion)(this, assert( cstk )); }
 }

/// + control pattern for commands + control pattern for control structures +
/// + control pattern for factory functions + control pattern for IO +
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

 void AdapterTable(Constructor)(void)
 { AdapterTable(Allocator)(&atable,7);///#2 (table)

      if( 1 ){ new(Assertion)(this, assert( atable )); }

      if( !istk ){istk = InterfaceStkInit(allocate(sizeof(InterfaceStk)));}///#4 (stack)
      if( 1 ){ new(Assertion)(this, assert( istk )); }

 }//
///       + support for extra interfaces per class implementation (adapters) +
/// + support for invisible object adapters + support for observers (many-to-one adapter) +
///      + support for decorators (recursive stackable adapter) +
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

 void VirtualTable(Constructor)(void)//7
 { VirtualTable(Allocator)(&vtable,101);///#1 (table) //important first table

      if( !vstk ){vstk = Class(Stk)(Init)(allocate(sizeof(Stk(Class))));}Assert( vstk );///#1 (stack)
      if( 1 ){ new(Assertion)(this, assert( vstk )); } //(first stack) <--see this (vPop())

      if( 1 ){ new(Assertion)(this, assert( vtable )); }

      if( !jstk ){jstk = Jump(Stk)(Init)(allocate(sizeof(Stk(Jump))));}///#2 (stack)
      if( 1 ){ new(Assertion)(this, assert( jstk )); } //Exception (for try/catch)

      if( !estk ){estk = Except(Stk)(Init)(allocate(sizeof(Stk(Except))));}///#3 (stack)
      if( 1 ){ new(Assertion)(this, assert( estk )); } //Assertion Stack (Exception Certificate)

 } /*101*///
/// + memory management support + constructor support + destructor support +
/// + assign an interface to each object + type id foreign key at factory table
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

 void FactoryControl(01)(void)       { ControlFactory(Setup)();//first for factory function
 }
/// + full control of the function arguements stack for the factory function + overloads +

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
 void VirtualTable(Destructor)(void) { VirtualTable(Deallocator)(&vtable);

       if( vstk ){deallocate(vstk);vstk=0;}//#1

       if( jstk ){deallocate(jstk);jstk=0;}//#2

       if( estk ){deallocate(estk);estk=0;}//#3
 }//
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
 void AdapterTable(Destructor)(void) { AdapterTable(Deallocator)(&atable);

      if( istk ){deallocate(istk);istk=0;}//#4
 }//
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
 void StrategicCommand(02)(void) {

      if( pstk ){deallocate(pstk);pstk=0;}//#5

      if( cstk ){deallocate(cstk);cstk=0;}//#6
 }
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
 void FactoryTable(Destructor)(void) { FactoryTable(Deallocator)(&ftable);

      if( mstk ){deallocate(mstk);mstk=0;}//#7

      if( fstk ){deallocate(fstk);fstk=0;}//#8

      if( tstk ){deallocate(tstk);tstk=0;}//#9

      if( hstk ){deallocate(hstk);hstk=0;}//#10
 }//



    /*#if 1 // 1 DEBUG
     explicit int printFactoryTable(FactoryTable * self)

     { size_t i = 0, i2 = 0, i3 = 0, count = 0, colCount = 0, length;
         for(i2 = 0; i2 < ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->maxsize; i2++) //
        { if(((Vector(ClassNameClassFactoryMethodPair)*)
                self)->array[i2].key != nullptr)
            {count++; length = string(size)(((Vector
                    (ClassNameClassFactoryMethodPair)*)
                    self)->array[i2].key);
                printf("\"%s\"", ((Vector
                    (ClassNameClassFactoryMethodPair)*)
                    self)->array[i2].key);
                for( size_t index = 0; index <= 30 - length - 2; index++ )
                { printf(" "); }
            }else{printf("\"\"");
                for( size_t index = 0; index <= 30 - 3; index++ )
                { printf(" "); }
            } colCount++;
            if(colCount == 4){ puts("\n"); colCount = 0; }
        }puts("\n\n\n");


        printf("maxsize:  %d\n",
               ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->maxsize); //
        printf("length:   %d\n",
               ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->length);   //
        return 0;}
    #else*/
  #if 0

    volatile typename(Iterator)(ClassClassVirtualTablePair);

    volatile typename(BasicVector)(ClassClassVirtualTablePair, );

    volatile  typename(AbstractHashSet)(ClassClassVirtualTablePair, Bits, );/**...**/

    ///DUBUG VERSION (VTABLE)
/*
    \
        comp /*defineBasicVector(ClassClassVirtualTablePair, comp);* /\
    \
        typedef struct ClassClassVirtualTablePair##HashSet##32 \
        {   Vector(ClassClassVirtualTablePair) base;\
    \
            uint##32##_t () (*hash)( uint##32##_t , ... );/* strategic * /\
    \
        }ClassClassVirtualTablePair##HashSet##32;\
    \
    \
        typedef struct ClassClassVirtualTablePair##HashSet##32##VirtualTable \
        {   ClassClassVirtualTablePair##VectorVirtualTable base;\
    \
            ClassClassVirtualTablePair * (*search)( const struct ClassClassVirtualTablePair##HashSet##32 *, /**type,** / ... );\
    \
            size_type () (*findsize)( size_type );\
    \
        }ClassClassVirtualTablePair##HashSet##32##VirtualTable;\
    \
    \
        typedef size_type ClassClassVirtualTablePair##HashSet##32##SizeType;\
    \
    \
        static ClassClassVirtualTablePair##HashSet##32 * ClassClassVirtualTablePair##HashSet##32##Init( ClassClassVirtualTablePair##HashSet##32 *, ... );\
    \
        static void ClassClassVirtualTablePair##HashSet##32##Dtor( ClassClassVirtualTablePair##HashSet##32 * ); \
    \
        static cstring ClassClassVirtualTablePair##HashSet##32##Type();\
    \
    \
        static void ClassClassVirtualTablePair##HashSet##32##InitArray( ClassClassVirtualTablePair##HashSet##32 * );\
    \
        static bool ClassClassVirtualTablePair##HashSet##32##Resize( ClassClassVirtualTablePair##HashSet##32 *, size_type );\
    \
        static bool ClassClassVirtualTablePair##QuadraticProbe##32##Insert( ClassClassVirtualTablePair##HashSet##32 *, ClassClassVirtualTablePair );\
    \
        static bool ClassClassVirtualTablePair##QuadraticProbe##32##Remove( ClassClassVirtualTablePair##HashSet##32 *, ClassClassVirtualTablePair );\
    \
        static ClassClassVirtualTablePair * ClassClassVirtualTablePair##QuadraticProbe##32##QProbe( ClassClassVirtualTablePair##HashSet##32 *, ClassClassVirtualTablePair );\
    \
        static size_ClassClassVirtualTablePair findPrime##32##Bit( size_type );\
    \
    \
        explicit cstring ClassClassVirtualTablePair##HashSet##32##Type(){ return "HashSet(" "ClassClassVirtualTablePair" "," "32" ")" ; }


    \
        typename(HashSetInitArray)(ClassClassVirtualTablePair, Bits, (*self).base.array[ count ].key = 0;\
                                                       (*self).base.array[ count ].val = 0;\
        );\
        typename(HashSetResize)(ClassClassVirtualTablePair, Bits,    (*iter).key,\
    \
                                                       (*p).key,\
    \
                                                       (*p).key = (*iter).key;\
                                                       (*p).val = (*iter).val;,/*pointer copy (assign)* /\
    \
                                                       (*p).key == (*iter).key\
        );\
        typename(HashSetAdd)(ClassClassVirtualTablePair, Bits,       (*p).key,\
    \
                                                       (*p).key = info.key;\
                                                       (*p).val = info.val;,/*pointer copy (assign)* /\
    \
                                                       (*p).key == info.key\
        );\
        typename(HashSetRemove)(ClassClassVirtualTablePair, Bits,    (*p).key,\
    \
                                                       (*p).key = 0;\
                                                       (*p).val = 0;\
        );\
    \
        typename(HashSetQProbe)(ClassClassVirtualTablePair, Bits,    info.key,\
    \
                                                       self->base.array[probe].key == 0,\
    \
                                                       self->base.array[probe].key == info.key,\
    \
                                                       info.val != 0,\
    \
                                                       info.val == 0,\
    \
                                                       (*slot) = self->base.array[probe];\
                                                       self->base.array[probe].key = 0;\
                                                       self->base.array[probe].val = 0;,\
    \
                                                       /**defineHashSetQProbePrint* /; \
    \
        );*/
  #endif // 0




    static void c17();
    static void c18();
    static void c19();
    static void c20();
    static void c21();
    static void c22();
    static void c23();
    static void c24();

    static void c25();
    static void c26();
    static void c27();
    static void c28();
    static void c29();
    static void c30();
    static void c31();
    static void c32();

    static void c33();
    static void c34();
    static void c35();
    static void c36();
    static void c37();
    static void c38();
    static void c39();
    static void c40();

    static void c41();
    static void c42();
    static void c43();
    static void c44();
    static void c45();
    static void c46();
    static void c47();
    static void c48();

    static void c49();
    static void c50();
    static void c51();
    static void c52();
    static void c53();
    static void c54();
    static void c55();
    static void c56();

    /*
        & c17,& c18,& c19,& c20,& c21,& c22,& c23,& c24,
        & c25,& c26,& c27,& c28,& c29,& c30,& c31,& c32,
        & c33,& c34,& c35,& c36,& c37,& c38,& c39,& c40,
        & c41,& c42,& c43,& c44,& c45,& c46,& c47,& c48,
        & c49,& c50,& c51,& c52,& c53,& c54,& c55,& c56, nullptr
     */



    /*
    static int &HashSet(type,bits)
    (ConsoleOut)(type,bits)(HashSet(type,bits) * self, ...)
    {Stack * stack = control();

        size_type index = arg(stack, size_type);

        return printf cprint ;

    }


    static int &HashSet(type,bits)
    (StandardOut)(type,bits)(HashSet(type,bits) * self, ...)
    {Stack * stack = control();

        size_type index = arg(stack, size_type);

        return sprintf sprint ;

    }


    static int &HashSet(type,bits)
    (FileOut)(type,bits)(HashSet(type,bits) * self, ...)
    {Stack * stack = control();

        size_type index = arg(stack, size_type);

        return fprintf fprint ;

    }




    static int &HashSet(type,bits)
    (ConsoleOut)(type,bits)(HashSet(type,bits) * self, ...)
    {Stack * stack = control();

        size_type index = arg(stack, size_type);

        return scanf cscan ;

    }


    static int &HashSet(type,bits)
    (StandardOut)(type,bits)(HashSet(type,bits) * self, ...)
    {Stack * stack = control();

        size_type index = arg(stack, size_type);

        return sscanf sscan ;

    }


    static int &HashSet(type,bits)
    (FileOut)(type,bits)(HashSet(type,bits) * self, ...)
    {Stack * stack = control();

        size_type index = arg(stack, size_type);

        return fscanf fscan ;

    }
    */

    /*

        switch(c)
        {
            case 0:
                val = printf( self->array );
            break;
            default:
              if( !(*Flags[1]) ){flags(1);ControlSlot[0][0]=&self;}

                val = cin->vector->array[c - 1](self);///Template Method

              (*Flags[1]) = false;
            break;
        }



            val = scanf( "", self->array );///////////////////////

        switch(c)
        {
            case 0:
                val = scanf("%s", self->array);
            break;
            default:
              if( !(*Flags[1]) ){flags(1);ControlSlot[0][0]=&self;}

                val = cin->vector->array[c - 1](self);///Template Method

              (*Flags[1]) = false;
            break;
        }



        switch(c)
        {
            case 0:


            break;
            case 1:


            break;
            case 2:


            break;
            default:

            break;
        }

     */


    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    /**                                                          *
     * @brief  queue adapter interface                           *
     *                                                           *
     *                                                           *
     * @param                                                    *
     *                                                           *
     *                                                           *
     * @return                                                   *
     *                                                           */\
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    \
        static cstring Stack(AdapterTable)(Type)();\
    \
        static struct class (AdapterTable)\
    \
            Vector(type)(Stack) = \
        {\
            &Stack(AdapterTable)(Type),\
    \
            &Vector(type)(Init),\
    \
            &Stack(Vector(type))(Interface)\
        };\
      explicit \
        cstring Stack(AdapterTable)(Type)()\
    \
        { return "Stack(AdapterTable)"; }\
    \

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    /**                                                          *
     * @brief  stack adapter interface                           *
     *                                                           *
     *                                                           *
     * @param                                                    *
     *                                                           *
     *                                                           *
     * @return                                                   *
     *                                                           */\
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    \
        static cstring Stack(AdapterTable)(Type)();\
    \
        static struct class (AdapterTable)\
    \
            Vector(type)(Stack) = \
        {\
            &Stack(AdapterTable)(Type),\
    \
            &Vector(type)(Init),\
    \
            &Stack(Vector(type))(Interface)\
        };\
      explicit \
        cstring Stack(AdapterTable)(Type)()\
    \
        { return "Stack(AdapterTable)"; }\
    \


    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    /**                                                          *
     * @brief  comparable registration                           *
     *                                                           *
     *                                                           *
     * @param  self, object                                      *
     *                                                           *
     *                                                           *
     * @return true or false                                     *
     *                                                           */\
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    \
        /*explicit bool Vector(type)(Equal)\
    \
            ( const Vector(type) * self, \
              const Vector(type) * objt, ... )\
    \
        {\
            Stack * stack = control();\
    \
            const Vector(type) * objt\
    \
                = arg(stack, const Vector(type)*);\
    \
            if( self->length == objt->length )\
            {\
                return equal( self, objt );\
            }\
            else\
            {\
                return false;\
            }\
        }\
    \
        explicit bool Vector(type)(Greater)\
    \
            ( const Vector(type) * self, \
              const Vector(type) * objt, ... )\
    \
        {\
            Stack * stack = control();\
    \
            const Vector(type) * objt\
    \
                = arg(stack, const Vector(type)*);\
    \
            if( 1 )\
            {\
                return greater( self, objt );\
            }\
            else\
            {\
                return false;\
            }\
        }\
    \
        static struct class (CompareTable)\
    \
            Vector(type)(Compare) = \
    \
        { \
            &class(CompareTable)(Type), \
    \
            &Vector(type)(Equal), \
    \
            &Vector(type)(Greater) };*/\
    \

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    # define FactoryMethodArray(Member)FactoryMethodArray ## Member
      # define FactoryMethod(Member)FactoryMethod ## Member
        typedef     FactoryMethod * Array(FactoryMethod);    ///#8
        typename   (Array)    (FactoryMethod);
            /// /// /// /// /// /// /// /// /// /// /// ///
        typename (Search)                        ///FactoryMethod
        ( /*FactoryMethod*/          FactoryMethod,
            string(equal)(array[*mid].key,key.key),
            string(greater)(array[*mid].key,key.key)
        );typename(QSort)                    ///FactoryTableFunction
        (                       FactoryMethod,
            string(equal)( array[i].key,array[left].key ),
            string(greater)( array[i].key,array[left].key ),
            typename(Swap)(FactoryMethod)///+Security Key Set
        );  /// /// /// /// ///For Data Member Names/// ///

  #if 0
    # define defineBasic(Member)defineBasic##Member

    # define defineVirtual(Member)define##Member

    # define defineFactory(Member)defineFactory##Member
  #endif // 0

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief  FactoryMethod                                     *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
  #if 0/*                    FactoryMethod                       */
   # define FactoryMethodHeap(Member)FactoryMethodHeap ## Member
    #define FactoryMethodHeapNode(Member)FactoryMethodHeapNode ## Member

   # define pFactoryMethodHeapNode(Member)pFactoryMethodHeapNode ## Member

   # define pFactoryMethodHeapNodeN(Member)\
        pFactoryMethodHeapNodeN ## Member

    #define pFactoryMethodHeapNodeIter(Member)\
        pFactoryMethodHeapNodeIter ## Member

    #define pFactoryMethodHeapNodeStk(Member)\
        pFactoryMethodHeapNodeStk ## Member

    typename(Heap)                               ///             #8
    (FactoryMethod,//FactoryHeap
        /// /// /// ///
        string(equal)( ((*pnode)->info.key),///FactoryMethod
                     (info.key) ),
        /// /// /// ///
        string(greater)( ((*pnode)->info.key),
                     (info.key) ),
        /// /// /// ///
        typename(HeapNode)(FactoryMethod);///Factory Table Functions
    ) ;
    #if 1
        explicit int Heap(FactoryMethod)(ConsoleIn)
        (Heap(FactoryMethod) * self, ...){}
        explicit int Heap(FactoryMethod)(ConsoleOut)
        (const Heap(FactoryMethod) * self, ...){}

        explicit int Heap(FactoryMethod)(StandardIn)
        (Heap(FactoryMethod) * self, ...){}
        explicit int Heap(FactoryMethod)(StandardOut)
        (const Heap(FactoryMethod) * self, ...){}

        explicit int Heap(FactoryMethod)(FileIn)
        (Heap(FactoryMethod) * self, ...){}
        explicit int Heap(FactoryMethod)(FileOut)
        (const Heap(FactoryMethod) * self, ...){}
    #endif // 0 MUST_INCLUDE_AFTER_TYPENAME
    static void Heap(FactoryMethod)
    (CopyFromArray)( Heap(FactoryMethod) *, FactoryMethod * );

    static void HeapNode(FactoryMethod)
    (FactoryMethodDestroy)( HeapNode(FactoryMethod) * * );

    static void Heap(FactoryMethod)
    (FactoryMethodDtor)( Heap(FactoryMethod) * );
  #endif // 0

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        COMMAND; CENTER;    COMMAND; CENTER;    COMMAND; CENTER;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
  #if 0
        static void class(Builder)(FactoryMethodInfo)///#8(SUB)
        ( FactoryMethod *, ... );
        explicit void class(Builder)
        (FactoryMethodInfo)( FactoryMethod * self, ... )
        {Stack * stack = ControlSlot[0][0] ;
        Address val = stack(arg)(Address);
        Address end = stack(arg)(Address);
        self->val = val;
        self->end = end;}

        explicit void Heap(FactoryMethod)                        ///#8
        (CopyFromArray)( Heap(FactoryMethod) * self, FactoryMethod * p )
        {while( !string(equal)( p->key, "" ) )
         {
                    string str = (string)allocate(string(size)
                                                  (p->key)) ;
                    if( !str ){throw(new(OutOfMemory))
                        (this, "FactoryMethodKeyFailure");}
                    string(fill)(str, p->key);

                    ///...

                    FactoryMethod slot = { str, p->val, p->end };

                    if( !Heap(FactoryMethod)(Insert)(self, slot) )
                    {throw(new(Exception))
                    (this, "HeapInsertFailure");}

                    p++;}}

        explicit void HeapNode(FactoryMethod)
        (FactoryMethodDestroy)( HeapNode(FactoryMethod) * * pnode )
        {if( (*pnode) == nullptr )
         {
            return;
         }
            HeapNode(FactoryMethod)(FactoryMethodDestroy)(&(*pnode)->left);
            HeapNode(FactoryMethod)(FactoryMethodDestroy)(&(*pnode)->right);

                deallocate( (*pnode)->info.key );

            deallocate( (*pnode) );/*dtor works in postorder*/
            (*pnode) = nullptr;
        }
        explicit void Heap(FactoryMethod)
        (FactoryMethodDtor)( Heap(FactoryMethod) * self )
        {
            HeapNode(FactoryMethod)(FactoryMethodDestroy)
            (&self->top); self->length = 0; }
  #endif // 0

#if 0
            Interface iterator[3]={&volatile(Type),0,0};
                volatile(type) = "builder(ComplexHeap)";

            Interface * reg = Heap(Interface)(Interface).base
                            .at(obj->pair.key, iterator);

            if( !reg ){throw(new(NullPointer))
                (this, "NullInterface");}

                class(Rig) slot = {"level",0,0,0};

            Complex * c = Heap(Complex)(Interface).base.at((*reg)[2],slot);

            if( c )
            {
                printf("key: %s\n", c->key) ;
            }




            reg = multimap(false)("Fan")("class(SubjectTable)");

            N(Class) * iter = ((Stk(Class)*)reg[1]) -> stktop;

            while(iter)
            {
                /* note: reallocate
                 */
                *(Object**)iter->info =
                    reallocate(*(Object**)iter->info, bytes("Fan"));

                if( !*(Object**)iter->info ){throw(new(OutOfMemory))
                    (this, "ObjectReallocationFailure");}



                ((Object***)iter->info)[0][ ( bytes("Fan") / sizeof(void*) ) - 1 ] = 0;



                iter = iter->link;
            }
#endif // 0
  #if 1
    except static cstring TypeID(Except)( const Object * );

    except explicit cstring TypeID(Except)( const Object * self )

        { if( !self ){ throw(new(NullPointer))(this, "NullObject"); }

          class(VirtualTable) * i = instance(self);
          if( !i ){ throw(new(NullPointer))
          (this, "NotAVirtualTableObject"); }

          if( ((typePtr*)i)[0] )/*i->type*/
          { return ((typePtr*)i)[0](); }/*i->type();//whatitismang*/
          else
          { throw(new(NullPointer))(this, "NullTypeID"); } }

  #else /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    noexcept static cstring TypeID(NoExcept)( const Object * );

    noexcept explicit cstring TypeID(NoExcept)( const Object * self )

        { if( !self ){ if(default(8)) {printf("(NullObject)\n");} return ""; }

          class(VirtualTable) * i = instance(self);
          if( !i ){ if(default(8)){ printf("(NotAVirtualTableObject)\n"); }
            return ""; }

          if( ((typePtr*)i)[0] )/*i->type*/
          { return ((typePtr*)i)[0](); }/*i->type();//whatitismang*/
          else
          { if(default(8)){ printf("(NullTypeID)\n"); } return ""; } }
  #endif // STACK_PRINT_RAISE_DEFAULT_8___DEBUG___0

           multimap(-1)("Fan")



            Interface iterator[3]={&volatile(Type),0,0};
                volatile(type) = "builder(ComplexHeap)";

            Interface * reg = Heap(Interface)(Interface).base
                            .at(obj->pair.key, iterator);

            if( !reg ){throw(new(NullPointer))
                (this, "NullInterface");}

                class(Rig) slot = {"level",0,0,0};

            Complex * c = Heap(Complex)(Interface).base.at((*reg)[2],slot);

            if( c )
            {
                printf("key: %s\n", c->key) ;
            }




            reg = multimap(false)("Fan")("class(SubjectTable)");

            N(Class) * iter = ((Stk(Class)*)reg[1]) -> stktop;

            while(iter)
            {
                /* note: reallocate
                 */
                *(Object**)iter->info =
                    reallocate(*(Object**)iter->info, bytes("Fan"));

                if( !*(Object**)iter->info ){throw(new(OutOfMemory))
                    (this, "ObjectReallocationFailure");}



                ((Object***)iter->info)[0][ ( bytes("Fan") / sizeof(void*) ) - 1 ] = 0;



                iter = iter->link;
            }



    #define FACTORY_SECURITY_RESTRICTION 0

    #if FACTORY_SECURITY_RESTRICTION
    static Security * (*Factory(Keys)) (cstring) = 0;

    volatile static bool Security(Restrict) = false;
    #endif // FACTORY_SECURITY_RESTRICTION


    #if FACTORY_SECURITY_RESTRICTION
        { if( Factory(Keys) ){ Key * key = Factory(Keys)(type);

                if( Security(Restrict) && key )
                    { throw( new(RestrictedAccess) ) //  out
                        (this, "SecurityRestriction"); }

                if( !Security(Restrict) && !key )
                    { throw( new(NullPointer) ) //  in
                        (this, "NotInHeapSet"); } }

          return ((new*)multimap(false)(type)
                  ("class(FactoryTable)"))[1](); }
    #else

    #endif // FACTORY_SECURITY_RESTRICTION



#if 0





                    #if 1
                        if( n == 5 )//pass(Heap) <--(use overload for interface reg[3])
                        {
                          //obj[0] = & pass(SecurityHeap)(Type);//swap with reg[3] for use
                          //obj[1] = reg[1];//method 1 (need volatile)
                          obj[2] = reg[2];//container
                          obj[3] = reg[3];//type method (for proper type)(swap with reg[0])
                        #if 1
                          obj[4] = reg[4];
                        #else
                          obj[4] = accumulate(string)(this, 11);
                          ItoaHex( *(string*)obj[4], &obj[4] );
                            /* note: the pass number is the address of
                                     the pass number
                             */
                        #endif // PASS_SETUP
                        }
                #endif // NOT_NEEDED




        explicit Interface () class(Builder)(BuildInit)(size_t c, ...)
        {


          /* note: this case is needed for when the class builder
           *       multimap re-adds the interface without throwing
           */
          if( class(Builder)(Flag) )
          {class(Builder)(Flag) = false;
    #if 0
                    if( string(equal)(  ((typePtr*)obj)[0]() ,
                        "class(SubjectTable)") )
                    {

                    }
                    class(Builder)(Helper)( ((typePtr*)obj)[0](), &n );

                    if( n == 4 )
                    {
                        obj[3]

                        ((factPtr*)obj[3])[2](obj[2]);

                        delete()

                        deaccumulate()

                        deallocate()
                    }
    #endif // RE_INITIALIZE_INTERFACE
          }


          switch(c)
          {
            case 0:





            break;

            case 1:       ;

                Interface reg = stack(arg)(Interface);


                cstring type = ((typePtr*)reg)[0]();
                if( type[0] == '0' )
                {type = ((typePtr*)reg)[3]();}
                else{}

                cstring str = class(Builder)(Helper)(type, &n);


                if( ((size_t)obj[1]) < n )
                {
                    throw(new(Exception))
                    (this, "new[size] < reg[size] (build)");
                }




                else
                {
            #if 0
                    if( n == 5 )//pass(Table)
                    {

                    }
                    else
            #endif //
                    if( n == 3 )//class(Table)
                    {

                    }
                }

            break;

            case 2:   ;

                if( obj[1] == 3 )//class(Table) + 2 param
                {obj[1] = 0;



                }

                if( obj[1] == 5 )//pass(SecurityHeap)
                {obj[1] = 0;

                    Object * pri = stack(arg)(Object*),

                           * sec = stack(arg)(Object*);

                    //       * thi = stack(arg)(Object*);

                    //       * fou = stack(arg)(Object*);

                    //obj[0] = & pass(SecurityHeap)(Type);

                           //& volatile(PassType);//return "(pass)"
                    obj[1] = pri;//method 1
                    obj[2] = sec;//method 2

                    obj[3] = obj[0];//type method (for proper type)


                    obj[4] = accumulate(string)(this, 11);
                    ItoaHex( *(string*)obj[4], &obj[4] );
                    /* note: the pass number is the address of
                                 the pass number
                     */

                }

            break;

          }

            return obj;//new reg
        }
#endif // 0
















            ///N O  W A S T E D  S P A C E  A L L O W E D///
            Heap(Complex) * heap = ((tblePtr*)multimap(false)
            (volatile(class))("builder(ComplexHeap)"))[2];
            ///N O  W A S T E D  S P A C E  A L L O W E D///
            Stk(pHeapNode(Complex)) stk;
            Stk(pHeapNode(Complex))(Init)(& stk);
            HeapNode(Complex)(InOrder)( heap->top, & stk );

            pHeapNode(Complex) p;

            /* note: add byte amounts together for data members
             */
            size_t bytes = 0;
            ///N O  W A S T E D  S P A C E  A L L O W E D///
            while( Stk(pHeapNode(Complex))(Top)(& stk) )
            {
              p = Stk(pHeapNode(Complex))(Pop)(& stk);

              bytes += p->info.col;
            }
            ///N O  W A S T E D  S P A C E  A L L O W E D///
            return VirtualTable(Interface).insert(
            vtable, vstk, (Class*)allocate(bytes),
            multimap(false)(volatile(class))("class"),
            & volatile(Init) ) ;
            ///N O  W A S T E D  S P A C E  A L L O W E D///

    /* note:

        there may need to be, (the tweakiest thing) that every
        objects first data field position be reserved for a
        pointer to its factory table class, or that builder
        objects come in "pairs" as in a factory table class
        slot pointer and object, there is the possibility that
        a single type function can work in a volatile way that
        works for all but an implementation limit of runtime
        complex factory table classes seems inevitable...


        remember either the first data field position (of a
        builder object) needs to be reserved for its factory
        table classes slot in the factory table, so the string
        allocated as the key there needs to take responsibility
        for the typeid function somehow...

             #define builder Pair(ID, Class)

             #define classfactory typeid, factory

             builder var = { typeid, factory("...")(this, ...) };



             builder var = { class(factory)("...")(this, ...) };


                        typeid(&var)


        typeid can check if the objects first datafield pos
        is a specific address, if so... then check its virtual
        table for its builder pointer back to the factory table
        class string key... a better thing to do would be to

        have a "typeid table" thats an adapter table or something
        that could be a/the builder(s) table so, when a builder

        object is passed into typeid, its looked inside by a table
        that only typeid uses, stored in the builder object, a table
        of objects and each objects assigned pointer to its runtime
        string type id its class key at the factory table or the
        string allocated by the factory table


        now that i think about it, nothing tweaky about builder

        objects being objects that need to pass inspection by

        the first datafield pos being a very specific address,

        the address of typeid. nothing tweaky about the builder

        having an adapter table, also.


             #define       class( type )\
             \
                { _type, factory(type) } // ;


             multimap("")


        the typeid table can be (in a way better way) a table

        of each interfaces assigned typeid, not object, therefore

        a typeid would execute as first, a check with the instance

        method to get the interface address, then a check in the

        typeid table for initializing the volatile type method,

        return just the type method as normal if not found in

        builder table, since not a builder class.



                size_t bytes = 0, pos = 0;


                while( !string(equal)( list->key, "" ) )
                {

                    //get the byte size amount for allocate

                    //from the complex heap as a list

                    //you should even be able to calculate

                    //the amount of wasted space if any.

                    //i can see this being really easy just

                    //if there is no wasted space

                    bytes += list->col;

                }


    private static private struct private struct(Bunker)
   *struct(Bunker)(ComplexInit)(private struct private
    struct(Bunker)*,...); private static private void
    struct(Bunker)(ComplexDtor)(struct struct(Bunker)*);


    private inline private static private struct
    private struct(Bunker)*struct(Bunker)(ComplexInit)
        (struct struct(Bunker)*self,...)
    {if(!self){return nullptr;}

       (*self)=class(Bunker); /*  * /

        Complex * iterator = (Complex*)((tblePtr*)multimap(false)

        ( struct(Bunker)(TypeID)() )("class(ComplexHeap)"))[2]



        VirtualTable(Allocator)

        ( & self->accumulator , 101 );//& ( self + ( row->val * row->col )

    return self;};



    (private struct private struct(Bunker)*self)
            //
        {vtable=*self->vtable;destroy();

         VirtualTable(Deallocator)
            //
         ( & self->accumulator ); }




        static void Delete(Object *);
        explicit void Delete(Object * self){delete(self);}//hopefully not


             //while( !string(equal)( iterator->key, "" ) )//
             //{ bytes += iterator->col; iterator++; }     //




             int a = 1,
                 b = 2,
                 c = a + b ;

             int a = 1;
             int b = 2;
             int c = a + b ;


            # define A(Member)A ## Member                   //namespace macro


             typedef struct A                               //struct for object
             {
                   int a, b, c;
             }A;                                            //classname


             typedef struct A(VirtualTable)                 //struct for interface
             {  struct class(VirtualTable) base;

                   void (*execute)(A *);

             }A(VirtualTable);


             extern void A(Execute)(A *);








             in .c

             void A(Execute)(A * self)
             {


             }




            # define A(Member)A ## Member                 //feel free to place extras
                                                          // (namespace macros)
             typedef struct A A;                          //just don't try to redefine
             struct A                                     //a macro as something else
             {                                            //without using #undef
                   int a, b, c;

             }obj = {1,2,3};






             int main()
             {
                A obj;
             }





     */

        /**
        THIS IS GOING TO USE A BINARY TREE FOR A HEAP, NOT A

        RUNTIME-OBJECT FOR AN ARRAY. THEREFORE, NONE OF THESE

        PARAMETERS ARE GOING TO BE USED. INSTEAD THE HEAP NEEDS

        TO BE POLYMORPHIC AS EITHER AN INTERFACE HEAP OR INFO HEAP

        SO IT CAN BE FOR THE BUILDER FACTORY METHOD AND BUILDER SUB

        FACTORY METHOD(S)


        ...


        AS THE BUILDER FACTORY

        METHOD IS WHERE THE CONTAINER ITSELF IS FOR THE HEAP,

        THERE A VOLATILE CONTAINER POINTER WILL BE NEEDED, THIS SHOULD

        SUFFICE FOR BOTH LEVELS OF HEAP. EVERYTHING HAS BEEN

        DEFINED FOR A LONG TIME NOW JUST THAT IT COMES DOWN TO

        THE FACT THAT NOW THINGS FOR THE CLASS BUILDER HAVE TO BE

        IMPLEMENTED SO THIS FILE IS GOING TO... (REPLACED BY STACKS)
        */
        /**
        it seems like ...
         */
    /**


    Class(VirtualTable) * p = instance(self)

    if( p )
    {
        cstring type = class(Builder)(IsBuilder)(p)


        if(type){return type;}else{return "(!builder)";}
    }



            switch(c)
            {
                case 0:



                break;
                case 1:





                break;
                case 2:



                break;
                default:

                break;
            }



     */



    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief global print stack trace (not important)           *
     *                                                           *
     *         - - (printf)  #define  print  printf  - -         *
     *                                                           *
     * @param self                                               *
     *                                                           *
     * @return int                                               *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #if 0
    #if 0
            printStackTrace(class(ConsoleTable))(self);
    #endif // 0

    //#define printStackTrace(reg) \
    //\


    explicit int printStackTrace(Exception * self)
    {
        if( instance(self) )
        {
            return ((factPtr*)multimap(false)(typeid(self))
             ("class(ConsoleTable)"))[2](self);
        }
        else
        if( struct(Bunker)(Instance) )
        {
            return ((factPtr*)multimap(false)(struct(Bunker)
             (TypeID)(self))("class(ConsoleTable)"))[2](self);
        }
    }
    #endif // 0


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief       polymorph heap for assertions                *
     *                       - - ... - -                         *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Polymorph    ///REDEFINITION

        Assertion  (PolymorphHeap)[two] =

    { {"Exception",0,0,""},{"class",0,0,""},
    {"",0,0,""} } ;
    static Polymorph *
    typename(SubFactoryMethod)(Assertion,Polymorph,Polymorph,0,1);


    static struct class(PolymorphHeap)//#3

        Assertion (Polymorph) =

    { &class(PolymorphHeap)(Type), &Assertion(PolymorphSearch),
      Assertion(PolymorphHeap)};

        /*


                if( string(equal)( type+l, "(FactoryMethod)" ) )
            {
                n--;
            }
            non = allocate(sizeof(void**n));

            if( string(equal)( type+l, "(FactoryMethod)" ) )
            {
                non[0]=&builder(FactoryMethod)(Type);
                non[1]=&volatile(ClassFactoryMethod);
                non[2]=allocate(sizeof(Heap(Interface)));
                non[3]=Heap(Interface)(Interface);
            }


            size_type x=0, y=0,z=0, length;

            for( size_type i = 0; i < str->length; i++ )
            {
                if( str->array[i] == '(' ){ x=i+1; z=1;}

                if( str->array[i] == 'H' ){ y=i-1; }

                if(z > 0){z++;}

                ++i;
            }
            length = y-x+1;//




            if( length == z ){  }


            Vector(char) * type =

            new(String)(this, 5, volatile(interface));


            Complex * row = (Complex*)multimap(true)( class(Builder)(ID) )

                    ("class(ComplexHeap)")("");

            self + ( row->val * row->col ) ;


     */



    #if 0



        explicit void Builder(BuildHelper)

            (cstring type, size_t * n, size_t * l)
        {
            if(type[0]=='c'&&type[1]=='l'&&type[2]=='a'
               &&type[3]=='s'&&type[4]=='s'){*n=3;*l=5;}
            else
            if(type[0]=='p'&&type[1]=='a'
               &&type[2]=='s'&&type[3]=='s'){*n=4;*l=4;}
            else
            if(type[0]=='b'&&type[1]=='u'&&type[2]=='i'
               &&type[3]=='l'&&type[4]=='d'&&type[5]=='e'
               &&type[6]=='r'){*n=6;*l=7;} return; }


        explicit Interface () (*build(cstring type))(Interface)
        {
            Interface non ;

            size_t n, l;

            Builder(BuildHelper)(type, &n, &l);


            non = allocate(sizeof(size_t) * n);


            Strategy * strategy = Builder(Types)(type);
            if(!strategy){throw(new(NullPointer))
                (this, "NotAnImplementedStruct");}


            non[0] = strategy->val;//assign type method

            for(size_t i = 1; i < n; i--)
            {
                non[i] = 0; }

            iPush(non);

            return & _(build);
        }


        explicit Interface () _(build)(Interface reg)
        {
            Interface self = iPop();

            if(!self){throw(new(NullPointer))
                     (this,"NullInterface");}

            if( reg == 0 )
            { return self; }
            else
            { cstring type=((typePtr*)reg)[0]();

              size_t n1, n2, l;

              Builder(BuildHelper)( ((typePtr*)self)[0](),
                                           &n1, &l);
              Builder(BuildHelper)(type, &n2, &l);




                if(n1 < n2){}


                cstring iter = type;
                while(*iter != '(')

                {iter++;}iter++;

                if(*iter == 'H'){iter++;}

                while(*iter != 'H')
                {
                    if(*iter == ')'){break;}

                    iter++;
                }
                if(*(--iter) == 'H'&&*(++iter) == 'e'
                 &&*(++iter) == 'a'&&*(++iter) == 'p' )
                {


                }




            }

        }





    #endif // 0


         #if 0

        explicit Interface () (*build(cstring type))(aSizeType, Interface)
        {
            Interface non ;

            size_t n, l;

            Builder(BuildHelper)(type, &n, &l);


            non = allocate(sizeof(size_t) * n);


            Strategy * strategy = Builder(Types)(type);
            if(!strategy){throw(new(NullPointer))
                (this, "NotAnInterface");}


            non[0] = ((typePtr*)strategy)[0] ;//assign type method

            for(size_t i = 1; i < n; i--)
            {
                non[i] = 0; }

            iPush(non);

            return & _(build);
        }


        explicit Interface () _(build)(aSizeType c, ...)
        {
            Interface self = iPop();

            if(!self){throw(new(NullPointer))
                     (this,"NullInterface");}





            if( reg == 0 )
            { return self; }
            else
            { cstring type=((typePtr*)reg)[0]();

              size_t n1, n2, l;

              Builder(BuildHelper)( ((typePtr*)self)[0](),
                                           &n1, &l);
              Builder(BuildHelper)(type, &n2, &l);




                if(n1 < n2){}


                cstring iter = type;
                while(*iter != '(')

                {iter++;}iter++;

                if(*iter == 'H'){iter++;}

                while(*iter != 'H')
                {
                    if(*iter == ')'){break;}

                    iter++;
                }
                if(*(--iter) == 'H'&&*(++iter) == 'e'
                 &&*(++iter) == 'a'&&*(++iter) == 'p' )
                {


                }




            }

        }

        //there is an exception based certificate
        //

//        printf( "%s\n", ((typePtr*)(*p))[0]() );//interface type
    //    printf( "0x%x\n\n", ((whatPtr*)(*p))[1]() );//constructor address

    //                         ///now im not looking at a ClassName
     //   Container * _str =  ((new*)(*p))[1]() (this, 2, "Hello");
      //                   ///this is the function called by factory("String")


        static Interface () _(build)(size_t, ...);
    #endif // 0

    #if 0

    #define defineAssertionOut( Type, Print, End, Object )\
    \
        explicit int Assertion(Type##Out)( Assertion * self, ... )\
        {\
            if( !self ){ printf("(assertion)"); return; }\
    \
            Stack * stack = control();\
    \
            Object    ;    \
    \
            if( instance(self) )\
            {\
                Print "type:\t\t %s\n", typeid(self)End;/*X*/\
            }\
            else\
            if( struct(Bunker)(Instance)(self) )\
            {\
                Print "type:\t\t %s\n", struct(Bunker)\
    \
                (TypeID)(self)End;/*X*/\
            }\
    \
            Print "\n" End;\
    \
            Print "time:\t\t %s\n", self->time End;/*[0]*/\
    \
            Print "date:\t\t %s\n", self->date End;/*[1]*/\

            if( instanceof( self, IsPolymorphic )
            || struct(Bunker)(InstanceOf)( self, IsPolymorphic ) )
            {
                Print "poly:\t\t %d\n", self->line End;/*[2]*/\
            }
            else
            {
                Print "line:\t\t %d\n", self->line End;/*[2]*/\
            }

    \
            Print "file:\t\t %s\n", self->file End;/*[3]*/\
    \
            Print "cond:\t\t %s\n", self->text End;/*[4]*/\
    \
            Print "eval:\t\t %s\n", (((Assertion*)self)\
                                ->cond?"true":"false") End;\
    \
            Print "\n" End;\
    \
            return 0;\
        }

    static int Assertion(ConsoleOut)( Assertion *, ... );

    typename(AssertionOut)
    ( Console,

        _cPrint(), cEnd(),

    ;);


    static int Assertion(StandardOut)( Assertion *, ... );

    typename(AssertionOut)
    ( Standard,

        _sPrint(str), sEnd(),

        string * str = ConsoleOut(Object) ;

    );


    static int Assertion(FileOut)( Assertion *, ... );

    typename(AssertionOut)
    ( File,

        _fPrint(file), fEnd(),

        File * file = ConsoleOut(Object) ;

    );


    #endif // 0




#if 0

    cout(e)cend;

    #undef printStackTrace
    explicit int printStackTrace( Exception * self )
    {
        if( !self ){ printf("(exception)"); return; }
        if( struct(Bunker)(Instance)(self) )
        {
          Print "type:\t\t %s\n", struct(Bunker)(TypeID)(self)End;/*X*/\
        }
        return Exception(ConsoleOut)(self);
    }


            if( instance(self) )\
            {\
              Print "type:\t\t %s\n", typeid(self)End;/*X*/\
            }\
    \

            if( string(equal)( typeid(self), "Assertion" ) )\
            {\
                Print "cond:\t\t %s\n", self->text End;/*[4]*/\
    \
                Print "eval:\t\t %s\n", (((Assertion*)self)\
                                ->cond?"true":"false") End;\
    \
    \
                /*(((bool*)self)[16]?"true":"false") End;*/\
    \
                /*((bool*)(((size_t*)self) + 5)\
                 [1]?"true":"false") End;*/\
            }\
            else \
            {\
                Print "text:\t\t %s\n", self->text End;\
            }\
#endif





        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /*     volatile search goes in factory table slot    */
        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /** * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief    volatile class factory method           *
         *                                                   *
         * i cant remember what this was for but i knew that *
         * there was room for it and so i implemented it. it *
         * was meant for where the factory table needs one   *
         * class factory method for all of them or something *
         * that was anyways volatile. so here is the volatile*
         * class factory method. if i find a reason to use   *
         * this i can remember, then i will make a note of   *
         * it here.                                          *
         *                                                   *
         * (fits in the same place as class factory method,  *
         * only 100% dynamic and volatile, if preferred, one *
         * can declare another variable like the rest named  *
         * index for where parameter 4 is getting a 0        *
         * passed) (for a starting point).                   *
         *                                                   *
         * this might be required by the builder and if it   *
         * is, then so are volatile sub-factory method(s)    *
         ** * * * * * * * * * * * * * * * * * * * * * * * * **/
        /// /// /// /// /// /// /// /// /// /// /// /// /// ///

              static volatile cstring volatile(interface) = 0;


              static volatile fSizeType volatile(size) = 0;
              static volatile fSizeType volatile(first) = 0;
              static volatile fSizeType volatile(last) = 0;

static volatile Interface volatile volatile(iter)[3]={&Volatile(Type),0,0};

        static volatile InterfaceHeap volatile volatile(regs) = 0;




        explicit Interface Volatile(Search) ( cstring reg )

        {   volatile(type) = reg;

            volatile(interface) = reg;//for sub factory method

            Interface * p = Heap(Interface)(Search)( volatile(regs),

                                                     volatile(iter),

                                              &volatile(size),

                                               volatile(first),

                                               volatile(last) );

            if( p ){ return ((*p)) ; } else { return 0; } }

        /**
        THIS IS GOING TO USE A BINARY TREE FOR A HEAP, NOT A

        RUNTIME-OBJECT FOR AN ARRAY. THEREFORE, NONE OF THESE

        PARAMETERS ARE GOING TO BE USED. INSTEAD THE HEAP NEEDS

        TO BE POLYMORPHIC AS EITHER AN INTERFACE HEAP OR INFO HEAP

        SO IT CAN BE FOR THE BUILDER FACTORY METHOD AND BUILDER SUB

        FACTORY METHODS


        ...


        AS THE BUILDER FACTORY

        METHOD IS WHERE THE CONTAINER ITSELF IS FOR THE HEAP,

        THERE A VOLATILE CONTAINER POINTER WILL BE NEEDED, THIS SHOULD

        SUFFICE FOR BOTH LEVELS OF HEAP. EVERYTHING HAS BEEN

        DEFINED FOR A LONG TIME NOW JUST THAT IT COMES DOWN TO

        THE FACT THAT NOW THINGS FOR THE CLASS BUILDER HAVE TO BE

        IMPLEMENTED SO THIS FILE IS GOING TO
        */

        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /** * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief    volatile sub factory method             *
         ** * * * * * * * * * * * * * * * * * * * * * * * * **/
        /// /// /// /// /// /// /// /// /// /// /// /// /// ///

        static Strategy

            Builder(StrategyHeap)[eight] =
        /**ABCDEFGHIJKLMNOPQRSTUVWXYZ**/
        {{"Builder",&Builder(Search)},
         {"Complex",&Complex(Search)},
         {"Control",&Control(Search)},
         {"FactoryMethod",&FactoryMethod(Search)},
         {"Polymorph",&Polymorph(Search)},
         {"Security",&Security(Search)},
         {"Strategy",&Strategy(Search)},
         {"Virtual",&Virtual(Search)},
         {"",0}}
        static Strategy *
        typename(SubFactoryMethod)(Builder,Strategy,Strategy,0,7);

        explicit factPtr Builder(Overload)( cstring type )
        {
            factPtr ptr_fun = Builder(StrategySearch)( type );

            if( !ptr_fun ){ throw(new(NullPointer))
            (this, "InfoHeapNotImplemented"); }
            else { return ptr_fun; } }






        static Info * Volatile(Sub) ( cstring );

        explicit Info * Volatile(Sub) ( cstring info )

        {   volatile(type) = info;



            Vector(char) * type = new(String)(this, 2, volatile(interface));


            size_type x=0, y=0,z=0, length;

            for( size_type i = 0; i < str->length; i++ )
            {
                if( str->array[i] == '(' ){ x=i+1; z=1;}

                if( str->array[i] == 'H' ){ y=i-1; }

                if(z > 0){z++;}

                ++i;
            }
            length = y-x+1;//


            if( length == z ){  }




            Info * p = Builder(Overload)(  )( volatile(regs),

                                               volatile(iter),

                                              &volatile(size),

                                               volatile(first),

                                               volatile(last) );

            if( p ){ return ((*p)) ; } else { return 0; } }


    /**
    REMEMBER THIS STRUCT AND WHY IT IS COMMENTED OUT, REMEMBER

    THAT THIS IS HOW SILLY YOU ARE SOMETIMES BECAUSE YOUR BUILDER

    FACTORY METHOD NEEDS TO BE A RUNTIME OBJECT ITSELF.
     */
    #if 0
        static struct builder(FactoryMethod)

            FactoryTable(Builder)(FactoryMethod) =

        { &builder(FactoryMethod)(Type),  }
    #endif // 0



    WHEN THIS FUNCTION IS PASSED INTO MULTIMAP

    PRIMARY FACTORY METHOD OR UNION FACTORY METHOD THE DETONATOR

    DEALLOCATES THE STRING ON TOP OF THE STACK, LEAVING THE TYPE INFO

    OBJECT ON TOP OF THE STACK AFTER. (ABANDONED) (INFO HEAP INSTEAD)



    //static void typename(Setup) (String) { /*register(Vector(char));*/ }

    //static void typename(Abort) (String) { /*drop(Vector(char));*/ }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief there is class construction in macros surrounding  *
     *  these prototypes and so they are hard to pick out in the *
     *  rest of the implementations and are also unnecessary but *
     *  are included here in the OO-String since its the first   *
     *  factory table class of the OOC Library and whatever works*
     *  here goes into the Vector afterwards, also must note     *
     *  Display in Display.h is the same as Command in Command.h *
     *  just the display comes as as factory table class.        *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    - - come up with a full interface or set of interfaces
        for the factory table helper with the factory table
        as the central access pointer for FACTORY C

        /**
        it seems like ...
         */

  #if 0
    #define defineConsoleOut( self, type, param, print, end )\
    \
            if( !instance(self) \
    \
                && self != vtable && self != ftable && self != atable )\
            {\
              return printf("%s", self);\
            }\
    \
            if( self == vtable )\
    \
            { multimap(false)("VirtualTable"); }\
    \
            if( self == ftable )\
    \
            { multimap(false)("FactoryTable"); }\
    \
            if( self == atable )\
    \
            { multimap(false)("AdapterTable"); }\
    \
            if( self != vtable || self != ftable || self != atable )\
            {\
              multimap(false)(typeid(self));\
            }\
    \
              class(Interface) * reg = map  ("class(ConsoleTable)");\
    \
    \
              if( reg ){ return ((factPtr*)reg)[2](self);  }\
              else{ throw(new(NullPointer))\
               (this, "NotAHeapInterface"); }

  #else

		try
		{
		Component * pancake = new (Menu)(this,
                              new (Stk(pComponent))(this),
                              new (String)(this, 2, "PANCAKE HOUSE MENU"),
                              new (String)(this, 2, "Breakfast") );

		Component * diner   = new (Menu)(this,
                            new (Stk(pComponent))(this),
                            new (String)(this, 2, "DINER MENU"),
                            new (String)(this, 2, "Lunch") );

		Component * cafe = new (Menu)(this,
                           new (Stk(pComponent))(this),
                           new (String)(this, 2, "CAFE MENU"),
                           new (String)(this, 2, "Dinner") );

		Component * dessert = new (Menu)(this,
                              new (Stk(pComponent))(this),
                              new (String)(this, 2, "DESSERT MENU"),
                              new (String)(this, 2, "Dessert of course!") ) ;

		Component * coffee = new (Menu)(this,
                             new (Stk(pComponent))(this),
                             new (String)(this, 2, "COFFEE MENU"),
                             new (String)(this, 2, "Stuff to go with your afternoon coffee") );


		Component * all = new (Menu)(this,
                          new (Stk(pComponent))(this),
                          new (String)(this, 2, "ALL MENUS"),
                          new (String)(this, 2, "All menus combined") );


		virtual( all, Component ) -> add(this, pancake);

        virtual( all, Component ) -> add(this, diner);

		virtual( all, Component ) -> add(this, cafe);



		virtual( pancake, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "K&B's Pancake Breakfast"),
			new(String)(this, 2, "Pancakes with scrambled eggs and toast"),
            true, 2.99));

		virtual( pancake, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Regular Pancake Breakfast"),
			new(String)(this, 2, "Pancakes with fried eggs, sausage"), false, 2.99));

		virtual( pancake, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Blueberry Pancakes"),
			new(String)(this, 2, "Pancakes made with fresh blueb"
                "erries, and blueberry syrup"),
			true, 3.49));

		virtual( pancake, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Waffles"),
			new(String)(this, 2, "Waffles with your choice of"
                " blueberries or strawberries"),
			true, 3.59));

		virtual( diner, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Vegetarian BLT"),
			new(String)(this, 2, "Bacon with lettuce & tomato on whole wheat"),
            true, 2.99));

		virtual( diner, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "BLT"),
			new(String)(this, 2, "Bacon with lettuce & tomato on whole wheat"),
            false, 2.99));

		virtual( diner, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Soup of the day"),
			new(String)(this, 2, "A bowl of the soup of the day, with a side"
               " of potato salad"),
			false, 3.29));

		virtual( diner, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Hot Dog"),
			new(String)(this, 2, "A hot dog, with saurkraut, relish, onions, "
               "topped with cheese"),
			false, 3.05));

		virtual( diner, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Steamed Veggies and Brown Rice"),
			new(String)(this, 2, "Steamed vegetables over brown rice"), true, 3.99));

		virtual( diner, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Pasta"),
			new(String)(this, 2, "Spaghetti with marinara sauce, and a slice"
               " of sourdough bread"),
			true, 3.89));


            virtual( diner, Component ) -> add(this, dessert);


		virtual( dessert, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Apple Pie"),
			new(String)(this, 2, "Apple pie with a flakey crust, topped "
               "with vanilla icecream"),
			true, 1.59));

		virtual( dessert, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Cheesecake"),
			new(String)(this, 2, "Creamy New York cheesecake, with a "
               "chocolate graham crust"),
			true, 1.99));


        virtual( dessert, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Sorbet"),
			new(String)(this, 2, "A scoop of raspberry "
               "and a scoop of lime"), true, 1.89));

		virtual( cafe, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Veggie Burger and Air Fries"),
			new(String)(this, 2, "Veggie burger on a whole wheat "
               "bun, lettuce, tomato, and fries"),
			true, 3.99));

		virtual( cafe, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Soup of the day"),
			new(String)(this, 2, "A cup of the soup of the day,"
               " with a side salad"), false, 3.69));

		virtual( cafe, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Burrito"),
			new(String)(this, 2, "A large burrito, with whole "
               "pinto beans, salsa, guacamole"),
			true, 4.29));


            virtual( cafe, Component ) -> add(this, coffee);


		virtual( coffee, Component ) -> add(this, new(Item)(this,
			new(String)(this, 2, "Coffee Cake"),
			new(String)(this, 2, "Crumbly cake topped with cinnamon and walnuts"),
			true, 1.59));

		virtual( coffee, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Bagel"),
			new(String)(this, 2, "Flavors include sesame, poppyseed,"
               " cinnamon raisin, pumpkin"),
			false, 0.69));

		virtual( coffee, Component ) -> add(this, new (Item)(this,
			new(String)(this, 2, "Biscotti"),
            new(String)(this, 2, "Three almond or hazelnut biscotti cookies"),
			true, 0.89));


		//Waitress * waitress = new (Waitress)(this, all);
            //waitress->


            virtual( all, Component ) -> print(this); //throws an exception

		}catch( Exception * e )
		{
		    printStackTrace(e);
		}





     *                                                                           *
     *      factory c is defined by/with a factory object and a control factory. *
     * a factory object is not only a virtual table object but an object of a    *
     * factory table class. factory c not only uses an object but it uses an     *
     * adapter. an adapter is an object adapter to another object with itself
     * using a specially assigned adapter constructor and interface


            factory c includes basic oop programming using a   *
     * virtual table (vtable) object with simple inheritance for the class       *
     * (object) type and the class virtual table (interface) type. factory c
     *
     *
     *
     *                                                                           *
     *      the control factory is a sequence of constructor style functions     *
     * where each constructor called in sequence is a factory function that      *
     * encapsulates a factory function called from its factory slot in a oo      *
     * array.                                                   *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief non-control factory use of template                                   *
     *                                                                              *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

    enum TempEnum { IntA = 0, CharA = 4, CharB = 5, CharC = 6, CharD = 7, IntB = 2 };

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
       ///this is what: typename(Object)(float); implements:
    /**
        float * floatInit( float *, float );

        void floatDtor( float * );

        cstring floatType();


        static struct class (VirtualTable)

            floatInterface =

        { & floatType, & floatInit, & floatDtor };


        float * floatInit( float * self, float info )

        { if( !self ){return 0;}

            (*self) = info;

          return self;}

        void floatDtor( float * self )  {}

        cstring floatType(){return "float";}

        /// and this for the factory table:

        ctorPtr floatFact(void) { return new(float); }


        static struct class (FactoryTable)

            floatFactory =

        { & classFactoryTableType, & floatFact, 0 };


        /// but not:

        static Reg floatRegs[one] =

        { & floatFactory, nullptr };

    */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * <library that defines Object-Oriented essentials in C (Factory C)>*
 *                                                                   *
 * THIS SOFTWARE IS NOT COPYRIGHTED                                  *
 *                                                                   *
 * This source code is offered for use in the static domain.         *
 * You may use, modify or distribute it freely.                      *
 *                                                                   *
 * This code is distributed in the hope that it will be useful, but  *
 * WITHOUT ANY WARRANTY.  ALL WARRANTIES, EXPRESS OR IMPLIED ARE     *
 * HEREBY DISCLAIMED.  This includes but is not limited to           *
 * warranties of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.*
 *                                                                   *
 * <jb.bee250@gmail.com> <Christopher Bond>                          *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
 ///needs to be validated  (SO DISCLAIM IT)
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *  <OOC library that defines Object-Oriented essentials in C (C+)>  *
 *                                                                   *
 * Copyright (C) <2017 - 2021>  <Christopher Bond>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Email: <jb.bee250@gmail.com>                                      *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*
        and so: this library of files gives you the choice of
               using Object, Container, and Iterator as the 3
               main interfaces with Object as the base type
               that every container is filled with and every
               Iterator points to (no primitives)
               ---or--- Object (as an interface or implemented
               structure) is void instead. so Container and Iterator
               won't be as powerful polymorphically but, Containers
               can then be full of anything under the sun, only
               a cast needs to be remembered returning anything
               from a Vector through it's base interface, Container
 */
#if 0
            else
            {


                while(                    0                    <     probe \
                \
                    &&                 ref                     !=    0 \
                      /*((type##Vector*)self)->array[probe]    !=    0*/\
                    &&                       comp \
                      /*((type##Vector*)self)->array[probe]    !=    info*/
                     ) \
                { \
        \
        \
                    if( typemax(size_type) - ((type##Vector*)self)->maxsize
                      > typemax(size_type) / 2 )
                    { if( probe > typemax(size_type) - ((type##Vector*)self)->maxsize )
                      { break; }
                    } else
                    { if( probe > ((type##Vector*)self)->maxsize )
                      { break; } }


        \
                    probe = h - (uint##bits##_t) pow(i, 2); \
        \
        \
        \
                    i++; \
        \
        \
        \
        \
        \
                }\
#endif // 0
    //FILE* fopen( const char*, const char* );//prototype in function body

    //FILE * fp = fopen("C:/CB/New/vtable.out", "a+");


    ///File * f = new(File)(this, "C:/CB/New/vtable.out", "a+");

    ///f->print();

    ///f->scan();

    ///Console * c = new(Console)(this);

    ///c->print();

    ///c->scan();

    //fclose(fp);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*
#define  print                   printf              //print to console


#define  scan                    scanf               //scan console input


#define  File                    FILE


#define  open                    fopen


#define  close                   fclose


#define  filePrint               fprintf             //print to file


#define  fileScan                fscanf              //scan file
*/
/*

        ///class * a = macro(a)

        ///define macro(x) f1(&x); f2

        ///class * a = f1(&a); f2(a);

        ///class * a = macro(x)(...);

        ///class * a = f1(&a); f2(a);

    - - try an alternative way of writing new(Class) - -

    - - but make the purpose towards some other basic need - -

    - - other than memory allocation, like console IO or File IO

        or GUI controls - -
*/
/**
 *
 * remember to include a pattern for the numbered functions branching
 * from the specific vArray data field position so theres Emergency01A
 * and Emergency01B or something that the array gets reinitialized to
 *      --this makes the added array of pointers
 *      provide maximum strategy (pat on the back)--
 *
 * copy( copied from (start), copied from (end), Iterator copied to (begin) )
 * front and back as functions are good to return a pointer
 *
 * define a Comparable struct and a
 * Pair struct that is Comparable for sets and tables;
 *          only use:    a->equal(a, b)
 *                       a->greater(a, b)
 *
 * finish stuff inside hashSet file like iterator constructor
 * and vtable destructor
 *
 * hashset doesn't use iterator (Vector(utype iterator available))
 * (so done)
 *
 * make sure to use the ideas for factories including an arg list of
 * arg lists
 *
 * ---either finish Size interface for more OOC or just scrap it and---
 *              ---put Size back into Container.h---
 *              ---define Wrapper for primitives by
 *                 the time Object is an interface---
 *
 *   ---size_type ever accepting of Integer or UInteger (Wrapper)?---
 */
 /*
     \
        t##Iter* new##t##Iter( N(t)* n )\
        { t##Iter* self = (t##Iter*)allocate(sizeof(t##Iter));\
          if( self == nullptr ){ return nullptr; }\
          ((dtorPtr*)self)[0] = 0;\
          t##IterInit( self );\
          self->n = n;\
          return(self);}

 */

     /*
        typedef cstring ClassName;  //preferred token

        typedef newfPtr ClassFact;  //this too


    ctorPtr [Class]Fact(){ return new( [Class] ); } O a ok



    funcPtr [Class]Virt(Class object){ return Virtual( object, [Class] ); } ??!



    //make it the responsibility of the class to have a :


    typedef struct ClassFactory
    {
        newfPtr fact;

        virtPtr virt;

    }ClassFactory;


    or just a:


    static ClassFactory [Class]Factory =
    {
        &[Class]Fact,

        &[Class]Virt
    };

    but also there should be :


    typedef struct ClassIO
    {               <------------*
        in                        \
                                   \
        out                         \
                                     \
    }ClassIO;                        |
                                     |
                                     |
    but also: -----------------------+

    is where it can extend ClassFactory: ClassFactory base;

    and use: whatPtr what



    to go with a stack of 3 or maybe 4 things in a way that the

    fTable has its own stack table of factory interface types


    */
 /**
 * encapsulate malloc() and free() functions for easy rewrite in prog
 * define nullptr over NULL
 *
 * possibly create a basic vector that does not resize itself.
 * 1) the vtable resizes itself its own way from the standard vector
 * 2) good for a large string (same reason)
 * 3) the extended vector can return an iterator thats added to the vtable,
 *      *an extra macro argument can do this
 *
 *  check all functions called from objects for being overridden properly
 *  or not especially with vtable
 *
 *  got an error with using uint64_t as the vector size type...
 */
///defineVector(int, *a = *b, *a = 0)

///defineVector(ShapePointer, (*a) = new(Shape)(this, 1, b), delete(*a))

///defineVector(Shape, a->copy(a, b), (*a).base.base.dtor(a))

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

///extern FILE (*abc)[];	/* A pointer to an array of FILE */
///#define ABC	(*abc)	    /* An array of FILE */

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/*
        vaList list;\
\
        vaStart(list, self);\
\
        size_type c = vaArg(list, size_type);\
\
        switch(c)\
        {\
            case 0:\
                self->maxsize = vaArg(list, size_type);\
                self->array = (type*)allocate( sizeof(type) * self->maxsize );\
                if( self->array == 0 ){ return 0; }\
                self->length = 0;\
            break;\
            case 1:\
                ;type##Vector* other = vaArg(list, type##Vector*);\
                self->maxsize = other->maxsize;\
                self->array = (type*)allocate( sizeof(type) * self->maxsize );\
                if( self->array == 0 ){ return 0; }\
                self->length = 0;\
\
                type##VectorCopy(self, other);\
            break;\
            case 2:\
                self->maxsize = vaArg(list, size_type);\
                self->array = (type*)allocate( sizeof(type) * self->maxsize );\
                if( self->array == 0 ){ return 0; }\
                self->length = 0;\
\
                type* a,* b;\
                a = vaArg(list, type*);\
                b = vaArg(list, type*);\
\
                type##Copy(self->array, a, self->array + self->maxsize, b);\
            break;\
            default:\
                self->maxsize = c;\
                self->array = (type*)allocate( sizeof(type) * self->maxsize );\
                if( self->array == 0 ){ return 0; }\
                self->length = 0;\
            break;\
        }\
        vaEnd(list);\
*/
        If; _this; file; is; included; before;
       struct_class;h; then; _Iterator; and; _Container; _return; raw;
       memory; If; the; oppositE; then; a; pointer; to; _this; _interface;
       is; returned; so; _this; _struct; could; be; re;written; or;
       taken; into; consideration ;_at; the; programs; beginning; As;
       Vectors; would ;be ;full ;of ;_Object; or; _Object; based ;data ;types
;       only; not; simple; types (primitives);;;;



        explicit Object * volatile(Init)(Object * self, ...)
        {Object * flag;
            multimap(false)(typeid(self));
            flag = flag();
            deaccumulate(flag);

            if( map("class(ComplexHeap)") )
            {
                /// ...

                return self;
            }

            multimap(false)(typeid(self));
            flag = flag();
            deaccumulate(flag);

            if( map("builder(ComplexHeap)") )
            {
                /// ...

                return self;
            }

            throw(new(NullPointer))
            (this, "NotAComplex:Init");
        }



/*
    H1(x) - first hash function, H2(x) - second hash function

    First time we try for following slot - H1(x),

    next probe would be - H1(x)+H2(x),

    next probe H1(x)+2*H2(x) ........ H1(x)+n*H2(x)
*/
/**
//https://gist.github.com/badboy/6267743

//http://burtleburtle.net/bob/hash/evahash.html

//try writing a hashtable with sizes of only
//powers of two

//use size_type for container, iterator and
//everything after...
//try undefining and redefining size_type
//especially after code is generated for classes

//Container would have to be abstract with sizetypes

//rewrite resize to use insert for every element
//after creating new memory because changing array
//size resets the keys

//consider a good time to consider being full like with
//a symbolic constant named determinefull or something
//otherwise try to fill 100% full

//rehash not being used

///self->base.array[ count ] = 0

/// = 0;    .key = 0

/// StringHashSet
/// StringHashTable(Object)
/// HashTable64(Object)

        ///typedef const char* uhashstring_t;

      /// uint##bits##_t
     ///   uint char _t,    hash8, hashstring
    ///and have bits include int in arg int32
   ///or int8 not 32 or 8

 ///try trading the bits arguement with the full uint bits _t
///for a hashset that hashes strings

/**




1. Get the key k
2. Set counter j = 0
3. Compute hash function h[k] = k % SIZE
4. If hashtable[h[k]] is empty
       (4.1) Insert key k at hashtable[h[k]]
       (4.2) Stop
   Else
       (4.3) The key space at hashtable[h[k]] is occupied, so we need to find the next available key space
       (4.4) Increment j
       (4.5) Compute new hash function h[k] = ( k + j * j ) % SIZE
       (4.6) Repeat Step 4 till j is equal to the SIZE of hash table
5. The hash table is full
6. Stop




#define defineQuadraticProbe(type, bits)\
\
    typedef struct type##QuadraticProbe##bits\
    {   HashSet##bits(type) base;\
\
        uint##bits##_t (*qprobe)(type##QuadraticProbe##bits*, uint##bits##_t x);\
\
    }type##QuadraticProbe##bits;\
\
    uint##bits##_t type##QuadraticProbe##bits##qProbe(type##QuadraticProbe##bits*, uint##bits##_t x);\
\
    type##QuadraticProbe##bits* type##QuadraticProbe##bits##Init(type##QuadraticProbe##bits* self, ...)\
    {   if(self == nullptr){return nullptr;}\

        size_type size = type##HashSet##bits##Findprime( maxsize );







        return self;
    }

    uint##bits##_t type##QuadraticProbe##bits##qProbe(type##QuadraticProbe##bits* self, uint##bits##_t x)
    {
        uint##bits##_t val = ((type##Vector*)self)->hash(x), i = 1, probe = val + (uint##bits##_t) pow(2, i)

            % ((type##Vector*)self)->maximum;

        while( probe != val || ((type##Vector*)self)->array[probe] != 0 )
        {
            i++;

            probe = val + (uint##bits##_t) pow(2, i) % ((type##Vector*)self)->maximum;
        }
        return probe;
    }

    bool type##HashSet##bits##QuadraticProbeAdd(\
\
    type##HashSet##bits* self, type val )\
    {\
        if(self->base.length == self->base.maxsize / 2)\
        {\
            if( self->base.maxsize == typemax(size_type)\
\
                && self->base.length - 1 >= self->base.maxsize / 2 )\
            {\
                return false;\
            }\
            if( !((Vector(type)*)self)->resize(self,\
\
            self->base.maxsize * multiplier) )\
            {\
                return false;\
            }\
        }\
        if( self->base.array[ self->hash(val) % self->base.maxsize ] != 0 )\
        {\
            if( self->base.array[ self->qprobe(self, val) ] != 0 )\
            {\
                if( !((Vector(type)*)self)->resize(self,\
\
                self->base.maxsize * multiplier) )\
                {\
                    return false;\
                }\
                else\
                {\
                    return type##HashSet##bits##Add(self, val);\
                }\
            }\
            else\
            {\
                self->base.array[ self->qprobe(self, val) ] = val;\
                self->base.length++;\
                return true;\
            }\
        }\
        self->base.array[ self->hash(val) % self->base.maxsize ] = val;\
        self->base.length++;\
        return true;\
    }\
\
    bool type##HashSet##bits##QuadraticProbeRemove( \
\
    type##HashSet##bits* self, type val )\
    {\
        if( self->base.array[ self->hash(val) % self->base.maxsize ] != 0 )\
        {\
            if( self->base.array[ self->hash(val) % self->base.maxsize ] == val )\
            {\
                self->base.array[ self->hash(val) & self->base.maxsize ] = 0;\
                self->base.length--;\
                return true;\
            }\
            else\
            {\
                if( self->base.array[ self->qprobe(self, val) ] != 0 )\
                {\
                    if( self->base.array[ self->qprobe(self, val) ] == val )\
                    {\
                        self->base.array[ self->qprobe(self, val) ] = 0;\
                        self->base.length--;\
                        return true;\
                    }\
                    return false;\
                }\
                return false;\
            }\
        }\
        return false;\
    }\
\
    type* type##HashSet##bits##QuadraticProbeSearch( \
\
    type##HashSet##bits* self, type val )\
    {\
        if( self->base.array[ self->hash(val) % self->base.maxsize ] != 0 )\
        {\
            if( self->base.array[ self->hash(val) % self->base.maxsize ] == val )\
            {\
                return &self->base.array[ self->hash(val) % self->base.maxsize ];\
            }\
            else\
            {\
                if( self->base.array[ self->qprobe(self, val) ] != 0 )\
                {\
                    if( self->base.array[ self->qprobe(self, val) ] == val )\
                    {\
                        return &self->base.array[ self->qprobe(self, val) ];\
                    }\
                    return nullptr;\
                }\
                return nullptr;\
            }\
        }\
        return nullptr;\
    }


#define defineSecondHash(type, bits)\
\
    bool type##HashSet##bits##SecondHashAdd(\
\
    type##HashSet##bits* self, type val )\
    {\
        if(self->base.length == self->base.maxsize)\
        {\
            if( self->base.maxsize == typemax(size_type)\
                && self->base.length - 1 >= self->base.maxsize )\
            {\
                return false;\
            }\
            if( !((Vector(type)*)self)->resize(self,\
\
            self->base.maxsize * multiplier) )\
            {\
                return false;\
            }\
        }\
        if( self->base.array[ self->hash(val) % self->base.maxsize ] != 0 )\
        {\
            if( self->base.array[ self->rehash(val) % self->base.maxsize ] != 0 )\
            {\
                if( !((Vector(type)*)self)->resize(self,\
\
                self->base.maxsize * multiplier) )\
                {\
                    return false;\
                }\
                else\
                {\
                    return type##HashSet##bits##Add(self, val);\
                }\
            }\
            else\
            {\
                self->base.array[ self->rehash(val) % self->base.maxsize ] = val;\
                self->base.length++;\
                return true;\
            }\
        }\
        self->base.array[ self->hash(val) % self->base.maxsize ] = val;\
        self->base.length++;\
        return true;\
    }\
\
    bool type##HashSet##bits##SecondHashRemove( \
\
    type##HashSet##bits* self, type val )\
    {\
        if( self->base.array[ self->hash(val) % self->base.maxsize ] != 0 )\
        {\
            if( self->base.array[ self->hash(val) % self->base.maxsize ] == val )\
            {\
                self->base.array[ self->hash(val) & self->base.maxsize ] = 0;\
                self->base.length--;\
                return true;\
            }\
            else\
            {\
                if( self->base.array[ self->rehash(val) % self->base.maxsize ] != 0 )\
                {\
                    if( self->base.array[ self->rehash(val) % self->base.maxsize ] == val )\
                    {\
                        self->base.array[ self->rehash(val) & self->base.maxsize ] = 0;\
                        self->base.length--;\
                        return true;\
                    }\
                    return false;\
                }\
                return false;\
            }\
        }\
        return false;\
    }\
\
    type* type##HashSet##bits##SecondHashSearch( \
\
    type##HashSet##bits* self, type val )\
    {\
        if( self->base.array[ self->hash(val) % self->base.maxsize ] != 0 )\
        {\
            if( self->base.array[ self->hash(val) % self->base.maxsize ] == val )\
            {\
                return &self->base.array[ self->hash(val) % self->base.maxsize ];\
            }\
            else\
            {\
                if( self->base.array[ self->rehash(val) % self->base.maxsize ] != 0 )\
                {\
                    if( self->base.array[ self->rehash(val) % self->base.maxsize ] == val )\
                    {\
                        return &self->base.array[ self->rehash(val) % self->base.maxsize ];\
                    }\
                    return nullptr;\
                }\
                return nullptr;\
            }\
        }\
        return nullptr;\
    }

    typedef struct type##SecondHash##bits
    {   HashSet##bits(type) base;
\
        uint##bits##_t (*rehash)( type , ... );\

    }type##SecondHash##bits;

    type##SecondHash##bits* type##SecondHash##bits##Init(type##SecondHash##bits* self, ...)
    {   if(self == nullptr){return nullptr;}



        return self;
    }





    typedef struct type##BinsAndBalls##bits
    {   HashSet##bits(type) base;
    }type##BinsAndBalls##bits;

    type##BinsAndBalls##bits* type##BinsAndBalls##bits##Init(type##BinsAndBalls##bits* self, ...)
    {   if(self == nullptr){return nullptr;}
\

\
        return self;
    }

*

///type##HashSet##bits##Init , Class##Init

///type* type##HashSet##bits##Search( type##HashSet##bits*, type* );\

    ///from old rehash function

    if( i == 0 )\
    {\
        return 1;\
    }\
    val = ((val << i) ^ val)* 0x405b80;\
\
    if( self->base.array[ self->hash(val) % self->base.maxsize ] != 0 )\
    {\
        return self->hash(val) % self->base.maxsize + 2 *\
\
        type##HashSet##bits##ReHash(self, val, i - 1);\
    }\
    else\
    {\
        return val;\
    }\
                    /// ...

                    /// recursive find prime number function

    size_type type##HashSet##bits##Findprime( size_type size )\
    {\
        if( size <= 0 )\
        {\
            return 1;\
        }\
        size_type count = 0, i;\
\
        for(i = size;i > 0;i--)\
        {\
            if( size % i == 0 )\
            {\
                count++;\
            }\
            if( count > 2 )\
            {\
                break;\
            }\
        }\
        if( count == 2 )\
        {\
            return size;\
        }\
        return type##HashSet##bits##Findprime( --size );\
    }\
\
    uint##bits##_t type##HashSet##bits##Hash(uint##bits##_t, uint##bits##_t);\

\
    bool type##HashSet##bits##SkipNextRecursive( type##Hash##Iterator##bits* self )\
    {\
        if( *(((type##Iterator*)self)->p) != 0 )\
        {\
            return true;\
        }\
        if( (((type##Iterator*)self)->p) == (self->back + 1) )\
        {   --(((type##Iterator*)self)->p);\
            return false;\
        }\
        type##HashSet##bits##SkipNext( ++(((type##Iterator*)self)->p) );\
    }\
\
    bool type##HashSet##bits##SkipBackRecursive( type##Hash##Iterator##bits* self )\
    {\
        if( *(((type##Iterator*)self)->p) != 0 )\
        {\
            return true;\
        }\
        if( (((type##Iterator*)self)->p) == (self->array - 1) )\
        {   ++(((type##Iterator*)self)->p);\
            return false;\
        }\
        type##HashSet##bits##SkipBack( --(((type##Iterator*)self)->p) );\


/**
 *        second hash  (32 bit)
 *
 * @brief i gets incremented for each collision
 * the value x in x - ( hashval % x )
 * re-hashes more when it is smaller
 * but it also fills itself completely
 * full more often.
 *
size_t reHashstring(size_t hashval, size_t i )
{   size_t reHashstr(size_t);
    return i * reHashstr( hashval ) * 0.5;
}
size_t reHashstr( size_t hashval )
{  //      7 - ( hashval % 7 );
    return 3 - ( hashval % 3 );
}

*/

    /*
    OStream* cout = new(OStream)(this);

    if( cout == nullptr ){ puts("memory failure");return; }

    cout->out(cout, 1) //

    ->out(cout, 1)->out(cout, 2)

    ->out(cout, 3)->out(cout, 5)
                        //follow the pattern of C++ with friend
    ->out(cout, 8)->out(cout, 1)
                        //functions placed with the class so that
    ->out(cout, 1)->out(cout, 0);
                        //its for the stream object to use the first
    O(printf)("\n%d\n\n\n", cout->count);
                        //parameter as its own self pointer.
    IStream* cin = new(IStream)(this);

    if( cin == nullptr ){ puts("memory failure");return; }

    ((P)((P)((P)F(cin))(cin))(cin))(cin);

    ///(f_type)((f_type)((f_type)cin->in(a, b))(a, b))(a, b)

    delete(cout);
    delete(cin);





            while( *iter == 0 )\
            {\
                iter++;\
\
                if( iter == back )\
                {   iter--;\
                    break;\
                }\
            }\

/*printf("array allocation failure, size: %d\n", size);*/
/*printf("length: %d, old length: %d, flag: %d\n", ((type##Vector*)self)->length, length, p);
    */
/*printf("length: %d, old length: %d, flag: %d\n", ((type##Vector*)self)->length, length, flag);*/

/*printf("null probe return\n");*/

/*printf("resize failure\n");*/
    /**
            if( p == nullptr )\
            {\
                return false;\
            }\
            else \
    \
            if( pref == 0 )\
            {\
                return false;\
            }\
            else \
            {\
                asgn;\
    \
                ((type##Vector*)self)->length--;\
    \
                return true;\
            }\
     */


    /*



            /**
            FactoryMethod methA = FactoryTable(Interface)
                                    .map( ftable, typeid(a) ),

                          methB = FactoryTable(Interface)
                                    .map( ftable, typeid(b) );

            if( !methA || !methB )
            {
                throw( new(Exception) )(this, "NotFound");
            }

            Reg regA = methA->search("classPolymorphTable"),

                regB = methB->search("classPolymorphTable");

            if( !regA || !regB )
            {
                throw( new(Exception) )(this, "NotFound");
            }

            Polymorph * polyA = (()regA)

            return 0;*/

#if 0
            ///typeid(...)


            ///FactoryTable(Interface).map(...)

            //... this calls the String impl

            return 0;


    */
#endif // 0


/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/**

    TODO:

            create your dream programming language, C+ that's halfway between
            C++ and C with features like letting the programmer manage
            their own "Free" interface and doing much of the work in OOP still
            with typedef struct and its normal dot operator. feature libraries
            with all your datastructures including NodeRow (double-linked), NodeGrid, NodeMatrix,
            LinkedChart, Board, Heap & Stk, Table, Graph, Deque, Array, and vTable

            (especially array!)    Array<int>* array = new(Array<int>)(this);

                                   array[20][20];

                                   array[0][0] = 5;

                                   ~array();

                                   array[10][10][10][10];

                                   array[0][0][0][0] = 5;

                                   cout << array[0][0][0][0] << endl;

                                   delete(array);                              (done in C++)


                Similarities to C++:
                    - multiple inheritance
                    - templates
                    - operator overloading
                    - new and delete (from <vTable.h> or <vTable>)
                    - namespaces (namespacing structures)
                    - namespace operator :: (BSRO)

                        typedef struct A
                        {

                        }A;

                        namespace A          // same name?
                        {

                        };

                        typedef struct B

                        : static A           //multiple inheritance support
                        {

                        }B;

                        /* same as:

                        typedef struct B     //only simple inheritance
                        {
                            A base;

                        }B;

                        or:

                        typedef struct B     //: static A, C
                        {                   //byte datatype can be typedef unsigned char;
                            byte array[ sizeof(A) + sizeof(C) ];

                        }B;

                        #define castAtoB(var) ((B*)var)->

                        #define castAtoC(var) ( (C*) ( var + sizeof(B) ) )->

                        #define castBtoC(var) ( (C*) ( var + sizeof(B) ) )->


                        #define castCtoB(var) ( (B*) ( var - sizeof(B) ) )->

                        #define castCtoA(var) ( (A*) ( var - sizeof(B) ) )->

                        #define castBtoA(var) ( (A*) ( var - sizeof(B) ) )->

                             byte array[ sizeof(B) + sizeof(C) ];

              0xff      *----------*----------*   - starting address of A, B
                        |    B     |    A     |
                        |          |          |
                        *----------*          |
                        |                     |
                        |                     |
              0x1ff     *---------------------*   - starting address of C
                        |          C          |
                        |                     |
                        |                     |
                        *---------------------*
                        |    B                |   - B's data members...
                        |                     |
                        |                     |
                        *---------------------*



                Similarities to C:
                    - "Free" interfaces

                Objectives:
                    - provide a "Free" interface thats fully modifiable at any time from the programmer
                      who can then override parts of his/her interface by simply re-initializing a pointer
                      within his/her object (one providing an interface)

                    - provide a "Free" virtual table: static vtable that could be accessed and so used as
                      a place where an extra pointer to each non-automatic object is located

                    - overload the dot . operator

                Features:
                    - feature new and delete as macros: #include <vTable.h>                     (done)
                    - write the compiler that does multiple inheritance,
                        template support, operator overloading... (all same syntax as C++)      (not done)
                    - rely on polymorphism to hide data members (information hiding)            (done)

                    - think of how to go about overloading functions (through a pointer)
                    - use macros for namespacing (write C+ in C :D)
                    - operator overloading can check for an operator returned from an object then substitute function calls
                    - use macros for templates, include separate:

                            #include <vTable.h>    //include singleton static vtable with new(Class) and delete(object)
                                                  //also includes vector, hashset, ... structclass, Object, Iterator, Container

                            define Vector<int>;    //generate code for templates here

                            define Vector<struct class*>;  //multiple defines not a problem
                                                          //like multiple header includes
                            int main()
                            {
                                Vector<int>* v = new(Vector<int>)(this, ...);

                                v[ 0 ] = 5;

                                    //  same as:
                                    //
                                    //     (*v).operatorSubscript(v, 0) = 5;
                                    //
                                    //  or:
                                    //
                                    //     (*v).operatorSubscript(v, 0).operatorAssign(v, 5); (using proxy or "Helper")

                                delete(v);
                            }


                            size_type unsigned int:

                            typename(Vector)(Class, );



    /*
    defineVector(char, #ifdef OBJECT, #endif);

    \
     #_begin \
    \
            ((whatPtr*)self)[1]       = 0;\
    \
     #_end \


\
    \
        type##Iterator* new##type##Iterator( type * p )\
        {\
            type##Iterator * self = (type##Iterator*)\
    \
            allocate(sizeof(type##Iterator));\
    \
            if( self == nullptr ){ return nullptr; }\
    \
            ((dtorPtr*)self)[0] = 0;\
    \
            type##IteratorInit( self );\
    \
            self->p = p;\
    \
            return(self);\
        }

    /

    \
        type##HashIterator##bits* new##type##HashIterator##bits(\
    \
            type* iter, type* front, type* back)\
        {\
            type##HashIterator##bits* self = (type##HashIterator##bits*)\
    \
            allocate(sizeof(type##HashIterator##bits));\
    \
            if( self == nullptr ){return nullptr;}\
    \
            type##HashIterator##bits##Init(self, iter, front, back);\
    \
            return self;\
        }
















    #define defineHashIterator(type, bits)\
    \
        defineBasicVector(type)\
    \
        typedef struct type##HashIterator##bits\
        {   Iterator(type) base;\
    \
            type* front,* back;\
    \
        }type##HashIterator##bits;\
    \
    \
        type##HashIterator##bits* type##HashIterator##bits##Init(\
    \
            type##HashIterator##bits*, type*, type*, type* );\
    \
        bool type##HashIterator##bits##SkipNext(\
    \
            type##HashIterator##bits* );\
    \
        bool type##HashIterator##bits##SkipBack( type##HashIterator##bits* );\
    \
        type##HashIterator##bits* new##type##HashIterator##bits( type*, type*, type* );\
    \
    \
        type##HashIterator##bits* type##HashIterator##bits##Init(\
    \
            type##HashIterator##bits* self, type* iter, type* front, type* back)\
    \
        {   if( self == nullptr ){ return nullptr; }\
    \
            type##IteratorInit(self);\
    \
            (*self).base.p = iter;\
    \
            self->front = front;\
    \
            self->back = back;\
    \
            ((Iterator*)self)->foreward = & type##HashIterator##bits##SkipNext;\
    \
            ((type##Iterator*)self)->backward = & type##HashIterator##bits##SkipBack;\
    \
            return self;\
        }\
    \
        bool type##HashIterator##bits##SkipNext( type##Hash##Iterator##bits* self )\
        {\
            while(true)\
            {\
                if( *(((type##Iterator*)self)->p) != 0 )\
                {\
                    return true;\
                }\
                if( (((type##Iterator*)self)->p) == self->back )\
                {   --(((type##Iterator*)self)->p);\
                    return false;\
                }\
                ++(((type##Iterator*)self)->p);\
            }\
        }\
    \
        bool type##HashIterator##bits##SkipBack( type##Hash##Iterator##bits* self )\
        {\
            while(true)\
            {\
                if( *(((type##Iterator*)self)->p) != 0 )\
                {\
                    return true;\
                }\
                if( (((type##Iterator*)self)->p) == self->front )\
                {   ++(((type##Iterator*)self)->p);\
                    return false;\
                }\
                --(((type##Iterator*)self)->p);\
            }\
        }


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #define HashIterator(type, bits)    type##HashIterator##bits




        type##HashIterator##bits* type##HashSet##bits##Begin( type##HashSet##bits* self )\
        {\
            return new##type##HashIterator##bits(((Vector(type)*)self)->array,\
    \
            ((Vector(type)*)self)->array - 1, ((Vector(type)*)self)->array\
    \
            + ((Vector(type)*)self)->maxsize ); }\
    \
        type##HashIterator##bits* type##HashSet##bits##End( type##HashSet##bits* self )\
        {\
            return new##type##HashIterator##bits(((Vector(type)*)self)->array\
    \
            + ((Vector(type)*)self)->maxsize - 1, ((Vector(type)*)self)->array - 1,\
    \
            ((Vector(type)*)self)->array + ((Vector(type)*)self)->maxsize ); }


        \
        defineHashIterator(type, bits)\

        type##HashIterator##bits* type##HashSet##bits##Begin( type##HashSet##bits* );\
    \
        type##HashIterator##bits* type##HashSet##bits##End( type##HashSet##bits* );\
    \

    size_t i = 0;
    while( true )
    {
        i++;

        printf("%d", i);

        if( i == 5 )
        {
            goto throw;  //no throw keyword in plain C
                        //look for ways to define throw
                       //as this is more like the case number
                      //that its used for here
        }
    }               //maybe use a global error code list that gets checked
    throw:         //(stack of Exceptions)

    puts("broke loop");

        void cstringFill(char * a, const char * b)
    {
        if( *a == '\0' )
        {
            return;
        }
        if( *b == '\0' )
        {   *a = '\0';
            return;
        }
        *a = *b;
        cstringFill(++a, ++b);
    }

    size_t cstringSize(const char * a)
    {
        if( *a == '\0' )
        {
            return 0;
        }
        return 1 + cstringSize(++a);
    }

    void cstringEqual(bool * flag, const char * a, const char * b)
    {
        if( *a == '\0' && *b == '\0' )
        {   *flag = true;
            return;
        }
        if( *a != *b )
        {   *flag = false;
            return;
        }
        cstringEqual(flag, ++a, ++b);
    }

    void cstringGreater(bool * flag, const char * a, const char * b)
    {
        if( *a == '\0' || *b == '\0' )
        {   *flag = false;
            return;
        }
        if( *a < *b )
        {   *flag = false;
            return;
        }
        if( *a > *b )
        {   *flag = true;
            return;
        }
        cstringGreater(flag, ++a, ++b);
    }


        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief foreward (like next but with index)                *
         *                                                           *
         * @param self pointer                                       *
         * @param (size_type) move index (amount)                    *
         *                                                           *
         * @return true or false for operation success/failure       *
         ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **\
        bool type##IteratorForeward( Iterator(type) * self,\
    \
            size_type move )\
        {\
            if( self->p == nullptr )\
            {\
                return false;\
            }\
            self->p += move;\
            return true;\
        }\
    \

\
    \
        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief backward                                           *
         *                                                           *
         * @param self pointer                                       *
         * @param (size_type) move index (amount)                    *
         *                                                           *
         * @return true or false for operation success/failure       *
         ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **\
        bool type##IteratorBackward( Iterator(type) * self,\
    \
            size_type move )\
        {\
            if( self->p == nullptr )\
            {\
                return false;\
            }\
            self->p -= move;\
            return true;\
        }

        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief assign   (set)                                     *
         *                                                           *
         * @param self pointer                                       *
         * @param pointer to value                                   *
         ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **\
        void type##IteratorSet( Iterator(type) * self, type * p )\
        {\
            self->p = p;\
        }\
    \
    /*
        front-end macros will be class(member) for class##member
        unless its for a define(a) macro then its class(member)
        for member##class...(confusing but need to smooth that over)

        ...maybe just for Iterator because of Iterator base type
            and Iterator(type) derived type front-end
                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/*
    int main(int argc, char** argv) //command line arguments
    {
        f01();

        return 0;
    }
*/
/*

    #undef size_type
    #define size_type size_t

    define(Stk)(pException,

        define(Iter)(pException,

            define(N)(pException))); //implement data structure

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*            implement singleton initializer                 /
    pExceptionStk * pExceptionStkGetStk( pExceptionStk ** pself )
    {
        if( *pself != nullptr )
        {
            return *pself;
        }
        *pself = new(pExceptionStk)(this);//encapsulate new(Class)

        //pExceptionStkFunc.base.base.dtor = ...

        return *pself;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Stk(pException) * estack = nullptr; //singleton

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */

///https://www.youtube.com/watch?v=uinJ4orFwtk


    /*
     * macro used in place of normal constructor
     *//**
    #define exception(self, text)\
    \
        (self, _line_, _file_, _time_, _date_, text);\
    \
        goto block;


    #define try

    #define catch( pointer )\
    \
        block:         ;\
    \
        pointer = vPop();


    #define throw( instance )\
    \
        instance exception

*/
/*
    #define try \
    \
        Exception(Flag) = false; \
    \
        try_block: if( Exception(Flag) ){ goto catch_block; }


    #define throw( instance )\
    \
        instance exception


    #define exception(self, text)\
    \
        (self, _line_, _file_, _time_, _date_, text);\
    \
        Exception(Flag) = true;\
    \
        goto try_block;


    #define catch( pointer )\
    \
        catch_block:       ;\
    \
        const pointer = vTop();\
    \
        if( Exception(Flag) )
*/
        ///this all works until an exception doesn't get thrown then theres
        ///a block of code that causes an error,   (using goto)  but ...

        /// if setjmp()  and  longjmp()  are used with   try and catch being

        /// an if() {}  ...   if {}


        ///try =

        ///setjmp()

        ///if()

        ///catch =

        //if()

        ///for( ; ; goto  )




/*
    void function() {}

    #define exception(self, text)\
    \
        (self, _line_, _file_, _time_, _date_, text);\
    \
        Exception(Flag) = true;\
    \
        goto try_block;

    #define try  try_block: if( Exception(Flag) ){ goto catch_block; }

    #define catch( pointer )\
    \
        catch_block: if( Exception(Flag) )\
        {      ;\
            pointer = vPop();\
    \
            Exception(Flag) = false;
        }


    #define throw( instance )\
    \
        instance exception
*/
/**



    and make sure the constructor adds to a singleton stack:


    exceptions->push(exceptions, self);


    Stk(pException) * exceptions = new (pExceptionStk) (this);


    new (Exception) ex ("InputMismatch");

        and/or: (or a combination of)

    new (InputMismatch) ex ("... tell a story");



        (or)



    try
    {
        throw( new(Exception) )(this, "...");
    }
    catch( Exception * e )
    {
        e->...;

        //...

        delete(e);
    }




    #define try \
    \
        jumpFlag = setJump( envBuffer );\
    \
        if( !jumpFlag )


    #define catch( pointer )\
    \
        pointer = ( jumpFlag ? vPop() : nullptr );

        if( jumpFlag )


    #define throw( instance )\
    \
        instance exception

    #define exception(self, text)\
    \
        (self, _line_, _file_, _time_, _date_, text);\
    \
        longJump( envBuffer, true );


    and make sure the constructor adds to a singleton stack:


    exceptions->push(exceptions, self);


    Stk(pException) * exceptions = new (pExceptionStk) (this);


    now all thats left is some way to simulate throw using goto label:

    ...








        //self->length = stringSize(temp);
printf("%d..., %d..., ", newsize , self->length );
        /*charCopy
        (
                 self->array,

                 temp,
//stringF
                 &self->array[newsize - 1],

                 &temp[self->length - 1]
        );*/


    /*
        {
            {
                0,/*&ComparableDtor,/

                0/*&ComparableType/
            },

            0,//&StringEqual,

            0//&StringGreater
        },
    */
#if 0   ///(1 for use)

    #define defineHashSetQProbe(type, bits, ref, iref, comp)\

        type * type##QuadraticProbe##bits##qProbe(\
    \
            type##HashSet##bits * self, type info )\
        {\
            uint##bits##_t i = 1,\
    \
                           h = (self->hash(iref) % ((type##Vector*)self)->maxsize),\
    \
                           probe = h;\


            if( probe > ((type##Vector*)self)->maxsize / 2 )
    \
    \
            while(  ((type##Vector*)self)->maxsize         >     probe \
            \
                &&                 ref                     !=    0\
                  /*((type##Vector*)self)->array[probe]    !=    0*/\
                &&                       comp \
                  /*((type##Vector*)self)->array[probe]    !=    info*/\
                 )\
            {\
    \
    \
    \
                probe = h + (uint##bits##_t) pow(i, 2);\
    \
    \
    /*printf("probe: %d\n", probe);*/\
    \
    \
    \
                i++;\
    \
    \
    \
    \
    \
            } \
    /**
            add an extra increment or decrement when the probe goes back

            and forth or you always land on the same places    */\
    \
            if( probe < ((type##Vector*)self)->maxsize )
            {
                return &((type##Vector*)self)->array[ probe ]; \
            }


            i = 1;

            h = ((type##Vector*)self)->maxsize;

            probe = h;


            while(                    0                    <     probe \
            \
                &&                 ref                     !=    0 \
                /*((type##Vector*)self)->array[probe]    !=    0*/\
                &&                       comp \
                /*((type##Vector*)self)->array[probe]    !=    info*/
                 ) \
            { \
    \
    \
                if( typemax(size_type) - ((type##Vector*)self)->maxsize
                  > typemax(size_type) / 2 )
                { if( probe > typemax(size_type) - ((type##Vector*)self)->maxsize )
                  { break; }
                } else
                { if( probe > ((type##Vector*)self)->maxsize )
                  { break; } }


    \
                probe = h - (uint##bits##_t) pow(i, 2); \
    \
    \
    \
                i++; \
    \
    \
    \
    \
    \
            }\


    */\
            if( ((type##Vector*)self)->maxsize <= probe )\
            {\
                return nullptr;\
            }\
            else \
            {\
                return &((type##Vector*)self)->array[ probe ];\
            }\
        }


    \
        type##HashSet##bits * type##AbstractHashSet##bits##Init(\
    \
            type##HashSet##bits * self, ... )\
        {printf( #type "HashSet" #bits "Init()\n");\
            if( self == nullptr ){ return nullptr; }\
    \
            vaList list;\
    \
            vaStart(list, self);\
    \
            size_type c = vaArg(list, size_type), max;\
    \
            switch(c)\
            {\
                case 0:     **//** parameters: case, maxsize *//*\
    \
                    max = type##HashSet##bits##FindPrime(vaArg(list, size_type));\
    \
                    self = type##VectorInit(self, 0, max);\
    \
                    if( self == nullptr ){ return; }\
    \
                    type##HashSet##bits##InitArray( self );\
    \
                break;\
                case 1:     *//** parameters: case, obj *//*\
    \
                    self = type##VectorInit(self, 1, vaArg(list, type##Vector*));\
    \
                    if( self == nullptr ){ return; }\
    \
                break;\
                default:    *//** parameters: case = maxsize *//*\
    \
                    c = type##HashSet##bits##FindPrime(c);\
    \
                    self = type##VectorInit(self, c);\
    \
                    if( self == nullptr ){ return; }\
    \
                    type##HashSet##bits##InitArray( self );\
    \
                break;\
            }\
            vaEnd(list);\
    \
            self->hash = &_hash##bits;\
    \
            return self;\
        }\
    \
        void type##HashSet##bits##Dtor( type##HashSet##bits * self )\
    \
        { type##VectorDtor(self); }

#endif // 0
/**\

    I WOULD HAVE LEFT THIS define OOP: (C++) STUFF (BELOW) WHERE IT WAS BUT

    I HAVE COME ALONG WAY FROM SIMPLE C PROCEDURAL PROGRAMMING TO

    OOC USING A VIRTUAL TABLE AND SIMPLE INHERITANCE AS BASIC OBJECT

    ORIENTED PROGRAMMING, TO USING A FACTORY TABLE WITH A VIRTUAL TABLE

    (AND EVEN AN ADAPTER TABLE) AS OBJECT ORIENTED PROGRAMMING THAT FLYS

    PAST CURRENT DEFINITIONS OF IT IN OTHER PLACES, FACTORY C (C FACTORY)

    IS WHAT I HAVE WORKED MY WAY UP TO. SO EVEN THOUGH THESE EARLIER

    DEFINITIONS BY DOCUMENTATION OR DESCRIPTION WERE NOT BAD WHEN I WROTE

    THEM, THEY DO NOT SUFFICE WHEN IT COMES TO FACTORY C. I UNDERSTAND THAT

    IM WRITING DOCUMENTATION INSIDE A FILE CALLED TRASH BIN, BUT THAT GOES

    TO SHOW HOW I AM ABOUT SOMETHING AFTER ITS BEEN IMPLEMENTED, IS THAT I LIKE

    KEEPING IT THE WAY IT WAS ORIGINALLY IMPLEMENTED (JUST HERE IS BETTER).

    I WILL MAKE SURE DOCUMENT THIS ALL AGAIN IN A MORE PERMANENT PLACE.
*/

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /* define OOP:  (C++)                                                        *
     *                                                                           *
     *      C++ defines something called a bolted function. a bolted function is *
     * declared (prototyped) and implemented inside the body of a class. (derived*
     * from struct) The C++ compiler unbolts all bolted functions meaning that   *
     * where the function was located is where an implicit function pointer is   *
     * located, one that gets initialized to point to the name-spaced function   *
     * placed below. C++ provides to the programmer a static interface for each  *
     * class implementation, depending on something called a function object     *
     * (strategy function pattern) for any strategic capability. All C++ classes *
     * come with a built-in name-space mechanism.                                *
     *                                                                           *
     *      Multiple inheritance is based on composition with automatic memory   *
     * of sub objects, like simple inheritance with reserving the first data     *
     * field position for a base in C. Based on composition with the added       *
     * difficulty of having to increment and/or decrement a pointer, Multiple    *
     * inheritance does this implicitly when the pointer that points to the      *
     * object is casted to one of it's derived types. There are ways to arrange  *
     * this configuration in C, but it's never implicit. (Just having all the    *
     * types considered a base composite inside the derived object is enough to  *
     * then define a set of macros to use in the place of casts)                 *
     *                                                                           *
     *      Function overloading and function overriding are separate ends       *
     * of the same thing, function pointer re-initialization. Function           *
     * overloading can be simulated in C by using a pointer to call any one of a *
     * set of functions, re-initializing the pointer each time the function is   *
     * called. Function overloading in C++ is where multiple functions get       *
     * declared using the same name but different amounts of parameters and      *
     * different data types for its parameters, maybe different return types     *
     * but having only a different return type is not enough to overload a       *
     * function in C++. A function with a different set of parameters may        *
     * use a different return type properly.                                     *
     *                                                                           *
     *      Function overriding can be simulated in C with using simple          *
     * inheritance where the first data field position in the object is          *
     * reserved for the base type, and initializer functions are implemented in a*
     * way that the base initializer initializes the interface and the second    *
     * initializer calls the first initializer and then re-initializes any       *
     * amount of function pointers to point to new implementations. This is      *
     * a built-in mechanism in C++ where the bolted function is re-declared      *
     * (or prototyped) in derived with the one provided inside base (base &      *
     * derived) declared as virtual by keyword. When a virtual function is       *
     * initialized to null or 0 in the statement its declared                    *
     * this implies that the function pointer provided to the C++ vtable by the  *
     * bolted function prototype is initialized to null or 0, It implies this but*
     * restrains the operation of memory allocation for that class type until the*
     * function is re-declared in derived and implemented there.                 *
     *                                                                           *
     *      C++ defines something called a template. These may be either function*
     * templates or function templates or both. Templates can be simulated using *
     * the preprocessor directive define and the token concatenation operator    *
     * on global declarations placed inside.                                     *
     *                                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**
    THIS IS NOT IMPLEMENTED BUT WAS A PIPE DREAM BEFORE COMING TO FACTORY C.
 */
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /* define (C+):                                                              *
     *                                                                           *
     *      (C+) is a middle ground between C++ and C. C+ provides a "free"      *
     * interface like in C while defining multiple inheritance, templates,       *
     * namespaces, and operator overloading similar to C++. A virtual table      *
     * is made available to include into the program similar to the one used     *
     * in OOC.                                                                   *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#if 0
     - - you can then get rid of estack because you can access
         exceptions through the vstk functions, so the program
         will have an extra list of pointers to work with or just
         forget about, won't make a big difference just as long as
         the objects themselves get deleted then its just a spare
         list of pointers that solves a problem or two with its
         presence - -

     - - not that there should be a singleton for any iterator here
         but an easy function that returns one or the other - -
        v
    - - if its a singleton it might be good to check if self == 0
       in the implementation of every function for synchronizing
       (and not just Init (ctor))  - -

    - - in java: synchronize is a keyword used in function declaration

        but also to make a block thats synchronized, ...

        so a synchronized function would entirely be in a synchronized

        block, so try defining: synchronized ( ClassName.member ){}- -

    - - in java: volatile is used as "double checked locking" so

        struct vtable would be declared as volatile here too since

        its a keyword from C - -

            - - there is similarities to a state machine
                pattern with this* being initialized to the object
                that was last added - -
        - - the destructor doesn't get initialized for automatic
            memory with the current patterns - - OLD

#endif // 0
/*

            THIS IS A GOOD WORKING QUADRATIC PROBE FUNTION THAT OPERATES WITHOUT
            ERROR JUST IT DOESNT DO WHAT I EXPECTED IT TO DO. (CASE WISE)

    #define defineHashSetQProbe(type, bits, ref, iref, comp)\
    \
        type * type##QuadraticProbe##bits##qProbe(\
    \
            type##HashSet##bits * self, type info )\
        {\
            const size_type  max = ((type##Vector*)self)->maxsize;\
    \
            uint##bits##_t     i = 1,\
    \
                               h = (self->hash(iref) % max),\
    \
                           probe = h;\
    \
            bool           flag  = false; \
    \
    \
    \
            if( probe < max / 2 ) { flag = true; }\
    \
            for( size_type index = 0; index < 2; index ++ )\
            {\
    \
    \
                i = 1;\
    \
    \
                while(                 ref                     !=    0\
                      /*((type##Vector*)self)->array[probe]    !=    0/\
                    &&                       comp \
                      /*((type##Vector*)self)->array[probe]    !=    info/\
                     )\
                {\
    \
    \
    \
    \
    \
                    if( flag ){ probe = h + (uint##bits##_t) pow(i, 2); }\
    \
                    else      { probe = h - (uint##bits##_t) pow(i, 2); }\
    \
    \
    \
    \
    \
                    i++;\
    \
    \
        /*printf("probe: %u\nq: %u\n", probe, 1 + (uint##bits##_t) pow(i, 2) );/\
    \
    \
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * /\
                    /**                   CheckForOutOfBounds                    */\
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * /\
                    if( typemax(size_type) - max > typemax(size_type) / 2 )\
                    { if( probe > typemax(size_type) - max || probe > max - 1 ) \
                      { break; }\
                    } else \
                    { if( probe > max - 1 )\
                      { break; } }\
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * /\
    \
    \
                } \
                if( probe < max )\
                {\
                    return &((type##Vector*)self)->array[ probe ]; \
                }\
                else if( index == 0 )\
                {\
                    if( flag )\
                    { flag = false; \
    \
    \
                      probe = h - (uint##bits##_t) pow(i, 2);\
    \
    \
                      if( probe + 1 < max )\
                      { probe += 1; } else { probe -= 1; }\
    \
    \
                    } else \
                    { flag = true; \
    \
    \
                      probe = h + (uint##bits##_t) pow(i, 2);\
    \
    \
                      if( probe - 1 < max )\
                      { probe -= 1; } else { probe += 1; } \
    \
    \
                    } \
    \
                } \
    \
            } \
            if( probe > max - 1 )\
            {\
                return nullptr;\
            }\
    \
        }

    */


        /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief vector initializer, incompatible with new(Class)   *
         *        proper initializer gets implemented in separate    *
         *        file since the vtable is a Vector(type) and the    *
         *        Vector(type) has functions that encapsulate        *
         *        new(Class) that get implemented with the proper    *
         *        initializer to use with new(Class)                 *
         *                                                           *
         * @param self pointer                                       *
         * @param see above for factory initializer info             *
         *                                                           *
         * @return self for initializing Object (pointer)            *
         ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/\
/*        Vector(type) * type##BasicVectorInit( Vector(type) * self, ... )\
        {printf(#type "BasicVectorInit()\n");\
            if( self == nullptr ){ return nullptr; }\
    \
            vaList list;\
    \
            vaStart(list, self);\
    \
            size_t c = vaArg(list, size_t);\
    \
            type##Vector * other;\
    \
            switch(c)\
            {\
                case 0:\
    \
                    self->maxsize = vaArg(list, size_type);\
    \
                    if( !self->maxsize )\
                    {\
                        self->array = nullptr;\
                    }\
                    else \
                    {\
                        self->array = (type*)allocate(\
    \
                            sizeof(type) * self->maxsize );\
    \
                        if( self->array == nullptr ){ return nullptr; }\
                    }\
    \
                break;\
                case 1:\
    \
                    other = vaArg(list, type##Vector *);\
    \
                    self->maxsize = other->maxsize;\
    \
                    self->array = (type*)allocate(\
    \
                        sizeof(type) * self->maxsize );\
    \
                    if( self->array == nullptr ){ return nullptr; }\
    \
                    type##VectorCopy(self, other);\
    \
                break;\
                default:\
    \
                    self->maxsize = c;\
    \
                    self->array = (type*)allocate(\
    \
                        sizeof(type) * self->maxsize );\
    \
                    if( self->array == nullptr ){ return nullptr; }\
    \
                break;\
            }\
            vaEnd(list);\
    \
            self->length = 0;\
    \
            return self;\
        }\
    */
#if 0
                enum [Set]Enum { [En0], [En1], [En2], ... [En] };

            ...

            void* [Set]Array[n] = { p1, p2, p3, ... pn };

            ...

            typedef type1 [En1][Set];

            typedef type2 [En2][Set];

            typedef type3 [En3][Set];

            typedef typen [Enn][Set]; ...

            ...

            typedef void        p[Set]0n    (type* self, ...); ...

            typedef p[Set]0n*   p[Set]03    (type* self, ...);

            typedef p[Set]03*   p[Set]02    (type* self, ...);

            typedef p[Set]02*   p[Set]01    (type* self, ...);

            typedef p[Set]01*   p[Set]00    (type* self, ...);

            ...

            typedef void        [Enn][Set]  (type* self, ...); ...

            typedef p[Set]0n*   [En3][Set]  (type* self, ...);

            typedef p[Set]03*   [En2][Set]  (type* self, ...);

            typedef p[Set]02*   [En1][Set]  (type* self, ...);

            typedef p[Set]01*   [En0][Set]  (type* self, ...);

            ...

            extern  void        [Set]0n     (type* self, ...); ...

            extern  p[Set]0n*   [Set]03     (type* self, ...);

            extern  p[Set]03*   [Set]02     (type* self, ...);

            extern  p[Set]02*   [Set]01     (type* self, ...);

            extern  p[Set]01*   [Set]00     (type* self, ...);

            ...

            [En3][Set]* = template([Set], [En1])(...)(...);

#endif // 0
                /**
        i think that the ultimate pattern for this file

        or this file's true intent, what its original intent

        was before anything was even defined or here...

        (try and remember)

        template( Set, Case )(...)(...)(...)(...)(...)(...);


        thats like an array full of a list o possibilities:

        now you have a way to actually pass parameters into

        them. now you have a way to actually be in full

        control of your datatypes implementing functions

        that take abstract data types for parameters: A.K.A.

        void * A.K.A. Object * A.K.A. Class A.K.A. ...


        there can be a separate array for returns...

        or an array of stacks


        continue( Set, Case )(...)(...)(...)(...)(...);

            dont forget:

        continue;

            is different from:

        continue(...);

            the preprocessor can tell the difference.
                                                                 */



    /*#define defineHashSetQProbe(type, bits, iref, comp, equl, neql, icmp, ineq, move, prnt)*/

    /*    defineHashSetQProbe(Key##Value##Pair, Bits,  info.key,\
    \
                                                       self->base.array[probe].key == 0,\
    \
                                                       self->base.array[probe].key == info.key,\
    \
                                                       self->base.array[probe].key != info.key,\
    \
                                                       info.val != 0,\
    \
                                                       info.val == 0,\
    \
                                                       (*slot) = self->base.array[probe];\
    \
                                                       self->base.array[probe].key = 0;\
    \
                                                       self->base.array[probe].val = 0,\
    \
                                                       defineHashSetQProbePrint \
    \
          );
    #define defineHashSetQProbePrint \
    \
                    if( PrintFlags[4] )
                    {
                        printf("\nprobe return: %u", probe);

                        ifOutOfBounds( maxsize, probe, printf(" (OutOfBounds)") );

                        printf("\nfound: %s\n", ( found ? "true" : "false" ) );

                        if ( found ) {

                            printf("(coming out)\ntypeid: %s\n",

                                   self->base.array[ probe ].val->what()  ); }
                        else

                        if ( info.val != 0 ) {

                            printf("(going in)\ntypeid: %s\n",  info.val->what()  );
                        } }
            */
        /**
        @brief THIS IMPLEMENTATION OF A QUADRATIC PROBE FOR THE VOLATILE PROGRAM LEVEL TABLES.

        THIS PULLED OUT OF TEMPLATE FORM (MACRO IMPLEMENTATION) TO WHERE/HOW IT SITS

        NOW AND (WAS) USED FOR DEBUGGING.


        DEBUGGING IS DONE AND THE VIRTUAL TABLE IS BETTER THAN EVER, WITH ITS ASSOCIATE TABLES

        SHARING THE SAME MACRO DEFINITION, BUT NOT COMPILER IMPLEMENTATION.
        */
#if 0  //(this one is even one worth using or is a copy of the one still in use)
        ClassClassVirtualTablePair * ClassClassVirtualTablePairQuadraticProbe32QProbe(

            ClassClassVirtualTablePairHashSet32 * self, ClassClassVirtualTablePair info )

        {

            ClassClassVirtualTablePair * slot = nullptr;

            const size_type           maxsize = self->base.maxsize;

            uint32_t                        i = 0,/*<---  (i = 1)*/

                                            h = (self->hash(info.key) % maxsize),

                                        probe = h;/*<---*/

            bool                        pivot = false,

                                        flag  = false;

                                        found = false;



            if( probe < ( maxsize / 2 ) ) { pivot = true; }/**pivot*/



            for( uint8_t index = 0; index < 2; index ++ )
            {





                i = 0;/*<---  (i = 1)*/

                probe = h;/*<---*/





                while ( true )
                {
        /**
                while(  (  self->base.array[probe].key         !=    0  )
                    *//*((type##Vector*)self)->array[probe]    !=    0*//**
                    &&  (  self->base.array[probe].key         !=    info.key  )
                    *//*((type##Vector*)self)->array[probe]    !=    info*//**
                     )
                {
         */



            if( PrintFlags[4] ){ if ( pivot ){ printf("\nprobe+: %u", probe); ifOutOfBounds(
                                           maxsize, probe, printf(" (OutOfBounds)") );
                                           printf("\n"); }
                                    else { printf("\nprobe-: %u", probe); ifOutOfBounds(
                                           maxsize, probe, printf(" (OutOfBounds)") );
                                           printf("\n"); } }



                    /** TRYING TO ADD BUT ALREADY THERE (SHOULDN'T HAPPEN) */
                    if( ( self->base.array[probe].key    ==    info.key ) && ( info.val != 0 ) )
                            {  return nullptr;  }

                    /** COMING OUT (FOUND) */
                    if( ( self->base.array[probe].key    ==    info.key ) )
                            {  found = true;  break;  }

                    /** GOING IN (STOP LOOKING) */
                    if( ( self->base.array[probe].key    ==    0 ) && ( info.val != 0 ) )
                            {  break;  }

                    /** COMING OUT (KEEP LOOKING) */
                    if( ( self->base.array[probe].key    ==    0 ) && ( info.val == 0 ) )
                            {  if(!slot){ slot = & self->base.array[probe]; }  }





                    i++;/**quadratic counter*/




                                         /**(uint32_t)*/
                    if( pivot ){ probe = h + (uint32_t) pow(i, 2) + 1; }/* + 1 */
                    else       { probe = h - (uint32_t) pow(i, 2) - 1; }/* - 1 */





                    /*i++;*/





                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
                    /**                   CheckForOutOfBounds                    */
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
                    if( ( typemax(size_type) - maxsize ) < ( typemax(size_type) / 2 ) )
                    { if( pivot )
                      { if( probe < ( typemax(size_type) / 2 ) ){ flag = true; break; } }
                      else
                      { if( probe > ( typemax(size_type) / 2 ) ){ flag = true; break; } }
                    }
                    else
                    { if( probe > maxsize - 1 )
                      { flag = true; break; } }
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */





                }/** IF OBJECT FOUND OR FOUND SLOT TO PUT NEW ONE */
                if( found || !flag )
                {
                    if( ( self->base.array[probe].key == 0 ) && ( info.val != 0 ) ) { }

                    if( PrintFlags[4] )
                    {
                        printf("\nprobe return: %u", probe);

                        ifOutOfBounds( maxsize, probe, printf(" (OutOfBounds)") );

                        printf("\nfound: %s\n", ( found ? "true" : "false" ) );

                        if ( found ) {

                            printf("(coming out)\ntypeid: %s\n",

                                   self->base.array[ probe ].val->what()  ); }
                        else

                        if ( info.val != 0 ) {

                            printf("(going in)\ntypeid: %s\n",  info.val->what()  );
                        } }

                     /** IF OBJECT FOUND AND FOUND SLOT (AND IS ALREADY IN TABLE)
                         AND NULL INFO INTERFACE SO JUST SEARCHING */
                    if( found && slot ) /* && (info.val == 0)*/
                    {
                        (*slot) = self->base.array[probe];


                        self->base.array[probe].key = 0;

                        self->base.array[probe].val = 0;


                        /** RETURN SLOT WITH OBJECT */
                        return slot;

                    }

                    /** RETURN SLOT WITH OBJECT OR NO */
                    return & self->base.array[ probe ];

                }
                else if( index == 0 )
                {

                    if( pivot )
                    { pivot = false;


                      h = h + (uint32_t) pow(i - 1, 2) + 1;/** + 1*/
                        /*h = h + (uint##bits##_t) pow(i - 1, 2);*/


                      if( h + 1 < maxsize )
                      { h += 1; } else { h -= 1; }/**offset*/


                    } else
                    { pivot = true;


                      h = h - (uint32_t) pow(i - 1, 2) - 1;/** - 1*/
                        /*h = h - (uint##bits##_t) pow(i - 1, 2);*/


                      if( h - 1 < maxsize )
                      { h -= 1; } else { h += 1; }/**offset*/


                    }
                    flag = false;
                    ifOutOfBounds( maxsize, h, break );
                }

            }
            ifOutOfBounds( maxsize, probe,

            if( PrintFlags[4] ){ printf("\nnull return\nfound: %s\n",

                    ( found ? "true" : "false" ) ); }
            /** LOOKED FOR AS LONG AS IT COULD GIVEN O( n / 2 q ) */
            return nullptr; ); return nullptr;
        }
#endif // 0



#ifdef                OBSERVERTABLESINGLETON
    void ObserverTable(Begin)(void)attribute((constructor));

    void ObserverTable(End)(void)attribute((destructor));
#endif // OBSERVERTABLESINGLETON
#ifdef                DECORATORTABLESINGLETON
    void DecoratorTable(Begin)(void)attribute((constructor));

    void DecoratorTable(End)(void)attribute((destructor));
#endif // DECORATORTABLESINGLETON

    #ifndef OBSERVERTABLESINGLETON
    #define OBSERVERTABLESINGLETON 1 //true





    #endif//OBSERVERTABLESINGLETON
    #ifndef DECORATORTABLESINGLETON
    #define DECORATORTABLESINGLETON 1 //true




    #endif//DECORATORTABLESINGLETON
            /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
            /**                   CheckForOutOfBounds                    */
            /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /**     if( ( typemax(size_type) - maxsize ) > ( typemax(size_type) / 2 ) )
            { if( ( probe > typemax(size_type) - maxsize ) || ( probe > maxsize - 1 ) )
                { break; }
            } else
            { if( ( probe ) > ( maxsize - 1 ) )
                { break; } }                                                        */
            /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

                    /** TRYING TO ADD BUT ALREADY THERE (SHOULDN'T HAPPEN) *//*
                    if( ( self->base.array[probe].key    ==    info.key ) && ( info.val != 0 ) )
                            {  return nullptr;  }

                  *//** COMING OUT (FOUND) *//*
                    if( ( self->base.array[probe].key    ==    info.key ) )
                            {  found = true;  break;  }

                  *//** GOING IN (STOP LOOKING) *//*
                    if( ( self->base.array[probe].key    ==    0 ) && ( info.val != 0 ) )
                            {  if(!slot){ slot = & self->base.array[probe];  }  break;  }

                  *//** COMING OUT (KEEP LOOKING) *//*
                    if( ( self->base.array[probe].key    ==    0 ) && ( info.val == 0 ) )
                            {  if(!slot){ slot = & self->base.array[probe]; }  } */
            /**
                slot->key = self->base.array[probe].key;

                slot->val = self->base.array[probe].val;
             */


    /// Duck * duck = adapter(Turkey, Duck)(this, ...);

    /// this will require new namespacing techniques that involve

    /// namespacing functions under Adapter and the alternate

    /// classname or the class to adapt to: TurkeyAdapterInterface

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    ///                  inside of: Duck.h
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    ///

/**
        there are multiple strategies as to create an adapter,

        one way is to re-assign the objects interface assigned

        to it from new()() is all, that would be re-assigning

        an objects interface stored in the vtable, there are other

        ways to create an adapter(s) that involve using the ftable,

        one of those ways is to use the AdapterTable provided in

        structclass.h (the actual registration adapter) you can

        just implement a what() function that gives the description

        of what it (your class object) is being adapted to so you

        can iterate through a classes list of registrations in the

        ftable for its specific adapter. the what() function would

        then return the description of your adapter so you can use

        it accordingly, the ftable strategy for creating an adapter

        is recommended at least for when there are multiple adapters.

        and either way, whichever strategy you use for your adapter(s)

        its probably going to involve having at least one extra

        instance of a ClassVirtualTable for a class, one thats declared

        globally and initialized globally to constant values (your

        global functions returning their addresses by addressof &)

        that would be named accordingly (and separate from

        ClassNameInterface or ClassInterface, the interface that gets

        assigned by default using new()() ) and initialized

        accordingly to the extra implementations of "Adapter" functions

        so there can be an AdapterClassInterface or ClassAdapterInterface

        beside ClassInterface ... and ...


            Duck * turkey = adapter(Duck, Turkey) (this, ...) ;


            but what ctor would that be using?
    *//*



            but dont forget:   Adapter * a = adapter() do we want to use this ClassType?


        just the reason why template was always a file here,

        but to actually make that second statement work would require

        not only expertise, but something other than the function

        provided by VirtualTable(Interface) and things like a volatile

        flag and an extra constructor case inside the constructor

        at the start of it, a function that returns a function

        that returns a function, (but what about a variable amount?)

        adapter()() as shown above could hide a cast so when the return

        returns the other way back to the pointer it gets casted

        from a function pointer type to object type, and i could use a

        stack maybe...


        adapter(Class, Adapter) (this, ...) ONLY USES THE CONSTRUCTOR

        (LIKE IT SHOULD). THE ONLY THING WITH MORE THAN ONE FUNCTION

        CALL LIKE THAT IS THE CONTROL FACTORY (FACTORY CONTROL SEQUENCE)

        (using). using IS EVEN JUST THE CONTROL FACTORY INITIALIZER

        THAT RETURNS #00 - #99

    *//**
        when it becomes a responsibility of the class to have adapter()

        encapsulated inside a function that returns the constructors datatype

        it will be the time to create fully dynamic instances following

        the same pattern as with new(), (with the ftable delegating to vtable)

        not any sooner or there may be unforseen structural problems.


        also consider a two way adapter...


        there are two kinds of adapters, object adapters and class adapters

        object adapters have been discussed so far,


        multiple inheritance is needed for class adapters


     */

    #define adapter(Class, Adapter) (Adapter *)VirtualTable(Interface)\
    \
        .insert( vtable, vstk, (Adapter *)allocate(sizeof(Adapter)), \
    \
        & Class##Adapter##AdapterInterface, & Class##Adapter##AdapterInit )


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief                                                    *
     *   - -                                               - -   *
     * @param                                                    *
     *   - -                                               - -   *
     * @return                                                   *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**
        THIS FUNCTION MUST SEARCH EACH RegList FOR "classFunctionsTable"

        AND SEARCH EACH "classFunctionsTable" FOR THE "ClassFunction"

        THAT IS NEEDED FROM THERE, FROM THERE IT CAN RETURN THE

        ADDRESS OF THAT FUNCTION FOR ASSIGNING A POINTER INSIDE

        override THE CENTRAL OVERRIDE METHOD ALSO class(override)

        BY FUNCTION NAME.
     */
    explicit Object * FactoryTable(Override)

        ( volatile fTable * volatile self, cstring funcName )

    {}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *  <OOC library that defines Object-Oriented essentials in C (C+)>  *
 *                                                                   *
 * Copyright (C) <2017 - 2021>  <Christopher Bond>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /*
    #define observer(Class, Observer) (Observer *)VirtualTable(Interface)\
    \
        .insert( vtable, vstk, (Observer *)allocate(sizeof(Observer)), \
    \
        & Class##Observer##ObserverInterface, & Class##Observer##ObserverInit )
     */

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                                                ;
    #if 0
    /**+---------------------------------+
     * @brief Decorator interface        |
     * +---------------------------------+
     */ ///(ADVANCED) NOT FULLY DEVELOPED (ADVANCED)
    typedef struct DecoratorAtom
    {   struct class base;

        struct DecoratorAtom * volatile link;///<---self

        Object * self; //self for interface (wrapped object)

    }DecoratorAtom;

    typedef struct DecoratorAtomVirtualTable
    {   struct class (VirtualTable) base;///need to know
    }DecoratorAtomVirtualTable;/// what part of the atom WHAT()


    static DecoratorAtom * DecoratorAtomInit

        ( DecoratorAtom *, Object * );


    explicit DecoratorAtom * DecoratorAtomInit

        ( DecoratorAtom * self, Object * host )

        { if(!self){return 0;}

            self->link = nullptr; ///DONT TOUCH WHEN NUCLEUS

            self->self = host;

            return self; }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**||     DECORATOR PATTERN (ATOM, NUCLEUS, ELECTRON)     || *
     *                                                           *
     *             by Willy (01/02/2022)                         *
     * ||                                                     || */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    typedef struct DecoratorElectron DecoratorElectron;

    typedef DecoratorElectron * pDecoratorElectron;

    typedef struct
    {   DecoratorAtom base;

        Container * rings ;//Vector(pDecoratorElectron)... NodeRow?

    }DecoratorNucleus;

    typedef struct DecoratorNucleusVirtualTable
    {   DecoratorAtomVirtualTable base;
    }DecoratorNucleusVirtualTable;


    static DecoratorNucleus * DecoratorNucleusInit

        ( DecoratorNucleus *, Object *, Container * );

    static void DecoratorNucleusDtor( DecoratorNucleus * );

    static cstring DecoratorNucleusType();


    explicit DecoratorNucleus * DecoratorNucleusInit

        ( DecoratorNucleus * self, Object * host, Container * rings )

    { if(!self){return 0;}

        self = DecoratorAtomInit(self, host);

        self->rings = rings;///INITIALIZE ALL TO 0 YOURSELF

        return self;}


    explicit void DecoratorNucleusDtor( DecoratorNucleus * self )

    { if( self->rings )
        {
        size_t size = virtual( self->rings, Container )->size(this);

        for( size_t i; i < size; i++ )
        {
            delete( (*(pDecoratorElectron*)

                virtual( self->rings, Container )->at(this, i) ) );
        }
        delete( ((DecoratorAtom*)self)->self );

        delete(self->rings); } }

  explicit
    cstring DecoratorNucleusType()
    { return "DecoratorNucleus"; }

    static DecoratorNucleusVirtualTable

        DecoratorNucleusInterface =

    { { { &DecoratorNucleusType,

          &DecoratorNucleusInit,

          &DecoratorNucleusDtor
        }
      }
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    struct DecoratorElectron
    {   DecoratorAtom base;

        DecoratorAtom * prev;
    };


    typedef struct DecoratorElectronVirtualTable
    {   DecoratorAtomVirtualTable base;
    }DecoratorElectronVirtualTable;


    static DecoratorElectron * DecoratorElectronInit

        ( DecoratorElectron *, size_t,

          DecoratorAtom *, Object * );

    static void DecoratorElectronDtor( DecoratorElectron * );

    static cstring DecoratorElectronType();


    explicit DecoratorElectron * DecoratorElectronInit

        ( DecoratorElectron * self, size_t index,

          DecoratorAtom * atom, Object * object )

    { if(!self){return 0;}

        if( (*(pDecoratorElectron*) virtual( ((DecoratorNucleus*)atom)
            ->rings, Container )->at(this, index) ) == 0 )
        { ((DecoratorAtom*)self)->link = atom; }
        else
        {
        ((DecoratorAtom*)self)->link =
            (*(pDecoratorElectron*) virtual( ((DecoratorNucleus*)atom)
            ->rings, Container )->at(this, index) ); }

        (*(pDecoratorElectron*) virtual( ((DecoratorNucleus*)atom)
            ->rings, Container )->at(this, index) ) = self;

        self->prev = atom;

        ((DecoratorAtom*)self)->self = object;

        ((Object**)object)[0] = atom->self;//hook up the real

        return self; }


    explicit void DecoratorElectronDtor( DecoratorElectron * self )

    { if( ((DecoratorAtom*)self)->link == nullptr ){ return; }

            DecoratorElectron * node = self;

            self = ((DecoratorAtom*)self)->link;

            delete(  ((DecoratorAtom*)node)->self  );

            delete(node);

            DecoratorElectronDtor(self); }

  explicit
    cstring DecoratorElectronType()
    { return "DecoratorElectron"; }

    static DecoratorElectronVirtualTable

        DecoratorElectronInterface =
        {
          {
            {
              &DecoratorElectronType,

              &DecoratorElectronInit,

              &DecoratorElectronDtor } } };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    typename(N)(pDecoratorElectron) ;

    #if 0
    #define decorator(Class, Decor) (Decor*)\
    \
        VirtualTable(Interface).insert( vtable, vstk, (Decor*)\
    \
        allocate(sizeof(Decorator)), & Class##Decorator##DecoratorInterface,\
    \
        & Class##Decorator##DecoratorInit )



    /*
    #define defineHashSetQProbe(type, bits, iref, comp, eqls, ineq, icmp, move, prnt)*/

    /*    defineHashSetQProbe(Key##Value##Pair, Bits,  info.key,\
    \
                                                       self->base.array[probe].key == 0,\
    \
                                                       self->base.array[probe].key == info.key,\
    \
                                                       info.val != 0,\
    \
                                                       info.val == 0,\
    \
                                                       (*slot) = self->base.array[probe];\
    \
                                                       self->base.array[probe].key = 0;\
    \
                                                       self->base.array[probe].val = 0,\
    \
                                                       defineHashSetQProbePrint \
    \
          );
    #define defineHashSetQProbePrint \
    \
                    if( PrintFlags[4] )
                    {
                        printf("\nprobe return: %u", probe);

                        ifOutOfBounds( maxsize, probe, printf(" (OutOfBounds)") );

                        printf("\nfound: %s\n", ( found ? "true" : "false" ) );

                        if ( found ) {

                            printf("(coming out)\ntypeid: %s\n",

                                   self->base.array[ probe ].val->what()  ); }
                        else

                        if ( info.val != 0 ) {

                            printf("(going in)\ntypeid: %s\n",  info.val->what()  );
                        } }
    */

                                               //iref == info ref not iter ref
    #define defineHashSetQProbe(type, bits, ref, iref, comp, eqls)\
    \
        type * type##QuadraticProbe##bits##QProbe(\
    \
            type##HashSet##bits * self, type info )\
    \
        {if( PrintFlags[1] ) { printf("\n" #type "HashSet" #bits "QProbe\n"); }\
    \
            const size_type  maxsize = ((type##Vector*)self)->maxsize;\
    \
            uint##bits##_t         i = 0,/*<---  (i = 1)*/\
    \
                                   h = (self->hash(iref) % maxsize),\
    \
                               probe = h;/*<---*/\
    \
            bool               flag  = false; \
    \
    \
    \
            if( probe < maxsize / 2 ) { flag = true; }/**pivot*/\
    \
    \
    \
            for( uint8_t index = 0; index < 2; index ++ )\
            {\
    \
    \
    \
                i = 0;/*<---  (i = 1)*/\
    \
                probe = h;/*<---*/\
    \
    \
    \
                while(                 ref                     !=    0\
                      /*((type##Vector*)self)->array[probe]    !=    0*/\
                    &&                       comp \
                      /*((type##Vector*)self)->array[probe]    !=    info*/\
                     )\
                {\
    \
    \
    \
    \
    \
                    i++;/**quadratic counter*/\
    \
    \
    \
    \
    \
                    if( flag ){ probe = h + pow(i, 2) + 1 ; } /**(uint##bits##_t)*/  \
    \
                    else      { probe = h - pow(i, 2) - 1 ; }/*pow(i, 2)  - 1 */\
    \
    \
    \
    \
    \
                    /*i++;*/\
    \
    /*    \
                if ( flag ) { printf("\n+probe: %u\nq: %u\n", probe, pow(i, 2) + 1 ); }\
    \
                else { printf("\n-probe: %u\nq: %u\n", probe, pow(i, 2) - 1 ); }\
    \
     */\
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */\
                    /**                   CheckForOutOfBounds                    */\
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */\
                    if( typemax(size_type) - maxsize > typemax(size_type) / 2 )\
                    { if( probe > typemax(size_type) - maxsize || probe > maxsize - 1 ) \
                      { break; }\
                    } else \
                    { if( probe > maxsize - 1 )\
                      { break; } }\
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */\
    \
    \
                } \
                if( probe < maxsize )/*( probe < max )*/\
                {\
                    return &((type##Vector*)self)->array[ probe ]; \
                }\
                else if( index == 0 )\
                {\
    \
                    /**if( i > 1 ){ --i; }  (or 2)*/\
    \
                    if( flag )\
                    { flag = false; \
    \
    \
                      h = h + pow(i - 1, 2) + 1;\
                        /*h = h + (uint##bits##_t) pow(i - 1, 2);*/\
    \
    \
                      if( h + 1 < maxsize )\
                      { h += 1; } else { h -= 1; }/**offset*/\
    \
    \
                    } else \
                    { flag = true; \
    \
    \
                      h = h - pow(i - 1, 2) - 1;\
                        /*h = h - (uint##bits##_t) pow(i - 1, 2);*/\
    \
    \
                      if( h - 1 < maxsize )\
                      { h -= 1; } else { h += 1; }/**offset*/\
    \
    \
                    } \
                    if( h > maxsize - 1 ){ break; }\
                } \
    \
            } \
            if( probe > maxsize - 1 )\
            {\
                return nullptr;\
            }\
    \
        }
    /**
                good thing:  (this one is the bad version still) so no

                    if( typemax(type) - max > typemax(type) / 2 )
                    { if( index > typemax(type) - max || index > max - 1 ) <----
                      {  }
                    } else
                    { if( index > max - 1 )
                      {  } }
    */


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 * THIS SOFTWARE IS NOT COPYRIGHTED    <Christopher Bond>                  *
 *                                                                         *
 * This source code is offered for use in the static domain.  You may use, *
 * modify or distribute it freely.                                         *
 *                                                                         *
 * This code is distributed in the hope that it will be useful, but        *
 * WITHOUT ANY WARRANTY.  ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY    *
 * DISCLAIMED.  This includes but is not limited to warranties of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                    *
 *                                                                         *
 * <jb.bee250@gmail.com>                                                   *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
 ///needs to be validated
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *  <OOC library that defines Object-Oriented essentials in C (C+)>  *
 *                                                                   *
 * Copyright (C) <2017 - 2021>  <Christopher Bond>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Email: <jb.bee250@gmail.com>                                      *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


    /*   *                                                   *
         * REMEBER THE NodeRow(type) WILL BE EXACTLY THE SAME*
         *                                                   *
         * AS THE VECTOR, NOT THAT THATS NECCESSARY WITH THE *
         *                                                   *
         * METHODS TABLE HAVING POSITION INDEXES, BUT BECAUSE*
         *                                                   *
     */ /*  v = victory in OOC (Factory C) (02/19/2022)      */


    /* CONSIDER THIS FILE BEING A .c FILE SINCE IT HAS IMPL ONLY *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    \
        /** ClassList here **/\
        static class(FactoryTable)\
    \
            Pizza( City, Type, Method ) = \
    \
        { & Pizza( City, Type, Search ) };\
    \

/**

        I AM GOING TO PUT THE CODE INTO THE PROGRAM SO THATS JUST ONE LESS TIME

        YOU NEED TO TYPENAME A TYPE OF PIZZA.  (OR NOT)


        IF THIS IMPLEMENTED VERSION OF THE ABOVE MACRO SERVED ANY PURPOSE,

        IT WOULD SERVE THE PURPOSE OF BEING THE DEBUG VERSION OF THE CLASS

        ABOVE. I SAY THAT BECAUSE THE DEBUGGER WILL ONLY POINT AT THE TYPENAME

        OTHERWISE. (WITHOUT THIS DEBUG VERSION) (IMPLEMENTATION)

*/      #define doubledoublePizza(Member)  doubledoublePizza##Member
        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        #define Phily(Member)     Phily##Member /// /// /// /// /// /// /// ///
        typedef struct /// /// /// /// /// /// /// /// /// /// /// /// ///
        {   struct class base;  /**OPTIONAL BASE LABEL*/ /// /// /// /// ///
        }Phily; /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        typedef struct  /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        {   struct class(VirtualTable)base;/**INTERFACE TYPE BASE NOT OPTIONAL*/
        }Phily(VirtualTable); /// /// /// /// ///
        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

        /// /// ///   MAKE IT A DOUBLE DOUBLE PIZZA PLEASE MISTER   /// /// ///

        /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

        typedef struct Pizza( double, double, )
        {   Pizza base;

            double the;

            double jam;

        }Pizza( double, double, );


        typedef struct Pizza( double, double, VirtualTable )
        {   Pizza(,,VirtualTable)base;



        }Pizza( double, double, VirtualTable );


        static Pizza( double, double, ) * Pizza( double, double, Init )

            ( Pizza( double, double, ) * self, ... );


        static void Pizza( double, double, Dtor )( Pizza( double, double, ) * ) ;

        static cstring Pizza( double, double, Type )();

        static ctorPtr Pizza( double, double, Fact )();


        explicit Pizza( double, double, ) * Pizza( double, double, Init )

            ( Pizza( double, double, ) * self, ... )

            { if(!self){return 0;}



                return self; }

        explicit void Pizza( double, double, Dtor )

            ( Pizza( double, double, ) * self )    {}

        explicit cstring Pizza( double, double, What )()
        { return "doubledoublePizza"; }


        static void Pizza( double, double, Prepare )( Pizza * )   ;

        static void Pizza( double, double, Bake )( Pizza * )    ;

        static void Pizza( double, double, Cut )( Pizza * )   ;

        static void Pizza( double, double, Box )( Pizza * )   ;


        static Reg Pizza( double, double, Search ) ( cstring );


        static Pizza( double, double, VirtualTable )

            Pizza( double, double, Interface ) =
        {
            {
                {
                    &Pizza( double, double, What ),

                    &Pizza( double, double, Init ),

                    &Pizza( double, double, Dtor )

                } ,

                    &Pizza( double, double, Prepare ),

                    &Pizza( double, double, Bake ),

                    &Pizza( double, double, Cut ),

                    &Pizza( double, double, Box )
            }
        }  ;
        explicit ctorPtr Pizza( double, double, Fact )()
        { return new(doubledoublePizza); }


        static struct class (FactoryTable)

            Pizza( double, double, Factory ) =

        { &classFactoryTableWhat, &Pizza( double, double, Fact ), 0 };


        static Reg Pizza( double, double, Regs )[one] =
        {
          &Pizza( double, double, Factory ),

          nullptr  };


        explicit Reg Pizza( double, double, Search ) ( cstring reg )
        {
            Reg iterator[3] = { &Volatile(What), 0, 0 };

            size_t i;   volatilewhat = reg;

            RegList p = RegSearch( Pizza( double, double, Regs ), iterator, &i, 0, 0 );

            return ((*p)) ; /**PHAT FARM*/
        }


        static FactoryTable(Method)

            Pizza( double, double, List ) =

        { &Pizza( double, double, Search ) };


        explicit void Pizza( double, double, Prepare )( Pizza * self )       {}

        explicit void Pizza( double, double, Bake )( Pizza * self )          {}

        explicit void Pizza( double, double, Cut )( Pizza * self )           {}

        explicit void Pizza( double, double, Box )( Pizza * self )           {}


        /// LOVE THAT CHICKEN FROM POPEYES!


V#if 1 //DEBUG
        typename(AbstractHashSet)(AdapterClassPair, 32, );/**...**/

        defineHashSetInitArray(AdapterClassPair, 32,   (*self).base.array[ count ].key = 0;
                                                       (*self).base.array[ count ].val = 0;
        );
        defineHashSetResize(AdapterClassPair, 32,      (*iter).key,

                                                       (*p).key,

                                                       (*p).key = (*iter).key;
                                                       (*p).val = (*iter).val;,/*pointer copy (assign)*/

                                                       (*p).key == (*iter).key
        );
      #if 1 //DEBUG
        explicit bool AdapterClassPairQuadraticProbe32Insert(

            AdapterClassPairHashSet32 * self, AdapterClassPair info )

        {if( PrintFlags[1] ) { printf("\n" "AdapterClassPair" "HashSet" "32" "Add\n"); }

            AdapterClassPair * p = AdapterClassPairQuadraticProbe32QProbe( self, info );

            top:

            while( p == nullptr && !found )
            {

                if( !(AdapterClassPairHashSet32Resize( self, findPrime32Bit(

                    ((AdapterClassPairVector*)self)->maxsize * multiplier ) ) ) )
                {
                    multiplier++; goto top;
                }
                multiplier = 2;


                p = AdapterClassPairQuadraticProbe32QProbe( self, info );

            }





            if( found || (*p).key == info.key )/* && found*/
            {
                return false;
            }
            else

            if( (*p).key == 0 )
            {

                (*p).key = info.key;
                (*p).val = info.val;

                ((AdapterClassPairVector*)self)->length++;

                return true;
            }

        }
      #else
        defineHashSetAdd(AdapterClassPair, 32,       (*p).key,

                                                       (*p).key = info.key;
                                                       (*p).val = info.val;,/*pointer copy (assign)*/

                                                       (*p).key == info.key
        );
      #endif // DEBUG
        defineHashSetRemove(AdapterClassPair, 32,    (*p).key,

                                                       (*p).key = 0;
                                                       (*p).val = 0;
        );
      #if 1
        explicit AdapterClassPair * AdapterClassPairQuadraticProbe32QProbe(

            AdapterClassPairHashSet32 * self, AdapterClassPair info )

        {if( PrintFlags[1] ) { puts("n" "AdapterClassPair" "HashSet" "32" "QProbe\n"); }

            AdapterClassPair           * slot = nullptr;

            const size_type           maxsize = self->base.maxsize;

            uint32_t                        i = 0,/*<---  (i = 1)*/

                                            h = (self->hash(info.key) % maxsize),

                                        probe = h;/*<---*/

            bool                        pivot = false,

                                        flag  = false;

                                        found = false;



            if( probe < ( maxsize / 2 ) ) { pivot = true; }/**pivot*/



            for( uint8_t index = 0; index < 2; index ++ )
            {





                i = 0;/*<---  (i = 1)*/

                probe = h;/*<---*/





                while ( true )
                {
        /**
                while(  (  self->base.array[probe].key         !=    0  )
                    *//*((type##Vector*)self)->array[probe]    !=    0*//**
                    &&  (  self->base.array[probe].key         !=    info.key  )
                    *//*((type##Vector*)self)->array[probe]    !=    info*//**
                     )
                {}
         */


    \
        explicit Interface Pizza( City, Type, Search ) ( cstring reg )\
        {\
            Interface iterator[3] = { &VolatileType, 0, 0 };/**SINGLE SLOT**/\
    \
            size_t i;                  volatiletype = reg;\
                                                           /*  TABLE LENGTH  */\
            InterfaceHeap p = Search(Interface)(\
    \
                Pizza( City, Type, InterfaceHeap ), iterator, &i, 0, 0 );\
    \
            return ((*p)) ; /**PHAT FARM**/ }\

            if( PrintFlags[4] ){ if ( pivot ){ printf("\nprobe+: %u", probe); ifOutOfBounds(
                                           maxsize, probe, printf(" (OutOfBounds)") );
                                           printf("\n"); }
                                    else { printf("\nprobe-: %u", probe); ifOutOfBounds(
                                           maxsize, probe, printf(" (OutOfBounds)") );
                                           printf("\n"); } }




                    /** TRYING TO ADD BUT ALREADY THERE (SHOULDN'T HAPPEN) */
                    if( ( self->base.array[probe].key == info.key ) && ( info.val != 0 ) )
                            {  found = true;  return nullptr;  }

                    /** COMING OUT (FOUND) */
                    if( ( self->base.array[probe].key == info.key ) )
                            {  found = true;  break;  }

                    /** GOING IN (STOP LOOKING) */
                    if( ( self->base.array[probe].key == 0 ) && ( info.val != 0 ) )
                            {  break;  }

                    /** COMING OUT (KEEP LOOKING) */
                    if( ( self->base.array[probe].key == 0 ) && ( info.val == 0 ) )
                            {  if(!slot){ slot = & self->base.array[probe]; }  }





                    i++;/**quadratic counter*/




                                         /**(uint32_t)*/
                    if( pivot ){ probe = h + (uint32_t) pow(i, 2) + 1; }/* + 1 */
                    else       { probe = h - (uint32_t) pow(i, 2) - 1; }/* - 1 */





                    /*i++;*/





                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
                    /**                   CheckForOutOfBounds                    */
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
                    if( ( typemax(size_type) - maxsize ) < ( typemax(size_type) / 2 ) )
                    { if( pivot )
                      { if( probe < ( typemax(size_type) / 2 ) ){ flag = true; break; } }
                      else
                      { if( probe > ( typemax(size_type) / 2 ) ){ flag = true; break; } }
                    }
                    else
                    { if( probe > maxsize - 1 )
                      { flag = true; break; } }
                    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */





                }/** IF OBJECT FOUND OR FOUND SLOT TO PUT NEW ONE */
                if( found || !flag )
                {


                    //prnt ;


                     /** IF OBJECT FOUND AND FOUND SLOT (AND IS ALREADY IN TABLE)
                         AND NULL INFO INTERFACE SO JUST SEARCHING */
                    if( found && slot )
                    {

                        (*slot) = self->base.array[probe]; \
                        self->base.array[probe].key = 0; \
                        self->base.array[probe].val = 0;\


                        /** RETURN SLOT WITH OBJECT */
                        return slot;

                    }

                    /** RETURN SLOT WITH OBJECT OR NO */
                    return & self->base.array[ probe ];

                }
                else if( index == 0 )
                {

                    if( pivot )
                    { pivot = false;


                      h = h + (uint32_t) pow(i - 1, 2) + 1;/** + 1*/
                        /*h = h + (uint##bits##_t) pow(i - 1, 2);*/


                      if( h + 1 < maxsize )
                      { h += 1; } else { h -= 1; }/**offset*/


                    } else
                    { pivot = true;


                      h = h - (uint32_t) pow(i - 1, 2) - 1;/** - 1*/
                        /*h = h - (uint##bits##_t) pow(i - 1, 2);*/


                      if( h - 1 < maxsize )
                      { h -= 1; } else { h += 1; }/**offset*/


                    }
                    flag = false;
                    ifOutOfBounds( maxsize, h, break );
                }

            }
            ifOutOfBounds( maxsize, probe,

                /*if( PrintFlags[4] ){ printf("nnull return\nfound: %s\n",

                    ( found ? "true" : "false" ) ); }*/
            /** LOOKED FOR AS LONG AS IT COULD GIVEN O( n / 2 q ) */
            return nullptr; ); return nullptr;
        }
      #else
        defineHashSetQProbe(AdapterClassPair, 32,    info.key,

                                                       self->base.array[probe].key == 0,

                                                       self->base.array[probe].key == info.key,

                                                       info.val != 0,

                                                       info.val == 0,

                                                       (*slot) = self->base.array[probe];
                                                       self->base.array[probe].key = 0;
                                                       self->base.array[probe].val = 0;,

                                                       /**defineHashSetQProbePrint*/;

        );
      #endif // DEBUG
  #else


    /**

    enum _c { _48 = 49 };
    static void (*c[_48])(void)  =
    {
        & c01,& c02,& c03,& c04,& c05,& c06,& c07,& c08,
        & c09,& c10,& c11,& c12,& c13,& c14,& c15,& c16,
        & c17,& c18,& c19,& c20,& c21,& c22,& c23,& c24,
        & c25,& c26,& c27,& c28,& c29,& c30,& c31,& c32,
        & c33,& c34,& c35,& c36,& c37,& c38,& c39,& c40,
        & c41,& c42,& c43,& c44,& c45,& c46,& c47,& c48, nullptr
    };

    */
    /**

    static volatile StackTop * volatile * volatile  MiniControl = nullptr ;

            ///new(Assertion)(this, assert( i == 0 ));

            ///((ReturnStack*)Controller)[1]

            ///printf("container: 0x%x\n",  ((ReturnStack*)(*SetArray))[1]  );



            printf( "2:%.2f\n", ** (double**) virtual

                   ((*SetArray)[0].val, Container)

                    -> at( this ) );


                virtual ((*SetArray)[0].val, Container) -> remove( this );


            printf( "3:%.2f\n", ** (double**) virtual

                   ((*SetArray)[0].val, Container)

                    -> at( this ) );


                virtual ((*SetArray)[0].val, Container) -> remove( this );

        bool          ControlWhileCheck(X) ( Boolean Condition )\
        {   if( !Condition )\
            { jumpControlFlag(X) = true; }
            else{ jumpControlFlag(X) = set( envControlBuffer(X) ) }\
              return Condition; }\
    \

        Type          ControlWhileBlock(X)  ( Function Pointer )\
        {   if( !jumpControlFlag(X) )\
            { return Pointer( (*X) );\
            } else if (  ) { jump( envControlBuffer(X), true ); } }\

        int i = 0;

        using template(Set, Case)(& i)(i < 5)(...)(i++);

        continue(Label)(...)(...)(...)(...)(...)(...)(...);

        flag(1);

        using template(On, Start);

        continue(+)(1)(3)(5)(2)(7)(6)(4);

        using template(Off, Start);

        continue(-)(2)(7)(6)(4);


    volatile static uint8_t  __format_arg_redirect = 0;//  Control

    volatile static uint8_t  __format_arg_flag = 0;//      CommandFlag

        int i = 0;

        using template(Control, Start)(& i)(i < 5)(...)(i++);



        bool SetCommandSlot( Command init )

        { if ( ((StackControl**)Controller)[0] )\
          {    *((Command*)Controller) = init;\
               Controller++;\

               return true;
          }
          else
          { return false; }  }


                  /**Control /\
                if ( BooleanFlag )\
                {\
                    ((Function*)Controller)[0]((p));\
    \
                    return ControlFactory##Next;\
                }\



            if( Terminate )
            { return ((Fact*)CommandIter)[0]; }
            else
            {  }


            virtual( new(Class)(this), Class )-> X

                    (bad if memory error)





            /*\*(JumpBuffers[i].val) = setJump( JumpBuffers[i].key );/\
            \
        printf("flag: %d\n", *(JumpBuffers[i].val) );        \


            \
    printf("flag: %d\n", *(JumpBuffers[i].val) );        \


        void factory01 (void) {}

        void (*factory02(int a)) (void) {}

        void (*(*factory03(double a)) (int)) (void) {}

        void (*(*(*factory04(float a))(double))(int))(void) {}
    */

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*

    i have finally decided on what i want and that's for the
    vtable to be implemented only as a table to keep a whatPtr
    within it's datastructure for each object as the dtorPtr
    remains with the struct class object and Object is
    unimplemented, only defined to be pointer or void so Object *
    is a void * like SizeType as SizeType can either return the
    size or a pointer to the size variable (2021 - 03 - 07)

    i realized also that the majority of the interface should be
    static not strategic (dynamic) so struct classes are separated
    into two structures with a singleton object for the interface
    that is assigned to an object by the vtable when new(Class)
    is used. so thats the last major change since removing the
    macros allowing a choice between two implementations since
    that is more complicated than it needs to be. (value
    simplicity)  (2021 - 09 - 10) (sept 10th)

    ///typedef struct class (VirtualTable)* (*virtPtr(void))(void);

                     printf("\nlength: %d", ((Vector(pObserver)*)weatherStation->observers)->length );
        printf("\nmaxsize: %d", ((Vector(pObserver)*)weatherStation->observers)->maxsize );
                                                    */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                         **/
    /*
       this (WAS) the place to put the programs primary interface
       considering Iterator and Container as pure interfaces
       return Object (BUT ISN'T).

       note: a void* is a pointer that accepts a cast to any
             pointer type... as memory returned through a void*
             is returned as raw memory (no data type)





     *   ...the What function is implemented using the           *
     *   stringize or (stringify? no) operator # on type as in   *
     *   return #type "Vector"; now so forget implementing it    *
     *                                                           *
        */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*
    if( PrintFlags[3] ) { printf("cstring: A: %u, B: %u\n", a, b);
      printf("cstring: B: %s, A: %s\n", b, a); }
     */
    /*
        static void string(fill)(char *, const char *);

        explicit void string(fill)(char * a, const char * b)
        { if( a == 0 || b == 0 ){ return; }

            while(*b)
            {
                *a = *b;

                a++;

                b++;
            }
            *a = '\0';
        }

        static     =   static

        explicit   =   inline static
     */
    /**

    IT SEEMS THAT WHEN I ADD static ALSO TO THE INLINE DECLARATION

    FOR BOTH PROTOTYPE AND FUNCTION THAT THE COMPILER GOES TO THE

    NEXT FUNCTION, THEREFORE IM NOT DONE BY JUST ADDING INLINE BUT

    I HAVE TO ALSO LABEL EVERYTHING AS static ALSO: (02/19/2022)

    SO I HAVE BEEN WORKING MY WAY THERE (BEING ABLE TO COMPILE

    MULTIPLE .c FILES), BUT IM NOT THERE YET.

     */
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *




        instead of recursion try:


        top:

        if( *a == '\0' )
        {
            return;
        }
        if( *b == '\0' )
        {   *a = '\0';
            return;
        }
        *a = *b;
        ++a; ++b;

        goto top;



        size_t i = 0;

        top:

        if( *a == '\0' )
        {
            return i;
        }
        ++i; ++a;

        goto top;



        top:

        if( *a == '\0' && *b == '\0' )
        {   *flag = true;
            return;
        }
        if( *a != *b )
        {   *flag = false;
            return;
        }
        ++a; ++b;

        goto top;



        top:

        if( *a == '\0' || *b == '\0' )
        {   *flag = false;
            return;
        }
        if( *a < *b )
        {   *flag = false;
            return;
        }
        if( *a > *b )
        {   *flag = true;
            return;
        }
        ++a; ++b;

        goto top;


    \
    \
        if( *pJumpVal != 0 ){ jumpFlag = true; }

     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#if 0/**NOT USED IN FAVOR OF: Stack * stack = control() (and) arg(stack, type) (Factory C)*/
#define  vaList                  va_list             //variable arguments list


#define  vaStart(self, arg)      va_start(self, arg) //initializer


#define  vaArg(self, type)       va_arg(self, type)  //return function


#define  vaEnd(self)             va_end(self)        //
#endif // 0

/**
    // /// /// /// /// /// /// /// /// /// /// /// /// /// /// //\
    /**                                                          *
     * @brief  functions table registration                      *
     *                                                           *
     *                                                           *
     * @param  cstring key                                       *
     *                                                           *
     *                                                           *
     * @return Object *                                          *
     *                                                           /\
    // /// /// /// /// /// /// /// /// /// /// /// /// /// /// //\
    \
        static Object * type##SearchFunctions( cstring );\
    \
        static Strategy \
    \
            type##FunctionsTable[nine] =\
        {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z/\
          { #type "Assign",         &type##Assgin        },\
          { #type "Divides",        &type##Divides       },\
          { #type "Max",            &type##Max           },\
          { #type "Min",            &type##Min           },\
          { #type "Minus",          &type##Minus         },\
          { #type "Modulus",        &type##Modulus       },\
          { #type "Multiplies",     &type##Multiplies    },\
          { #type "Plus",           &type##Plus          },\
          { #type "Swap",           &type##Swap          },\
    \
          { "", 0 }\
        };\
    \
    \
        explicit Object * type##SearchFunctions( cstring key )\
        {\
            Strategy pair = { key, 0 },\
                   * p;\
            size_t   i;\
    \
            p = StrategySearch( type##FunctionsTable,\
                                pair, &i, 0, 8 );\
    \
            if( p ){ return p->val; } else { return 0; }\
        }\
    \
    \
        static struct class (StrategyTable)\
    \
            type##Functions = \
    \
        {\
            &classFunctionsTableWhat,\
    \
            &type##SearchFunctions,\
    \
             type##FunctionsTable \
        };\
    \
 */

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief    this one must be done for there to be a         *
     *           class builder that uses a pick and pull from    *
     *           this class **most optional**                    *
     *                                                           *
     *                                                           *
     * @param    cstring key                                     *
     *                                                           *
     *                                                           *
     *                                                           *
     * @return   string key for class builder func type          *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Builder

        StringBuilderTable[seven] =

    {

{ "String * substr(Vector(char) *, size_type, size_type);", "Fact" },
{ "String * init(String *, ... );",                         "Fact" },
{ "bool concat(Vector(char) *,const Vector(char) *);",      "Bool" },
{ "bool resize(Vector(char) *, size_type)",                 "Bool" },
{ "char * toString(Vector(char) *);",                       "Fact" },
{ "cstring what(void);",                                    "What" },
{ "void dtor(String *);",                                   "Fact" },

      { "", "" }
    };


    explicit Object * String(SearchBuilder)( cstring key )
    {
        Builder pair = { key, 0 }, /*SINGLE SLOT*/
               * p;
        size_t   i;
                                          /*TABLE LENGTH STORED HERE*/
        p = BuilderSearch( StringBuilderTable, pair, &i, 0, 6 );

        if( p ){ return p->val; } else { return 0; }
    }


    static struct class(BuilderTable)

        String(Builder) =

    {   &classBuilderTableWhat,

        &String(SearchBuilder),

         StringBuilderTable   };


    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
    /**                                                          *
     * @brief  builder table registration                        *
     *                                                           *
     *                                                           *
     * @param  cstring key                                       *
     *                                                           *
     *                                                           *
     * @return Object *                                          *
     *                                                           */
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*//*
    \
        static Object * type##SearchBuilder( cstring );\
    \
        static Builder\
    \
            type##BuilderTable[seventeen] = \
    \
        {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z/\
    \
        { "bool assign( Object *, ... );",             "CFac" },\
        { "bool swap( Object *, ... );",               "CFac" },\
        { "SizeType min( const Object * );",           "CFac" },\
        { "Object * plus( Object *, ... );",           "CFac" },\
        { "Object * minus( Object *, ... );",          "Fact" },\
        { "Object * multiplies( Object *, ... );",     "Fact" },\
        { "Object * divides( Object *, ... );",        "Fact" },\
        { "Object * modulus( Object *, ... );",        "Fact" },\
    \
          { "", "" }\
        };\
    \
    \
        explicit Object * type##SearchBuilder( cstring key )\
        {\
            Builder pair = { key, 0 }, /*SINGLE SLOT/\
                   * p;\
            size_t   i;\
                                              /*TABLE LENGTH STORED HER
            p = BuilderSearch( type##BuilderTable, pair, &i, 0, 16 );\
    \
            if( p ){ return p->val; } else { return 0; }\
        }\
    \
    \
        static struct class(BuilderTable)\
    \
            type##Builder = \
    \
        {\
            &classBuilderTableWhat,\
    \
            &type##SearchBuilder,\
    \
             type##BuilderTable \
        };\
    \



    /** * * * * * * * * *factory registration * * * * * * * * * **/\
    /*                                       *//**new(type) X *//*
                ctorPtr type##Fact(void) { return new(type); }\
    \
    \
                static struct class (FactoryTable)\
    \
                    type##Factory = \
    \
                { & classFactoryTableWhat, & type##Fact, 0 };

    /*
                static Reg type##Regs[one] = \
    \
                { & type##Factory, nullptr };


            &type##Builder,\
    \
    \
            &type##Functions,\
    */


    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
        /**                                                  *
         * @brief  min                                       *
         *                                                   *
         * @param  self                                      *
         *                                                   *
         * @throw  throw(new(Exception))(this,"no function") *
         *                                                   *
         * @return SizeType                                  *
         *                                                   */
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

        explicit SizeType   min( const Object * self )
        {
            return ((SizeType(*)(const Object *))

                (*function( self, "min" )))(this);
        }

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
        /**                                                  *
         * @brief  plus                                      *
         *                                                   *
         * @param  self                                      *
         *                                                   *
         * @throw  throw(new(Exception))(this,"no function") *
         *                                                   *
         * @return Object *                                  *
         *                                                   */
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

        explicit Object *   plus( Object * self, ... )
        {
            if( !(*Flags[0]) ){flags(0);ControlSlot[0][0]=&self;}

            Object * objt = ((Object *(*)(Object *,...))

                (*function( self, "plus" )))(this);

            flags(0);

            return objt;
        }

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
        /**                                                  *
         * @brief  minus                                     *
         *                                                   *
         * @param  self                                      *
         *                                                   *
         * @throw  throw(new(Exception))(this,"no function") *
         *                                                   *
         * @return Object *                                  *
         *                                                   */
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

        explicit Object *   minus( Object * self, ... )
        {
            if( !(*Flags[0]) ){s(0);ControlSlot[0][0]=&self;}

            Object * objt = ((Object *(*)(Object *,...))

                (*function( self, "minus" )))(this);

            s(0);

            return objt;
        }

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
        /**                                                  *
         * @brief  multiplies                                *
         *                                                   *
         * @param  self                                      *
         *                                                   *
         * @throw  throw(new(Exception))(this,"no function") *
         *                                                   *
         * @return Object *                                  *
         *                                                   */
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

        explicit Object *   multiplies( Object * self, ... )
        {
            if( !(*s[0]) ){s(0);ControlSlot[0][0]=&self;}

            Object * objt = ((Object *(*)(Object *,...))

                (*function( self, "multiplies" )))(this);

            s(0);

            return objt;
        }

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
        /**                                                  *
         * @brief  divides                                   *
         *                                                   *
         * @param  self                                      *
         *                                                   *
         * @throw  throw(new(Exception))(this,"no function") *
         *                                                   *
         * @return Object *                                  *
         *                                                   */
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

        explicit Object *   divides( Object * self, ... )
        {
            if( !(*s[0]) ){s(0);ControlSlot[0][0]=&self;}

            Object * objt = ((Object *(*)(Object *,...))

                (*function( self, "divides" )))(this);

            s(0);

            return objt;
        }

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
        /**                                                  *
         * @brief  modulus                                   *
         *                                                   *
         * @param  self                                      *
         *                                                   *
         * @throw  throw(new(Exception))(this,"no function") *
         *                                                   *
         * @return Object *                                  *
         *                                                   */
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

        explicit Object *   modulus( Object * self, ... )
        {
            if( !(*s[0]) ){s(0);ControlSlot[0][0]=&self;}

            Object * objt = ((Object *(*)(Object *,...))

                (*function( self, "modulus" )))(this);

            s(0);

            return objt;
        }

    #define ClassNameConstructPairIterator(Member)\
    \
        ClassNameConstructPairIterator##Member

    #define ClassNameConstructPairVector(Member)\
    \
        ClassNameConstructPairVector##Member

    #define ClassNameConstructPairHashSet(Member)\
    \
        ClassNameConstructPairHashSet##Member

    #define ClassNameConstructPair(Member)\
    \
        ClassNameConstructPair##Member

    #define ClassNameConstructPairQuadraticProbe(Member)\
    \
        ClassNameConstructPairQuadraticProbe##Member


    #define ClassNameConstructPairVector(Member)\
    \
        ClassNameConstructPairVector##Member

    #define ClassNameConstructPair(Member)\
    \
        ClassNameConstructPair##Member

                /*
                 abs
                 div
                 acos
                 asin
                 atan
                 atan2
                 ceil
                 cos
                 cosh
                 exp
                 fabs
                 floor
                 fmod
                 frexp
                 ldexp
                 log
                 log10
                 modf
                 pow
                 sin
                 sinh
                 sqrt
                 tan
                 tanh
                 */
        #if 0
         default;
         break;
         return;
        #endif // 0

                 LessThanComparable;
                 remove_all_extents;
                 remove_const;
                 remove_copy;
                 remove_copy_if;
                 remove_cv;
                 remove_extent;
                 remove_if;
                 remove_pointer;
                 remove_reference;;
                 remove_volatile;
                 less_equal  ;


        binary_function;
        binary_negate;
        binary_search;
        bind;
        bind1st;
        bind2nd;
        binder1st;
        binder2nd;
        binomial_distribution;
                   ///max;pow;sqrt;

      #if 0
        #undef size_type
        typedef size_t size_type;
      #endif // 0

        typedef size_t nothrow_t;
        const nothrow_t nothrow = 0U;


            equal_to;
            not1;
            not2;



        is_array;
        is_class;
        is_empty;


            bad_alloc;
            bad_function_call;
            bad_weak_ptr;


            not_equal_to;

                           /** FactoryArray */

                            set_difference;
                            set_union;
                            set_intersection;

                                back_item;
                                minmax;
                                unique;
                                min_element;
                                max_element;

                                minmax_element;


                                max_fixed_size;
                                max_none;
                                max_unbounded;
                                max_variable_size;

                                for_each;
                                all_of;
                                any_of;
                                none_of;
                                find;
                                find_if;
                                find_if_not;
                                count;
                                count_if;
                                transform;
                                reverse;
                                rotate;
                                shuffle_order_engine;
    ///except;
                                nth_element;

                                merge;

                                includes;

                                iter_swap;

                                array;


        discard_block;
        discard_block_engine;
        discrete_distribution;


        minstd_rand;

        minstd_rand0;


       ///noexcept;

    uninitialized_fill_n;
    uninitialized_fill;

    uninitialized_copy_n;
    uninitialized_copy;
    uniform_real_distribution;
    uniform_int;
    uniform_int_distribution;

    unique_copy;
    unique_ptr;
                                difference_type;

                                ///max;




                                ///sin; cos; tan;
    //exception;
        ///multimap;

        ///multiplier;


        multiset;



        ///div_t;

        sub_match;exception;

        subtract_with_carry_engine;

        subtract_with_carry_01;

        subtract_with_carry;




        vector;
        list;
        deque;
        stack;
        ///map;

        ///set;    set()   jump()





        set_new_handler;
        set_symmetric_difference;


        bitset;




        setw;




        inplace_merge;

        ;
        input_iterator_tag;
        output_iterator_tag;

        out_of_range;



        istream;ostream;iostream;

        istreambuf_iterator;
        istream_iterator;
        ostreambuf_iterator;
        ostream_iterator;




        swap_ranges;


        random_access_iterator_tag;

        random_device;

        random_shuffle;

        range_error;

        rank;

        ranlux24;

        ranlux24_base;

        ranlux3;

        ranlux3_01;

        ranlux4;

        ranlux48;

        ranlux48_base;

        ranlux_base_01;

        ranlux4_01;

                                ranlux64_base_01;

                ///static_assert;

            ///static_cast;



         static_pointer_cast;


                                        pair(key, val);

                                        ///size;
        sort_heap;



        filebuf;

        search_n;


        unary_function;
        unary_negate;
        ///function;

        move_backward;
        move_iterator;

        ptr_fun;
        iterator_traits;
        back_insert_iterator;

             stable_sort;

             stable_partition;

        next_permutation;

          numeric_limits;   constexpr;

          const_iterator; conditional;

          extent;

          is_polymorphic;



                ///get_deleter;
        get_temporary_buffer;
        get_pointer_safety;


         ///  and


          ///and_eq


         /// bitand


          /// bitor


          ///  compl

    ///  not


          /// not_eq


         ///  or


         /// or_eq


       /// xor
     ///@headername
    ///@file
         ///xor_eq

         allocator;

         tr1;


                   exception; ///(in throw.h)
                   value_type;
                   ///type_info; (in Comparable.h)
                   size_type; ///(in SizeType.h)
                   valarray;


        ///reference;
          reference_wrapper;

          static_assert;

          static_cast;

          static_pointer_cast;

       /// std; ///std->cout->cout()->cout()
                 ///less;
                 ///more;

                 ///bit_and;
                 ///bit_or;
                 ///bit_xor;
 ///SizeType        max( const Object * );///(also used with Factory Container)








                ///max;
                ///min;

                ///less;
                ///plus;
                ///minus;
                ///multiplies;
                ///divides;
                ///modulus;



                ///bit_and;
                ///bit_or;
                ///bit_xor;

                    empty;

                    hash;   /// Strategic (in object)

                    sort;

                    find;

                 ///fill;

                    reverse;

                 ///assign;


    /**
        THIS FUNCTION AS YOU CAN TELL IT USES A SEQUENTIAL

        SEARCH. THIS WAS BEFORE THE FACTORY TABLE USED A

        CLASS FACTORY METHOD THAT ITSELF USES A BINARY SEARCH

        ON A MANUALLY SORTED STATIC TABLE.
     */

    #define FUNCTIONFACTORY
    #ifndef FUNCTIONFACTORY ///THIS WAS THE FIRST IMPL OF FACTORY
/*inactive*/
        Class ClassInit( Class, ... );

        ctorPtr factory( cstring name )

        { RegList p = FactoryTable(Interface) /// - istration
          .search(ftable, name);
          if( !p ){ return &ClassInit; }

            while( *p )
            { if( string(equal)( ((whatPtr*)(*p))[0](),
                "classFactoryTable" ) )

              { return ((newfPtr*)(*p))[1](); }

                ((p))++;  //PHAT FARM BABY

            } return &ClassInit; }

        Class ClassInit( Class self, ... ){ return 0; }

    #endif // FACTORYTABLESINGLETON
    /**
        typedef struct FactoryTable(FactoryTable)
        {   Object * (*search)( RegistrationName );
            RegistrationList list;//PUBLIC
        }FactoryTable(FactoryTable);


        struct class(FactoryTable) * (*function)

                ( volatile fTable * volatile, ClassName ... );

        void *** p = StringRegistrations;


        printf( "%s\n", ((whatPtr*)(*p))[0]() );


        String * str = ((newfPtr*)(*p))[1]()(this, 2, "Hello");


    typedef struct FactoryTable(FactoryTable)
    {   /// /// /// ///
        whatPtr what;//
        /// /// /// ///
        srchPtr sear;//
        /// /// /// ///
        reglPtr regl;//
        /// /// /// ///
    }FactoryTable(FactoryTable);

        ///    typedef FactoryTable(FactoryTable) methPtr;
    ///typedef Object * * * FactoryList;///ClassNameFactoryListPair


    typedef Object * * Fact;  ///(new)  also:  ClassFact

    typedef cstring FactoryName;



    DONT FORGET TO USE map AND multimap AS SINGLETON FUNCTIONS

    ALONG WITH A FUNCTION THAT RETRIEVES A DATAFIELD POSITION

    FROM AN INTERFACE BASED ON ITS METHOD NAME. MAYBE function

    WOULD WORK. (THAT WILL BE THE HELPER FOR ACTUAL FACTORY

    OBJECTS) function( typeid(objt), "method" ) X ->

    */

    #define FunctionHelper( self, objt )\
    \
        if( !(*s[1]) ){(1);ControlSlot[0][0]=&self;}\
    \
        Object * objt = ((ctorPtr)function( self, "init" ))(self);\
    \
        (1);

/**#include "fTable.h"  //and dont forget everything for the vtable
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/*                          Program Entry Point                      *
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
void FactoryTable(Begin)(void)
{    FactoryTable(NewTable)(&ftable, 101);

     register(Class);

     register(Class);

     register(Class);

}
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
int main(void)
{
    Class * o = factory("Class")(this, ...); //fully-dynamic



    return 0;
}
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
void FactoryTable(End)(void)        { FactoryTable(Destroy)(&vtable); }
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

            ctorPtr ClassFact() { return new(Class); }


            static struct class(FactoryTable)

                ClassFactory =

            { & classFactoryTableWhat, & ClassFact, 0 };


            static Object ** ClassRegistrations[one] =

            { &ClassFactory, nullptr };
            ctorPtr ClassFact() { return new(Class); }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

            static struct class(FactoryTable)

                ClassFactory =

            { & classFactoryTableWhat, & ClassFact, 0 };


            static Object ** ClassRegistrations[one] =

            { &ClassFactory, nullptr };


            ctorPtr ClassFact() { return new(Class); }

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

            static struct class(FactoryTable)

                ClassFactory =

            { & classFactoryTableWhat, & ClassFact, 0 };


            static Object ** ClassRegistrations[one] =

            { &ClassFactory, nullptr };

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                                                                 */


    typename(Search)
    (   char,

        array[*mid] == key,

        array[*mid] > key
    );

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief    function implementation table                   *
     *                                                           *
     *                                                           *
     * @param    class namespaced function name                  *
     *                                                           *
     *                                                           *
     * @return   function address                                *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Strategy     /**Pair(Name, Address)*/

        StringFunctionsTable[seven] =
    {
      {  "StringConcat",        &String(Concat)        },
      {  "StringDtor",          &String(Dtor)          },
      {  "StringInit",          &String(Init)          },
      {  "StringResize",        &String(Resize)        },
      {  "StringSubStr",        &String(SubStr)        },
      {  "StringTostring",      &String(ToString)      },
      {  "StringWhat",          &String(What)          },

      {  "",  0  }
    };


    explicit Object * String(SearchFunctions)( cstring key )
    {
        Strategy pair = { key, 0 }, /*SINGLE SLOT*/
               * p;
        size_t   i;
                                          /*TABLE LENGTH STORED HERE*/
        p = StrategySearch( StringFunctionsTable, pair, &i, 0, 6 );

        if( p ){ return p->val; } else { return 0; }
    }


    static struct class(StrategyTable)

        String(Functions) =

    {   &classFunctionsTableWhat,

        &String(SearchFunctions),

         StringFunctionsTable   };

             ///(*s[1]?ControlSlot[0][0]:&self);stack=((void**)stack)+1

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    volatile static unsigned char CFactFunc = 0;
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define _control(self)  ( CFactFunc ? ControlSlot[0][0][0] : self ) /// <---
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define _control_2(self)( CFactFunc ? ControlSlot[0][0][1] : self )
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #undef _control /// <---
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #undef _control_2
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #include "../Control/using.h"
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
      MINI; COMMAND; MINI; COMMAND; MINI; COMMAND; MINI; COMMAND;//
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
      MINI; FACTORY; MINI; FACTORY; MINI; FACTORY; MINI; FACTORY;//
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

static volatile StackControl * volatile * volatile MiniController = nullptr;
      #define                          MiniStart(top)\
      \
            ControlSlot[0][0] = top ; *s[0] = true;
      static volatile bool             Mini = false ;
      #define                          MiniFinish()\
      \
            *s[0] = false;         MiniController++;
   static Factory MiniDefault={0,0}, * AMiniDefault = & MiniDefault;
      #define                          mini\
      \
            (Object*)MiniInit
static volatile StackTop * volatile * volatile MiniControl=& AMiniDefault;

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    typedef void               MiniControl(03) ( StackTop *, ... );

    typedef MiniControl(03) *  MiniControl(02) ( StackTop *, ... );

    typedef MiniControl(02) *  MiniControl(01) ( StackTop *, ... );

    typedef MiniControl(01) *  MiniControl(00) ( StackTop *, ... );
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static void                MiniFactory(03) ( StackTop *, ... );

    static MiniControl(03) *   MiniFactory(02) ( StackTop *, ... );

    static MiniControl(02) *   MiniFactory(01) ( StackTop *, ... );

    static MiniControl(01) *   MiniFactory(00) ( StackTop *, ... );

    static MiniControl(00) *   MiniInit        ( StackTop * * );

    explicit MiniControl(00) * MiniInit ( StackTop * * p )
    { if(p == nullptr){return nullptr;}

        MiniController = ((p));

            ((p)) = true; /** PHAT FARM **/

        return & MiniFactory(00);
    }
    explicit void            MiniFactory(03)( StackTop * top, ... )
    {   MiniStart( & top );   ((Function*)MiniController)[0]((top));
        MiniFinish();               return;                       }

    explicit MiniControl(03)*MiniFactory(02)( StackTop * top, ... )
    {   MiniStart( & top );   ((Function*)MiniController)[0]((top));
        MiniFinish();               return & MiniFactory(03);     }

    explicit MiniControl(02)*MiniFactory(01)( StackTop * top, ... )
    {   MiniStart( & top );   ((Function*)MiniController)[0]((top));
        MiniFinish();               return & MiniFactory(02);     }

    explicit MiniControl(01)*MiniFactory(00)( StackTop * top, ... )
    {   MiniStart( & top );   ((Function*)MiniController)[0]((top));
        MiniFinish();               return & MiniFactory(01);     }

    enum          MiniEnum { Zero, One, Two, Three };

    static void * MiniArray[4] =

{&ControlStart(X), &ControlCheck(X), &ControlBlock(X), &ControlProbe(X)};

    typedef  void     ZeroMini                         ( Index * );

    typedef  bool     OneMini                          ( Boolean );

    typedef  Type     TwoMini              ( StackControl *, ... );

    typedef  void     ThreeMini                          ( Index );

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
      MINI; FACTORY; MINI; FACTORY; MINI; FACTORY; MINI; FACTORY;//
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
      MINI; COMMAND; MINI; COMMAND; MINI; COMMAND; MINI; COMMAND;//
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**
              mini template(Mini, Zero)       (...)(...)(...)(...);
              \
                 (((Case##Set**)Set##Array)[Case])  ... (...)

                (((Zero##Mini**)Mini##Array)[Zero])

                  (((ZeroMini**)MiniArray)[Zero])

              AND NO using template(...) FOR MINI COMMAND

              OR UNDEF using FOR MiniInit (FOR RE-DEFINE)

              MiniInit( p )(...)(...)(...)(...); (IF NOT)
     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
      MINI; COMMAND; MINI; COMMAND; MINI; COMMAND; MINI; COMMAND;//
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///



    typedef struct class    (CommandTable)                          /**NOT SURE**/
    {   /// /// /// ///
        whatPtr what;//
        /// /// /// ///
        objtPtr self;// = 0   ///
        /// /// /// ///
        execPtr exec;// = 0   ///
        /// /// /// ///
    }class      (CommandTable);
  explicit
    cstring classCommandTableWhat()
    { return "classCommandTable"; }





    typedef struct class    (InterfaceTable)    /**MIGHT NOT BE ROOM FOR THIS ONE*/
    {   /// /// /// ///    (override table in conjunction with...
        whatPtr what;///    stategy table as normal function table)
        /// /// /// ///
        methPtr meth;///   (this is also needed for a registration
        /// /// /// ///     "interface" list)
        tblePtr list;///
        /// /// /// ///
    }class    (InterfaceTable);
  explicit
    cstring classInterfaceTableWhat()
    { return "classInterfaceTable"; }




    typedef struct class    (FunctionsTable)
    {   /// /// /// ///  #2
        whatPtr what;//
        /// /// /// ///
        methPtr meth;// //singleton search for table
        /// /// /// ///
        tblePtr list;// //for sequential search
        /// /// /// ///
    }class      (FunctionsTable);
  explicit
    cstring classFunctionsTableWhat()  ///StrategyTable
    { return "classFunctionsTable"; }

s[7] = &Skip;         /// #8 (COUNTER TO DETERMINE AMOUNT OF SEQUENCE FACTORIES TO SKIP)

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define        int_least8_t(member)\
                            int_least8_t##member
    typename       (Object)             (int_least8_t) ;
    #define        uint_least8_t(member)\
                            uint_least8_t##member
    typename       (Object)             (uint_least8_t)  ;
    #define        int_least16_t(member)\
                            int_least16_t##member
    typename       (Object)             (int_least16_t);
    #define        uint_least16_t(member)\
                            uint_least16_t##member
    typename       (Object)             (uint_least16_t);
    #define        int_least32_t(member)\
                            int_least32_t##member
    typename       (Object)             (int_least32_t);
    #define        uint_least32_t(member)\
                            uint_least32_t##member
    typename       (Object)             (uint_least32_t);
    #define        int_least64_t(member)\
                            int_least64_t##member
    typename       (Object)             (int_least64_t);
    #define        uint_least64_t(member)\
                            uint_least64_t##member
    typename       (Object)             (uint_least64_t);
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define        int_fast8_t(member)\
                            int_fast8_t##member
    typename       (Object)             (int_fast8_t);
    #define        uint_fast8_t(member)\
                            uint_fast8_t##member
    typename       (Object)             (uint_fast8_t);
    #define        int_fast16_t(member)\
                            int_fast16_t##member
    typename       (Object)             (int_fast16_t);
    #define        uint_fast16_t(member)\
                            uint_fast16_t##member
    typename       (Object)             (uint_fast16_t);
    #define        int_fast32_t(member)\
                            int_fast32_t##member
    typename       (Object)             (int_fast32_t) ;
    #define        uint_fast32_t(member)\
                            uint_fast32_t##member
    typename       (Object)             (uint_fast32_t);
    #define        int_fast64_t(member)\
                            int_fast64_t##member
    typename       (Object)             (int_fast64_t) ;
    #define        uint_fast64_t(member)\
                            uint_fast64_t##member
    typename       (Object)             (uint_fast64_t);
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define        atomic_int_least8_t(member)\
                            atomic_int_least8_t##member
    typename       (Object)             (atomic_int_least8_t);
    #define        atomic_uint_least8_t(member)\
                            atomic_uint_least8_t##member
    typename       (Object)             (atomic_uint_least8_t);
    #define        atomic_int_least16_t(member)\
                            atomic_int_least16_t##member
    typename       (Object)             (atomic_int_least16_t);
    #define        atomic_uint_least16_t(member)\
                            atomic_uint_least16_t##member
    typename       (Object)             (atomic_uint_least16_t);
    #define        atomic_int_least32_t(member)\
                            atomic_int_least32_t##member
    typename       (Object)             (atomic_int_least32_t);
    #define        atomic_uint_least32_t(member)\
                            atomic_uint_least32_t##member
    typename       (Object)             (atomic_uint_least32_t);
    #define        atomic_int_least64_t(member)\
                            atomic_int_least64_t##member
    typename       (Object)             (atomic_int_least64_t);
    #define        atomic_uint_least64_t(member)\
                            atomic_uint_least64_t##member
    typename       (Object)             (atomic_uint_least64_t);
    #define        atomic_int_fast8_t(member)\
                            atomic_int_fast8_t##member
    typename       (Object)             (atomic_int_fast8_t);
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define        atomic_uint_fast8_t(member)\
                            atomic_uint_fast8_t##member
    typename       (Object)             (atomic_uint_fast8_t);
    #define        atomic_int_fast16_t(member)\
                            atomic_int_fast16_t##member
    typename       (Object)             (atomic_int_fast16_t);
    #define        atomic_uint_fast16_t(member)\
                            atomic_uint_fast16_t##member
    typename       (Object)             (atomic_uint_fast16_t);
    #define        atomic_int_fast32_t(member)\
                            atomic_int_fast32_t##member
    typename       (Object)             (atomic_int_fast32_t);
    #define        atomic_uint_fast32_t(member)\
                            atomic_uint_fast32_t##member
    typename       (Object)             (atomic_uint_fast32_t) ;
    #define        atomic_int_fast64_t(member)\
                            atomic_int_fast64_t##member
    typename       (Object)             (atomic_int_fast64_t);
    #define        atomic_uint_fast64_t(member)\
                            atomic_uint_fast64_t##member
    typename       (Object)             (atomic_uint_fast64_t);



    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief    function implementation table                   *
     *                                                           *
     *                                                           *
     * @param    class namespaced function name                  *
     *                                                           *
     *                                                           *
     * @return   function address                                *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    static Strategy     /**Pair(Name, Address)*/

        BirdAdapterFunctionsTable[seven] =
    {
      {  "",            },
      {  "",               },
      {  "",              },
      {  "",          },
      {  "",           },
      {  "",        },
      {  "",             },

      {  "",  0  }
    };


    explicit Object * BirdAdapter(SearchFunctions)( cstring key )
    {
        Strategy pair = { key, 0 }, /*SINGLE SLOT*/
               * p;
        size_t   i;
                                          /*TABLE LENGTH STORED HERE*/
        p = StrategySearch( BirdAdapterFunctionsTable, pair, &i, 0, 6 );

        if( p ){ return p->val; } else { return 0; }
    }


    static struct class(StrategyTable)

        BirdAdapter(Functions) =

    {   &classFunctionsTableWhat,

        &BirdAdapter(SearchFunctions),

         BirdAdapterFunctionsTable   };



        int_least8_t *          x            = new (int_least8_t)   (this, 24);

        uint_least8_t *         y            = new (uint_least8_t)  (this, 25);

        int_least16_t *         z            = new (int_least16_t)  (this, 26);

        uint_least16_t *        aa           = new (uint_least16_t) (this, 27);

        int_least32_t *         ab           = new (int_least32_t)  (this, 28);

        uint_least32_t *        ac           = new (uint_least32_t) (this, 29);

        int_least64_t *         ad           = new (int_least64_t)  (this, 30);

        uint_least64_t *        ae           = new (uint_least64_t) (this, 31);

        int_fast8_t *           af           = new (int_fast8_t)    (this, 32);

        uint_fast8_t *          ag           = new (uint_fast8_t)   (this, 33);

        int_fast16_t *          ah           = new (int_fast16_t)   (this, 34);

        uint_fast16_t *         ai           = new (uint_fast16_t)  (this, 35);

        int_fast32_t *          aj           = new (int_fast32_t)   (this, 36);

        uint_fast32_t *         ak           = new (uint_fast32_t)  (this, 37);

        int_fast64_t *          al           = new (int_fast64_t)   (this, 38);

        uint_fast64_t *         am           = new (uint_fast64_t)  (this, 39);


/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *  <OOC library that defines Object-Oriented essentials in C (C+)>  *
 *                                                                   *
 * Copyright (C) <2017 - 2022>  <Christopher Bond>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 *                                                                   *
 * The author may be reached at: <jb.bee250@gmail.com>               *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */

     *"DONT FORGET THERE NEEDS TO BE A ClassFactoryInterface THAT*
     *                                                           *
     *GETS DECLARED AND HAS POINTERS TO THE FACTORY OBJECT VERSIONS
     *                                                           *
     *OF THE INTERFACE METHODS. ON SECOND THOUGHT THERE MAY NOT  *
     *                                                           *
     *BE ROOM FOR ONE BUT IS POSSIBLY HELPFUL, TO HAVE ALL THE   *
     *
     *FUNCTIONS PROVIDED BY INTERFACE ONCE MORE SEEMS TO BE THE
     *
     *END OF THAT STORY. IT ALSO SEEMS THAT THEY DONT NEED TO BE
     *
     *AND THAT EVEN JUST CALLING A GLOBAL FUNCTION (WITH A METHOD
     *
     *NAME) IS DYNAMIC ENOUGH FOR ONCE." - author

        atomic_int_least8_t *   dd       = new (atomic_int_least8_t)(this, 47);

        atomic_uint_least8_t *  de      = new (atomic_uint_least8_t)(this, 48);

        atomic_int_least16_t *  df      = new (atomic_int_least16_t)(this, 49);

        atomic_uint_least16_t * dh     = new (atomic_uint_least16_t)(this, 50);

        atomic_int_least32_t *  di     = new (atomic_int_least32_t) (this, 51);

        atomic_uint_least32_t * dj     = new (atomic_uint_least32_t)(this, 52);

        atomic_int_least64_t *  dk     = new (atomic_int_least64_t) (this, 53);

        atomic_uint_least64_t * dl     = new (atomic_uint_least64_t)(this, 54);

        atomic_int_fast8_t *    dm     = new (atomic_int_fast8_t)   (this, 55);

        atomic_uint_fast8_t *   dn     = new (atomic_uint_fast8_t)  (this, 56);

        atomic_int_fast16_t *   dp     = new (atomic_int_fast16_t)  (this, 57);

        atomic_uint_fast16_t *  dq     = new (atomic_uint_fast16_t) (this, 58);

        atomic_int_fast32_t *   dr     = new (atomic_int_fast32_t)  (this, 59);

        atomic_uint_fast32_t *  ds     = new (atomic_uint_fast32_t) (this, 60);

        atomic_int_fast64_t *   dt     = new (atomic_int_fast64_t)  (this, 61);

        atomic_uint_fast64_t *  du     = new (atomic_uint_fast64_t) (this, 62);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*              ... to be continued (advanced)               */

    /// ...                                   Strategy?

    /*
    static Pair(FunctionName, Address) String(Commands)[] =
    { { "StringWhat", &StringWhat },
      { "StringInit", &StringInit },
      { "StringDtor", &StringDtor },
      {}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
    }
     */
    /**
        THERE IS NAMESPACE THATS CLEAR FOR String(FactoryTable)

        THAT SHOULD BE WHERE THE INTERFACE IS RE-DECLARED ENTIRELY

        INSIDE OF A STRUCT THAT EXTENDS class(FactoryTable) NOT

        class(VirtualTable) OR EVEN class(AdapterTable) NOT

        THE FIRST TWO. THE String(FactoryTable) WOULD THEN BE

        EXTENDED FROM charVector(FactoryTable)
     */


    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
        /*                 factory primitive                 */
                    /** FactoryObject(Primitive) */
        #define             ref(object)       (*object)


        if ( !p->val )
            { if( Exception ){ throw( new(Exception) )
                   (this, "virtual( null interface )" ); }
              else{ return 0; } }
        else

/**Stack * stack = control(); (TOO CRITICAL TO CALL CONTROL C)

      ClassStk * the = arg(stack, volatile Object * volatile);

      Class * object = arg(stack, Class);**/

/**Stack * stack = control();

      Class * object = arg(stack, Class);*/

/**Stack *  stack = control();

      ClassStk * the = arg(stack, volatile Object * volatile);

      Class * object = arg(stack, Class);*/

/**...**/

 /**arg(stack, funcPtr)**/

/**arg(stack, ctorPtr);**/

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**
        THE Exception IS A  THAT CAN BE RAISED OR LOWERED

        FOR THERE TO EITHER BE AN EXCEPTION THROW OR A RETURN 0

        FROM virtual(object, Class) -> meth(this, ...);
     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*    possibilities: (and uses with separate components)

        - - constructor for class type (destructor only) - -

                - - put destructor in proper array - -

       - - put destructor in array of any one type at a time - -
                    (objects without structures)

     - - what() function that returns the ClassName as a string - -
       - - as a way to tell what each object is from the vtable - -

             - - singleton iterator for the singleton - -
                 - - vtable can be declared infile - -

        - - write a search function that re-initializes this* - -

             - -       vPush(object) vPop() vTop()    - -

              - - use a vStk(Class) in the function underlying
              new(Class) to then be able to: self = vPop();
              inside the ctor for when something like a Decorator
              passes new(Class) into new(Class):

              new(Class)(this, new(Class)(this, new(Class)(this)));

              new(Class)(this, new(Class)(this), new(Class)(this));


        new(Class)(vPop(), new(Class)(vPop(), new(Class)(vPop())));

        new(Class)(vPop(), new(Class)(vPop()), new(Class)(vPop()));

    - - static struct class *  this  = 0; //main self pointer - -

    - - destroy should be redefined as a function so therefore
        destroy can be a named data member to an interface
        somewhere else - -


    - - if the Virtual table was extensible, its file would need
        to be extended for every alternate struct class () interface
        it would be used for.

        ClassVirtualTable * VirtualTable(Factory) (...);

        ClassVirtualTable * VirtualTable(Compare) (...);

        ClassVirtualTable * VirtualTable() (...);

        - -
        bool       vRev(); //<--- not implemented as singleton func


    - - a multiple inheritance object might might need to use

        VirtualTable(Interface).insert( ... )

    - - use the vtable pointer as an iterator pointer
        (that never has an instance to itself then) if you want
        a vTable configuration that involves multiple vtables


    defineAbstractHashSet(ClassClassVirtualTablePair, 32, );

    ClassClassVirtualTablePair *

    ClassClassVirtualTablePairQuadraticProbe32QProbe(

        ClassClassVirtualTablePairHashSet32 *,

        ClassClassVirtualTablePair );

    - - DONT FORGET THAT THE ADAPTER TABLE MIGHT NEED A REMOVE

    HELPER LIKE THE VIRTUAL TABLE USES ONE FOR ITS OWN REMOVE

    FUNCTION THAT GOES WITH A  AND THE INSTANCE STACK. I CAN

    SEE THE POSSIBILITY OF A CASE THATS SIMILAR BUT INVOLVES

    DECORATORS BEING REMOVED (BUT NOT DELETED)

                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /// VirtualTable(Add)( ... );
        //this works with destroy() in structures

    //#define
    //#include "defines/defineObject.h"//int* i=new(int)(this,123);
    ///destroy();
                                             ;//(chicken scratch)
    ///#define          this            vPop()


        #define FACTORY_C
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
           /// struct(struct)->override( class ((p)), ... );
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *  <OOC library that defines Object-Oriented essentials in C (C+)>  *
 *                                                                   *
 * Copyright (C) <2017 - 2021>  <Christopher Bond>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
        #ifdef ADAPTERTABLESINGLETON
        /*
        #include "structclass.h"

        #define Adapter(Member) Adapter##Member
        /**+---------------------------------+
         * @brief interface Adapter          |
         * +---------------------------------+
          / //simple, single adapter
        typedef struct
        {   struct class base;//empty

            struct class * self;                    //Class

            struct class (VirtualTable) * interface;//ClassVirtualTable
        }Adapter;


        typedef struct
        {   struct class (VirtualTable) base;

        }Adapter (VirtualTable);


        Adapter * AdapterInit( Adapter *, Object *,

            struct class (VirtualTable) * );

        void AdapterDtor( Adapter * self ) {}

        cstring AdapterWhat(){ return "Adapter"; }


        static Adapter(VirtualTable)

            Adapter(Interface) =

        { { &AdapterWhat, &AdapterInit, &AdapterDtor } };


        Adapter * AdapterInit( Adapter * self, Object * host,

            struct class (VirtualTable) * interface )

        { if(!self){return 0;}

            self->self = host;

            self->interface = interface;

          return self;}

    ///dont forget another alternative:  Pair(Class, ClassVirtualTable) adapter

    ///instead of:                       Adapter * adptr = new(Adapter)(this, ...);

    /// (the first one is equivalent to a data field position in the vTable)
        */


    explicit void Set( size_type i )//bool () * array [],
    {
        if( * s[i] == false ){ * s[i] = true;  }

            else

        if( * s[i] == true  ){ * s[i] = false; }
    }


        explicit Factory(02) * ControlFactory01 ( StackTop * p, ... )
        {
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
               ControlSlot[0]   =   & Control;

               LvlName          =   "00";

               LvlAddr          =   & ControlFactory01;
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
      if(Skip){Skip--;Controller();return & ControlFactory02;}
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
      if ( Template ){ Control = & ((p)) ; Template ((p)) ; }
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

        if ( Boolean )
          {
          /**  Default  **//*                                    */
          if ( Factory )
            {

            if ( Initial )
              {
                  Stack * stack = & ((p));

                  stack = ((void**)stack) + 1;

                  ((Function*)Controller)[0] = p;

                  ((ReturnStack*)Controller)[1] = arg(stack, ReturnStack);

                  Controller();
              }
            else
              {
                Control = true;

                if ( Terminate && *Control == ((Function*)Controller)

                    [0] )
             /**terminate factory control sequence with object return**/
                { Control = & ((p)) ;

                  return (StackControl*)((Function*)Controller)

                    [0]((p)); }



                                        /*
                */Control = & ((p)) ;/* /// ... ///
                                        /// ... ///
                                        /// ... ///

                *//*                    /// ... ///
                                        /// ... ///
                                        /// ... ///
                                                 */
                         /* if new(Class) passed in */
                if ( ((p)) == ((Function*)Controller)[0] )

                { Terminate = true;  /**<---**/

                  return & ControlFactory02;/**ctor next return**/
                }





                  if ( ! (((Function*)Controller)[0]) )
                  { throw ( new(AbortFactorySequence) )
                        (this, "FactoryAbort:" "00");/**abort**/
                  }





                  if( Terminate )
                  { return ((Function*)Controller)[0]((p));/**Factory**/
                  }





                  if ( (((ReturnStack*)Controller))[1] )

                  {
                    if ( !( ((Insert*)

                             ( (virtual( ((ReturnStack*)Controller)

                    [1], Container ) ) ))

                    [4]( ((ReturnStack*)Controller)[1],

                        ((Function*)Controller)[0]((p)) ) ) )  {}

                        /**Factory**/

                    vPop();
                  }

                  else

                  {
                    ((Function*)Controller)[0]((p));/**Factory**/
                  }




    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    for(unsigned short i = 0; i < 26; i++)

    {
        if(  ((  *JumpBuffers[i].val) == false   )
        &&   (   (JumpBuffers[i].end) == false  ))
        {

            JumpBuffers[i].end = true;          /**Control**/
        }


        if(  ((*JumpBuffers[i].val) == true   )
        &&   (( JumpBuffers[i].end) == true  ))
        {

            JumpBuffers[i].end = false;     /**Control**/
        }
    }
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * **/



                Control = false; /*<---*/

                /*Command-Style is where the iterator is halted*/

                Controller() ;/*<---*/




              }
            }
          else
            {
                /**CommandMode**/
           /*if ( !Factory )*/
            if ( Initial )
              {
                    Stack * stack = & ((p));

                    stack = ((void**)stack) + 1;

                    ((Execute*)Controller)[0] = p;

                    ((Class*)Controller)[1] = arg(stack, Object*);

                    Controller();
              }
            else
              {





                  Command * iterator = &(((Command*)Controller)

                  [   (Index)  ((p))   ]);/**Command**/





                    if ( !((Class*)iterator)[0] )
                    { throw ( new(AbortCommandSequence) )
                          (this, "CommandAbort:" "00");/**abort**/
                    }





                  ((Execute*)iterator)[1]( ((Class*)iterator)[0] );
                /**Command**/


              }

            }

          }
          return & ControlFactory02;
        }

        explicit Factory(01) * ControlFactory00 ( StackTop * p, ... )
        {
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
               ControlSlot[0]   =   & Control;

               LvlName          =   "00";

               LvlAddr          =   & ControlFactory00;
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
      if(Skip){Skip--;Controller();return & ControlFactory01;}
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
      if ( Template ){ Control = & ((p)) ; Template ((p)) ; }
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

        if ( Boolean )
          {
          /**  Default  **//*                                    */
          if ( Factory )
            {

            if ( Initial )
              {
                  Stack * stack = & ((p));

                  stack = ((void**)stack) + 1;

                  ((Function*)Controller)[0] = p;

                  ((ReturnStack*)Controller)[1] = arg(stack, ReturnStack);

                  Controller();
              }
            else
              {
                Control = true;

                if ( Terminate && *Control == ((Function*)Controller)

                    [0] )
             /**terminate factory control sequence with object return**/
                { Control = & ((p)) ;

                  return (StackControl*)((Function*)Controller)

                    [0]((p)); }



                                        /*
                */Control = & ((p)) ;/* /// ... ///
                                        /// ... ///
                                        /// ... ///

                *//*                    /// ... ///
                                        /// ... ///
                                        /// ... ///
                                                 */
                         /* if new(Class) passed in */
                if ( ((p)) == ((Function*)Controller)[0] )

                { Terminate = true;  /**<---**/

                  return & ControlFactory01;/**ctor next return**/
                }





                  if ( ! (((Function*)Controller)[0]) )
                  { throw ( new(AbortFactorySequence) )
                        (this, "FactoryAbort:" "00");/**abort**/
                  }





                  if( Terminate )
                  { return ((Function*)Controller)[0]((p));/**Factory**/
                  }





                  if ( (((ReturnStack*)Controller))[1] )

                  {
                    if ( !( ((Insert*)

                             ( (virtual( ((ReturnStack*)Controller)

                    [1], Container ) ) ))

                    [4]( ((ReturnStack*)Controller)[1],

                        ((Function*)Controller)[0]((p)) ) ) )  {}

                        /**Factory**/

                    vPop();
                  }

                  else

                  {
                    ((Function*)Controller)[0]((p));/**Factory**/
                  }




    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    for(unsigned short i = 0; i < 26; i++)

    {
        if(  ((  *JumpBuffers[i].val) == false   )
        &&   (   (JumpBuffers[i].end) == false  ))
        {

            JumpBuffers[i].end = true;          /**Control**/
        }


        if(  ((*JumpBuffers[i].val) == true   )
        &&   (( JumpBuffers[i].end) == true  ))
        {

            JumpBuffers[i].end = false;     /**Control**/
        }
    }
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * **/



                Control = false; /*<---*/

                /*Command-Style is where the iterator is halted*/

                Controller() ;/*<---*/




              }
            }
          else
            {
                /**CommandMode**/
           /*if ( !Factory )*/
            if ( Initial )
              {
                    Stack * stack = & ((p));

                    stack = ((void**)stack) + 1;

                    ((Execute*)Controller)[0] = p;

                    ((Class*)Controller)[1] = arg(stack, Object*);

                    Controller();
              }
            else
              {





                  Command * iterator = &(((Command*)Controller)

                  [   (Index)  ((p))   ]);/**Command**/





                    if ( !((Class*)iterator)[0] )
                    { throw ( new(AbortCommandSequence) )
                          (this, "CommandAbort:" "00");/**abort**/
                    }





                  ((Execute*)iterator)[1]( ((Class*)iterator)[0] );
                /**Command**/


              }

            }

          }
          return & ControlFactory01;
        }

        /** * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief  template macro for overload function      *
         *                                                   *
         * @param  self                                      *
         *                                                   *
         * @throw  throw(new(Exception))(this,"no function") *
         *                                                   *
         * @return macro param                               *
         ** * * * * * * * * * * * * * * * * * * * * * * * * **/
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

    #define defineFactory(name, rtrn, pram)\
    \
        explicit rtrn       name( pram self, ... )\
        {\
            if( !(*s[0]) ){s(0);ControlSlot[0][0]=&self;}\
    \
            rtrn val = ((rtrn(*)( pram, ... ))\
    \
                (*function( self, #name )))(this);\
    \
            s(0);\
    \
            return val;\
        }

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/

    #define defineFactory(name, rtrn, pram)\
    \
        explicit rtrn   name( pram self )\
        {\
            return ((rtrn(*)(pram))\
    \
                (*function( self, #name )))(this);\
        }
/*
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*            declare/initialize static interface            */
    static VirtualTable(VirtualTable) VirtualTable(Interface) =
    {//consider that every interface is a "singleton", that might
      {//mean that every interface in every file should be declared
        {//volatile...
          {
            {


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                  declare static interface                 */
    static AdapterTable(VirtualTable) AdapterTable(Interface) =
    {//consider that every interface is initialized to constant
      {//values because i don't believe in there being a need to
        {//declare every interface as volatile, i would
          {//recommend against it if i could give an educated
            {//opinion, unless its data field positions get
              &AdapterTableWhat,//re-initialized at runtime,
                                          //i (would) recommend
              &AdapterTableInit,//declaring it as volatile
                                          //then. (actually)



    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                      static interface                     */
    static FactoryTable(VirtualTable) FactoryTable(Interface) =
    {//remember that every interface is a "singleton" ...
      {//volatile may be desirable always there...
        {//volatile wont be needed unless its common to re -
          {//initialize data field positions (possibly)
            {
              &FactoryTable(What),

              &FactoryTable(Init),

              &FactoryTable(Dtor)
            },



    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief     function helpers for the factory table         *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                           map                             */
        /**+---------------------------------+
         * @brief map()->search()            |
         * +---------------------------------+
         */
        except explicit Class(FactoryMethod) map(cstring key)
        {///map( key ) X ->search( reg )  (PROG TERM AT X OR THROW)
            Class(FactoryMethod) list = FactoryTable(Interface)
                .map(ftable, key);

              if( !list ){if( Exception )
                {throw(new(Exception))
                (this,"ClassFactoryMethodNotFound");}
                else{return 0;}}

            return list; }
    /*                        multimap                           */
        /**+---------------------------------+
         * @brief multimap()                 |
         * +---------------------------------+
         */
        except explicit Reg multimap(cstring key, cstring reg)
        { ///multimap( key, reg )
            Reg r = FactoryTable(Interface)
                .multimap(ftable, key, reg);

              if(!r){if( Exception )
                {throw(new(Exception))
                (this,"RegNotFound");}
                else{return 0;}}

            return r; }
    /*                           end                             */



    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief    get instance of aTable, oTable, dTable          *
     * X *redefine macro default_prime for choice of table size* *
     *   - - (for __attribute__((constructor)) function) - -     *
     * @param          aSizeType size (size_type)                *
     * @return      0                                            *
     *                                                           *
     *            - - (see: central area in file) - -            *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*           this is for the triplet or tripleton            */
    explicit volatile aTable * volatile AdapterTable(Allocator)

        ( aSizeType size )//...

    {  AdapterTable(NewTable)(&atable, size);//singleton
       AdapterTable(NewTable)(&otable, size);//singleton
       AdapterTable(NewTable)(&dtable, size);//singleton

     if( 1 ){ return 0; }; }


noexcept explicit Constructor FactoryTable(Factory)( cstring name )
        noexcept   static   Constructor   (*factory)   (cstring) = 0;
                                     //factory("Class")(this, ...)
        static Class(FactoryMethod) map(cstring);
        static Reg multimap(cstring, cstring);

      except static Object * * (*function) (Object *, cstring) = 0;//
*/
//*///

   /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     *  typedef FactoryTable(Method) FactoryTable(FactoryTable); *
     *                                                           *
     *                                                           *
     *  THIS typedef WONT BE USED BECAUSE ITS NAMESPACE IS       *
     *                                                           *
     *  RESERVED. THERE IS ROOM IN THE NAMESPACE FOR A           *
     *                                                           *
     *  VirtualTable(FactoryTable) WHEN THE VIRTUAL TABLE        *
     *                                                           *
     *  IS A FACTORY OBJECT. class(FactoryTable) GETS EXTENDED   *
     *                                                           *
     *  INTO VirtualTable(FactoryTable) like class(VirtualTable) *
     *                                                           *
     *  GETS EXTENDED INTO VirtualTable(VirtualTable)            *
     *                                                           *
     *  AND class(FactoryTable) GETS EXTENDED INTO               *
     *                                                           *
     *  FactoryTable(FactoryTable) like class(VirtualTable)      *
     *                                                           *
     *  GETS EXTENDED INTO FactoryTable(VirtualTable).           *
     *                                                           *
     *                                                           *
     *  SO THERE IS ALSO NAMESPACE TAKEN FOR AN                  *
     *                                                           *
     *  AdapterTable(VirtualTable) AND AdapterTable(FactoryTable)*
     *                                                           *
     *  IF THERE WAS ANY REASON FOR class(AdapterTable) TO BE    *
     *                                                           *
     *  EXTENDED THEN THERE IS ROOM FOR A ClassAdapterTable OR   *
     *                                                           *
     *  Class(AdapterTable) IF EVER A FactoryTable(AdapterTable) *
     *                                                           *
     *  OR ... (might not need) SO TO CONTINUE ALSO THERE IS     *
     *                                                           *
     *  NAMESPACE RESERVED FOR A ... THAT IS Class(FactoryTable) *
     *                                                           *
     *  AND Class(Method) TO GO WITH Class(List) AS A STRUCT     *
     *                                                           *
     *  VARIABLE (AUTOMATIC) OF THE TYPE Class(Method)           *
     *                                                           *
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief this is the file where any components would go for *
     *                                                           *
     * handling an argument(s) stack for a function when it      *
     *                                                           *
     * gets called. there is not much to program to here,        *
     *                                                           *
     * other than the first idea (only idea) which was, a set    *
     *                                                           *
     * of components for replacing the variable arguments list   *
     *                                                           *
     * struct variable and its components... there was another   *
     *                                                           *
     * idea, the main reason to abandon the built-in va_list     *
     *                                                           *
     * was to be able to have a factory function that was called
     *
     * with only a
     *                                                           *
     *                                                           *
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

    #if 0
    "000000000\
    0000000000\
    0000000000\
    0000000000\
    0000000000"
    #endif // 0


/*                                                                         *
 *  TRY AND THINK OF SOME NEW ONES AND USE C++ AVAILABLE "FREE KEYWORDS"   *
 *                                                                         *
 *  THAT MAKE ME VERY CONTENT WITH BEING HERE IN C (FACTORY C)             *
 *                                                                         */

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief for programming to the factory object, this file   *
     *                                                           *
     *
     *
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief for programming to the factory object, this file   *
     *                                                           *
     * will be placed on the left, with structclass.h on the     *
     *                                                           *
     * right. to program to the factory object, consider that    *
     *                                                           *
     * the interface(s) needs to be engineered. this file is for *
     *                                                           *
     * the interface components that are used to engineer a      *
     *                                                           *
     * base type interface that is of a single responsibility or *
     *                                                           *
     * single purpose and placed inside structclass.h            *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/


    #undef  addDecorator //(decorator, object)
    #define addDecorator(decorator, object)\
    \
        AdapterTable(Interface).insert( dtable, decorator, object )

    #undef  getDecorator //
    #define getDecorator(decorator)\
    \
        AdapterTable(Interface).search( dtable, decorator )

    #undef  remDecorator //
    #define remDecorator(decorator)\
    \
        AdapterTable(Interface).remove( dtable, decorator )


    #include "Decoratable.h"


    /**  IN FEATHER.H :

    ctorPtr DuckFeatherDecoratorFact(){return decorator(Duck, Feather);}


    static struct class(DecoratorTable)

        DuckFeatherDecoratorFactory =
    {
        &classDecoratorTableType,

        &DuckFeatherDecoratorFact,

        0,
    };


    static Object** DuckFeatherDecoratorRegistrations[one] =
    {
        &DuckFeatherDecoratorFactory,

        nullptr
    };

    THERE IS ROOM FOR AN ATABLE INSTANCE FOR EVERY HELPER STYLE DESIGN

    PATTERN INCLUDING DECORATOR AND OBSERVER AS LONG AS THE NAMESPACE

    IS ADDED TO THOSE THINGS, SO:

    **//*
    #define decorator(Class, Decorator) (Decorator *)VirtualTable(Interface)\
    \
        .insert( vtable, vstk, (Decorator *)allocate(sizeof(Decorator)), \
    \
        & Class##Decorator##DecoratorInterface, & Class##Decorator##DecoratorInit )
    *//**

    THIS IS HOW THE ATABLE CAN BE EXTENDED, THIS MACRO SHOULD BE IN

    ITS OWN FILE OR INSIDE THE EXISTING FILE DECORATOR LIKE THE

    EXISTING FILE OBSERVER... THE FILE DECORATOR HAS AN ADVANCED

    STYLE OF DECORATOR IN IT THAT IS NOT FULLY DEVELOPED, I WOULD

    ADVISE NOT USING IT IF WHAT YOU WANTED WAS A SIMPLE DECORATOR.

    THIS MACRO SHOULD BE INCLUDED IN THE SINGLETON AREA OF THE FILE

    ATABLE, WHERE ADAPTER WILL BECOME THE DOMINANT PATTERN OF

    THE SET, SINCE AN INSTANCE OF IT WILL BE USED FOR OBSERVER,

    FOR DECORATOR, ...

    **//*
    #define observer(Class, Observer) (Observer *)VirtualTable(Interface)\
    \
        .insert( vtable, vstk, (Observer *)allocate(sizeof(Observer)), \
    \
        & Class##Observer##ObserverInterface, & Class##Observer##ObserverInit )
    *//**

        ProxyTable, pTable, ptable...

        AdapterTable still only because its adapting something

        into being a proxy instead of anything else

    */
    #define helper(Class, Helper, Adapter)\
    \
        (Helper*)VirtualTable(Interface).insert( vtable, vstk, \
    \
            (Helper*)allocate(sizeof(Class)), \
    \
            & Helper( Class, Helper, Adapter )(Interface),\
    \
            & Helper( Class, Helper, Adapter )(Init) )

    #define Helper( Class, Helper, Adapter ) Class##Helper##Adapter

    ///Object * obj = helper(Class, Helper, Adapter)(this, ...);



    - - #define    decorator( Class, Decorator )

    - - #define    observer( Class, Observer )

    - - (below) by create instance globally i mean declare
        a pointer globally and create an instance inside
        anything like a program constructor

    - - if the AdapterTable is extensible for its use
        its extensible in a way that you would create multiple
        instances of AdapterTables globally like otable,
        dtable, ... and use it to store the self pointer
        datamember for each object of each design pattern,

        since the AdapterTables datastructure will suffice, (there)
        and no more implementations will be needed for any
        more volatile OO tables, only every Class should
        have all of its static OO tables filled out,
        (see structclass.h)

        #define addDecorator(decorator, object)
        #define getDecorator(decorator)
        #define remDecorator(decorator)

        defineAbstractHashSet(AdapterClassPair, 32, );

        defineHashSetQProbe(AdapterClassPair, 32,

                        self->base.array[probe].key,

                        info.key,

                        self->base.array[probe].key != info.key,

                        self->base.array[probe].key == info.key
        );



    - - DONT FORGET THAT THE ADAPTER TABLE MIGHT NEED A REMOVE

    HELPER LIKE THE VIRTUAL TABLE USES ONE FOR ITS OWN REMOVE

    FUNCTION THAT GOES WITH A  AND THE INSTANCE STACK. I CAN

    SEE THE POSSIBILITY OF A CASE THATS SIMILAR BUT INVOLVES

    DECORATORS BEING REMOVED (BUT NOT DELETED)



    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**

                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*

                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*

                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*

                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**

                                                                 */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*              finish any previous definitions              */
    #undef  addAdapter //(adapter, object)
    #define addAdapter(adapter, object)\
    \
        AdapterTable(Interface).insert( atable, adapter, object )

    #undef  getAdapter //
    #define getAdapter(adapter)\
    \
        AdapterTable(Interface).search( atable, adapter )

    #undef  remAdapter //
    #define remAdapter(adapter)\
    \
        AdapterTable(Interface).remove( atable, adapter )





    /*                                                               * * * * * * *
     *                                                                           *
     *        a major part of the inspiration for this 4-year project            *
     *        was something that came from what i believe was stack-             *
     *        overflow.com and someone's quote from there:                       *
     *                                                                           *
     *        "classes are structures where each object has a hidden             *
     *         pointer inside the C++ virtual table"                             *
     *                                                                           *
     *        along with:                                                        *
     *                                                                           *
     *        "the vtable in C++ is declared as static"                          *
     *                                                                           *
     *        a second major source of inspiration was from the book             *
     *        OOC that i will do my best to keep a copy of its file              *
     *        with my own personal OOC library that was intended                 *
     *        as a datastructures library but i think im going to                *
     *        leave is with only the needed datastructures to                    *
     *        compile the vTable with. (and check out the vstk)                *
     *        singleton inside Exception.h for handling errors                   *
     *                                                                           *
     *        ...other future datastructures will be placed in a separate        *
     *        folder (possibly)                                                  *
     *                                                                           *
     *        from OOC (book) there was patterns for defining new(Class)         *
     *        along with delete(object) and patterns for Object, Iterator        *
     *        and Container                                                      *
     *                                                                           *
     *        struct class is an imported pattern i did little to change         *
     *        in honor of the stackoverflow.com blog that mentioned the          *
     *        pattern of putting a dtor in every object and provided the         *
     *        struct class                                                       *
     *                                                                           *
     *        define_list is an imported pattern i did little to change          *
     *        that proved that template and typename (C++ keywords) are          *
     *        not completely neccessary with the power of C macros and           *
     *        their token concatenation operator ## to concatenate two           *
     *        identifier tokens into one identifier or two operator              *
     *        tokens into one operator like: =##= ... that concatenates          *
     *        to == ... and <=, +=, -=, ... can be formed when = is a            *
     *        macro argument in a way that arg##= concatenates to ==             *
     *        with macro(=) ##= or #define defineOperator(op) op##=              *
     *        (this is all about operator concatenation not identifier           *
     *        concatenation but u prolly get it) define_list was a blog          *
     *        about templates in C on stackoverflow.com                          *
     *                                                                           *
     *        if you can understand this library (OOC by willy A.K.A.            *
     *        CWJB) as your own then you can take with you the patterns and      *
     *        practices included here all the way into pure OO languages         *
     *        like C++ and Java and know that its like driving a car thats       *
     *        an automatic where OO programming in C (the one and only)          *
     *        is like driving a standard                                         *
     *                                                                           *
     *        there you can reflect or take note of pure OO things like          *
     *        using new as an operator, and especially implementing              *
     *        interfaces by implement i mean implement the structure that        *
     *        provides an interface of functions, a set of functions             *
     *        for the interfaces pointers to point to are never                  *
     *        implemented in a pure interface, and the constructor               *
     *        is never implemented, and a virtual destructor is apparently       *
     *        always implemented (i kinda get that one) but anyways the list     *
     *        goes on and on                                                     *
     *                                                                           *
     *        when it comes to C++ and its classes remember what it comes down   *
     *        to here in some of these files because the patterns here are       *
     *        designed with C++ in mind and are parallel to for the most part.   *
     *        so u can then see what goes on at the C level of doing things      *
     *        with C++ interfaces and some of the compile errors people get      *
     *        when implementing interfaces there in C++, implementing an         *
     *        interface in C is something that takes a lot of quiet careful      *
     *        thought, never all the problems getting tied up in a knot like     *
     *        with compiling C++ interfaces even when you know what you want.    *
     *                                                                           *
     *        what i understand is that you can declare a structure without      *
     *        implementing it, and then declare a pointer to that structure by   *
     *        data type. this being said you can have pointers used by an        *
     *        interface that are for unimplemented structured data types and     *
     *        even a C++ interface should only use pointers for things passed    *
     *        or returned to/from functions NOT references... thats all and      *
     *        this is a 4-year long project in reverse engineering thats just    *
     *        come to a close (2021 - 03 - 07)                                   *
     *                                                                           *
     *        C itself is still useful at least when considering writing an      *
     *        operating system...                                                *
     *                                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "Adaptable.h"



/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/* [ctrl] - z for undo, [ctrl] - x for cut, [ctrl] - c for copy, [ctrl] - v for paste*/
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**
                           ________  ________  _______
                          /\  ____ \/\  ____ \/\  ____\
                          \ \ \__/\ \ \ \__/\ \ \ \___/
                           \ \ \ \ \ \ \ \ \ \ \ \ \
                            \ \ \_\_\ \ \ \_\_\ \ \ \____
                             \ \_______\ \_______\ \______\
                              \/_______/\/_______/\/______/

    */
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/* [ctrl] - z for undo, [ctrl] - x for cut, [ctrl] - c for copy, [ctrl] - v for paste*/
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * define OOC:                                                               *
     *                                                                           *
     *      When we talk about C, we are talking from inside a little window,    *
     * and the world outside this little window is like the Object-Oriented      *
     * paradigm structured around C's procedural core. New stuff like C++, Java, *
     * and JavaScript all define this structure that surrounds C's core, with    *
     * no limitations on data types or how they are used. OOP is a way of        *
     * thinking. (from a point of view) We can sit and speak freely of things    *
     * like the abstraction of how everything can be considered an object.       *
     * OOC can be where we define this object-driven structure ourselves, as OOP *
     * in C or OOC.                                                              *
     *                                                                           *
     *      Object-Oriented Programming is not defined as early as C, but we do  *
     * have the struct mechanism to start with. A struct is a structure and the  *
     * way to implement structured data types in C. The C compiler treats        *
     * struct memory as special memory that uses a data member access operator   *
     * or dot operator (.) as the direct access operator. The C compiler also    *
     * treats a pointer to struct memory as special memory itself that uses      *
     * a data member access operator or pointer arrow (->) as the indirect       *
     * access operator. A struct variable is an improper array, when each value  *
     * is placed a multiple of its own byte size from the starting address. Now  *
     * we dont need to map a data field position to a cast ourselves, we can     *
     * forget casts and forget data field positions just remember what our       *
     * declared data members are named. Don't forget as i am coming back here    *
     * from Factory C to give a further definition, But an implemented structured*
     * datatype, a struct and its variable is not every answer to every problem. *
     * There may still be a point in time, even with permanent fortifications    *
     * for the C struct and the C union here in OOC, a time when a structs       *
     * integrity may be compromised and will then need to be abandoned.          *
     * regardless, my personal definition or style (flavour) of OOC will serve   *
     * the purpose of fortifying the implemented structured datatype as strongly *
     * as possible, for my own personal reasons (prelude to Factory C).          *
     *                                                                           *
     *      When a pointer is dereferenced it returns the reference of the data  *
     * type the pointer is used to point to as a data type itself. There is also *
     * a pointer type that returns no data type when dereferenced, a void        *
     * pointer. This special type of pointer accepts a cast to any pointer type. *
     * Since an array is a pointer, a void pointer can be used to handle memory  *
     * as an array of any data type, one data type at a time. The dot operator   *
     * is similar to applying a cast to a void pointer and then incrementing     *
     * the pointer by an amount that you can always consider it to be a multiple *
     * of that data type's byte size or index i * byte size when i is the        *
     * numbered data field position inside memory or array index. With this      *
     * being said, a struct variable or object is an array with multiple data    *
     * types being used inside.                                                  *
     *                                                                           *
     *      Since Object-Oriented Programming is not defined as early as C we    *
     * can take the liberty to define it ourselves here in OOC with the careful  *
     * consideration of how we define our interface. If there's only one list of *
     * pointers initialized for an objects interface of pointers to functions    *
     * per struct implementation then we have a static interface. If there's a   *
     * full list of pointers initialized for an objects interface of pointers    *
     * to functions per object then we have a fully strategic interface or a     *
     * dynamic one. Meaning each object can take the liberty of pointing to a    *
     * different function for it's interface. On the other hand we have a lot    *
     * less pointer allocations and initializations to be aware of. (i must note *
     * that in OOP static and dynamic are terms used alongside one another, to   *
     * call an interface a strategic one is to do so with consideration of       *
     * design patterns and the strategy function pattern). Another note would    *
     * be that just as long as there is strategic inclinition (inclined) that    *
     * is all thats needed, the strategically inclined interface is separated    *
     * in another struct from the struct containing data members. The majority   *
     * of functions called from an interface as methods need not be strategic.   *
     *                                                                           *
     *      You can define an interface by declaring a struct and implementing   *
     * it with pointers to functions (function pointers) as data members. You    *
     * can declare a struct without implementing it and then declare a pointer   *
     * to that struct datatype. This way we can provide an interface that uses   *
     * unimplemented structured data types. (implementing them all only when we  *
     * need to)                                                                  *
     *                                                                           *
     *      You can type define a struct in the statement it's declared by using *
     * typedef. This transforms the comma delimited list of structure aliases    *
     * also known as objects in-between the end block separator (}) and statement*
     * terminator(;) into a comma delimited list of user defined types also known*
     * in this case as Class Names. (by default, structs use a struct name or    *
     * data type name preceeded by/with the struct keyword)                      *
     *                                                                           *
     *      The first parameter of every member function is to be reserved for a *
     * self pointer or a pointer named self thats for the object to pass itself  *
     * into it's own function as the function is called from the object through  *
     * a pointer.                                                                *
     *                                                                           *
     *      The first data field position of each struct structure is to be      *
     * reserved for an automatic variable named base. (for simple inheritance by *
     * casting).                                                                 *
     *                                                                           *
     *      It might be helpful to define some the the major structures used in  *
     * C++ OOP here in OOC. (simple) Classes are structures where each object    *
     * has a hidden pointer inside the virtual table. (vtable) The vtable in C++ *
     * declared as static. This is the ObjectFactory and using it in C++ is      *
     * is using new(Class) with the constructor and delete(object) as it's       *
     * front-end. "We can take the liberty to define our own vtable in OOC, one  *
     * that keeps a pointer to that objects what() function as the value that the*
     * objects address is the key to."-author (if not its pointer to it's static *
     * interface). This way, we can have a vtable that knows where every object  *
     * is and what it is. This solves a problem that we may find later on: when  *
     * all of the programs objects go inside one list, how can we tell what      *
     * anything is? This has been updated to use a strategically inclined        *
     * interface and each object is assigned an interface by new(Class) along    *
     * with an initializer the constructor can point to (not just the typeid     *
     * function).                                                                *
     *                                                                           *
     *      The constructor is the pointer used to call the initializer          *
     * function from new(Class).                                                 *
     *                                                                           *
     *      Using inheritance, and something known as the dynamic binding of a   *
     * base pointer (abstract) used to point to derived memory (concrete) we can *
     * achieve polymorphism, the single most powerful application of a pointer   *
     * in C.(more powerful than simple arrays) From there we can take advantage  *
     * of a number of things like the information hiding technique of hiding all *
     * proper data members inside derived (using base and derived types) making  *
     * them inaccessible from a base pointer, leaving access only to the         *
     * functions that use such data members, since the base pointer being used   *
     * would be passed into its function as a derived pointer.                   *
     *                                                                           *
     *      Using the preprocessor directive define we can write                 *
     * define(Type)(type) macros to give the definition of how things like       *
     * data structures will be implemented. This is an information hiding        *
     * technique where things like the data type used within a data structure    *
     * is hidden from the implementation. Using this technique, we provide the   *
     * the data type only when the data structure is implemented, when the       *
     * define(Type)(type) macro is used with its parameter(s). These macros      *
     * should be written as x-macros.                                            *
     *                                                                           *
     *      An x-macro is an accumulation of macros defining the macro using     *
     * another macro inside of it first.                                         *
     *                                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/* [ctrl] - z for undo, [ctrl] - x for cut, [ctrl] - c for copy, [ctrl] - v for paste*/
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/**
       _______                  __                                  _______
      /\  ____\                /\ \__                              /\  ____\
      \ \ \___/  ___      ___ /\__  _\    ___   ____   __  __      \ \ \___/
       \ \  _\  / __`\   / ___\/_/\ \/   / __`\/\  _`\/\ \/\ \      \ \ \
        \ \ \/ /\ \/\.\_/\ \__/_ \ \ \/\/\ \/\ \ \ \_/\ \ \_\ \      \ \ \____
         \ \_\ \ \___/\_\ \_____\ \ \__/\ \____/\ \_\  \ \____ \      \ \______\
          \/_/  \/__/\/_/\/_____/  \/_/  \/___/  \/_/   \/___/\ \      \/______/
                                                          /\ \_\ \
                                                          \ \____/
                                                           \/___/
 */
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
/* [ctrl] - z for undo, [ctrl] - x for cut, [ctrl] - c for copy, [ctrl] - v for paste*/
/// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * define Factory C:                                                         *
     *                                                                           *
     *      Factory C is where i made it to after starting Head First: Design    *
     * Patterns and translated about half the code examples from the book into C.*
     * Factory C is where i am at the level i am even confident i can get a job  *
     * as a programmer where i want. I made it over the hill that was there and  *
     * i am in the clear now, object-oriented programming as it has been defined *
     * previously in other places, is in need of re-implementation to support    *
     * the solutions provided by Factory C (Willy's C Factory). I won't get into *
     * how it needs to be re-implemented here, but i can tell ya it does. Or its *
     * just Factory C that is worth writing an operating system with. C++ has no *
     * further use to me, Java does for reasons of its method of deployment,     *
     * after that is JavaScript. This will all be made staticly available at a   *
     * static distribution site, i am not sure right now what namespace that will*
     * be of... C was used to write compilers in the past and i am confident     *
     * of C's integrity and its procedural purpose of its trajectory mechanism,  *
     * the pointer. After this has all been made staticly available, with FSF    *
     * (free software foundation) copyrights that have been validated given i    *
     * host the distribution site myself, i can give it to you (the programmer)  *
     * in the hope that it will be useful, (without warranty) in the hope that   *
     * all of the general practices displayed will be adopted and made good use  *
     * of. Adopt all the general practices here would be my advice. Factory C is *
     * C Factory, as i have still made no changes to the C compiler.             *
     *                                                                           *
     *      OOC was what this project was always called, or New even, since      *
     * i was inspired by the book named OOC to define new(Class) and             *
     * delete(object). their definition of new(Class) was: #define new(Class)    *
     * malloc(sizeof(Class)). and delete(object) was: #define delete(object)     *
     * free(object). It wasn't much but was what inspired me to work in C,       *
     * leaving C++ behind me for good now.                                       *
     *                                                                           *
     *      I have come a long way from simple C procedural programming to       *
     * writing my own personal definition of OOP in C or OOC, using a virtual    *
     * table object with simple inheritance to achieve polymorphism as basic     *
     * object-oriented programming, to using a factory table. A factory object   *
     * in Factory C is not only a virtual table object but an object of a        *
     * factory table class. The class factory method for a factory table class   *
     * is used for that class interface heap. I tell ya its not multiple         *
     * inheritance, but multiple inheritance is within reach when the factory    *
     * table class interface heap is within reach. I tell ya an object-oriented  *
     * interface is not as dynamic as calling a global function, when that global*
     * function is one of a set of C central overload functions, each one a      *
     * central function that controls data types that get passed in, calling     *
     * the appropriate (versions) functions only used by the appropriate classes *
     * and their objects. I tell ya that a central override method can be implemented *
     * to perform a runtime override on any data field position of any interface *
     * to re-initialize that interface method to the address of any other        *
     * function in the program before runtime ends. I can tell ya too that there *
     * are ways, (including final where final is defined as const) to prevent    *
     * this, including information hiding at the point of where the factory      *
     * table has access to the class factory method for a class, but not a       *
     * pointer to its registration list (interface heap). My best work is in the *
     * class factory method, and its a singleton pattern being displayed with    *
     * every class. I only want to have my sights set there in Factory C, I      *
     * tells ya, its what i consider important to all this. All i want to think  *
     * about in Factory C is the class factory method and a factory table class  *
     * interface heap. After that i can announce that there will be room for a   *
     * small runtime class builder built on the foundation of the concrete class *
     * type extended from struct class and having an extra parameter in its      *
     * constructor thats for an extra amount of bytes to allocate. Also, there   *
     * is support for fully dynamic instances using factory("Class")(this,...)   *
     * instead of new(Class)(this, ...), a function that a factory table class   *
     * has support for, even one that has just a single interface (registration) *
     * in its heap.                                                              *
     *                                                                           *
     *      My definition of Factory C and why its really called C Factory       *
     * or Factory C (and i want it to stay that way) is not only because it      *
     * uses a factory table but also because it uses a factory control sequence  *
     * (double whammy). The C factory control sequence i implemented is my time  *
     * off from the difficult implementations of OO-Programming. It covers       *
     * the command pattern, factory pattern (factory function), and the control  *
     * pattern. Factory C will be presented in a way that promotes the use of    *
     * its C Factory. Up to 99 functions can be called one after another without *
     * specifying their names, in sequence, and in a single statement. The       *
     * purpose of this is to control the returns of up to 99 factory functions   *
     * each one in its slot in an array. based on my template arrays pattern from*
     * 2017, a factory control sequence function encapsulates a factory function *
     * and calls it from its slot in the array. the encapsulated factory makes   *
     * a call to control(), the first thing to be made an operator when Factory  *
     * C becomes a compiler that compiles into C. The control() call is to       *
     * initialize the stack pointer for the encapsulated factory function to     *
     * the stack top of the factory control sequence factory function. So the    *
     * encapsulated factory function gets all the parameters passed into the     *
     * encapsulating factory function and returns onto a stack, using the        *
     * Object Oriented Container interface and a Container pointer for the       *
     * return stack. There are 8 global s and room for more s, i will    *
     * always consider there being room for another global , as long as its  *
     * volatile and as long as there is a problem that seems unsolvable          *
     * procedurally. The factory control sequence makes use of its global        *
     * ging to do things like return an object from out of its sequence.     *
     * The factory sequence uses a controller (iterator) to go from one factory  *
     * function to the next. using another , the controller can stay parked  *
     * on a single function and have it called repeatedly, returning onto its    *
     * stack each time unless a controlled return object case is made. The       *
     * FactoryArray type that it uses is comparable to a CommandArray and is     *
     * interchangeable with, when another  is raised or lowered. It switches *
     * from Command to Factory without having to change the array even, if its   *
     * an array of multiple types, i should note that it would terminate the     *
     * program if the wrong array was given to the control sequence at the wrong *
     * time. when the arrays themselves can be virtual table objects and passed  *
     * in a way they are checked for there typeid, that would be to assert       *
     * control there (not saying they are checked by typeid just that they can   *
     * be). Exception objects are defined here in a way they can be thrown like  *
     * anywhere else, and i defined an Assertion object also that lets you print *
     * the assertion case after making the assertion, and having that case pass. *
     * Assertions are, as of right now, left on the virtual table's instance     *
     * stack it uses between the function underneath new(Class) itself and the   *
     * constructor that gets called after. so:                                   *
     *                                                                           *
     * new(Assertion)(this, assert( case )); is used instead of assert( case )   *
     * dont forget that assert used inside the Assertion constructor is different*
     * from the old assert and the old assert is now Assert( case ). Print s *
     * are another thing i use for debugging/error handling, when whatever print *
     *  is raised, print functions are called, printing things i need to see *
     * when debugging. print statements that are then made permanent like the    *
     * implementations they print for. new(Class) and factory("Class") wont throw*
     * an exception, as virtual(object, Class) -> may, when a  is raised or  *
     * lowered it marks the difference of whether or not its going to throw or   *
     * return 0, that would terminate the program at the point of where you see  *
     * an X ahead:  virtual( object, Class )   X   -> method(this) if 0 (null)   *
     *                                                                           *
     *      Factory C and its C Factory (Control Sequence) is what Factory C is  *
     * presented with by using. Its a strong Command/Control mechanism thats even*
     * centered around factory functions (Factory). It comes with 99 control     *
     * functions, 26 index pointers complete with a jump  for each and an    *
     * array of 26 jump  pointers and markers. also there is a (unused)      *
     * jumpBuf variable for each index. each index pointer has a default control *
     * block to copy into a runtime array, itself being a static array of 4 slots*
     * start - check - block - probe. thats just the default block also. the     *
     * block slot in a control block can be replaced with as many slots desired. *
     *                                                                           *
     * see: int i = 0;                                                           *
     *      try{  using template(Control, Start)(& i)(i < 9)(&func)(++i);  }     *
     *      catch (Exception * e) {}                                             *
     *                                                                           *
     *      try{  using template(Command, Start)(1)(3)(5)(7)(9);  }              *
     *      catch (Exception * e) {}                                             *
     *                                                                           *
     *      new(double);                                                         *
     *      new(double);                                                         *
     *      try{  using template(Factory, Start)(this, .99)(this, 1.29);  }      *
     *      catch (Exception * e) {}                                             *
     *                                                                           *
     *      Don't forget that these 3 configurations are so interchangeable      *
     * by means of global ging, 2 types of array are used, Control actually  *
     * still would use a FactoryArray, theres a  for a template setting      *
     * that just calls a function from the global Template pointer for a factory *
     * control sequence function and its case it has when it gets called.        *
     *                                                                           *
     *      Template as a pattern that involves the typename macro here is the   *
     * most well fortified pattern of Factory C. The C Vector used here was the  *
     * first implemented version of Container. from 2017 itself, it is so well   *
     * fortified here that, every volatile program level table is extended from  *
     * it by simple inheritance (sharing macro implementations, but not compiler *
     * implementations). The C Factory Vector itself is also somewhat volatile,  *
     * that goes towards my feelings of it being a Vector(type) and not an       *
     * ArrayList(type). if it were typenamed as volatile typename(Vector)(int, ) *
     * or if its object were labeled as volatile it would be more volatile,      *
     * but does not need to be labeled as volatile from top to bottom, like the  *
     * virtual table or factory table or adapter table (singletons). a macro
     * with a parameter it uses for compiler string concat and variable type
     * declarations... (not done)
     *
     *
     *                                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


    explicit void init(void)
        {VirtualTable(NewTable)(&vtable,default_prime);}

    explicit void destroy(void)
        {VirtualTable(Destroy)(&vtable);}


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief    search for a registration under a class name    *
     *      - -                                             - -  *
     * @param                 fTable  ftable                     *
     * @param                  cstring name                      *
     *                                                           *
     * @return     registration                                  *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit Interface FactoryTable(MultiMap)

        ( volatile fTable * volatile self,

          cstring className, cstring regName )

    { Class(FactoryMethod) p = FactoryTable(Interface)
        .map( self, className );
      if( !p ) { return 0; } else { return
           p->search( regName ); } }






    #define defineClassFactoryMethod(Class, First, Last)\
    \

    #define define

        Interface iterator[3]  =  { &Volatile(Type), 0, 0 };\
    \
                                     volatiletype = reg;\


        Type iterator  =  { key, 0 };\


    \
        Interface(Heap) heap   =   Interface(Search)(\
    \
        ClassInterfaceHeap, iterator, & i, First, Last );\



    \
        Type p     =     Type(Search)(\
    \
        VirtualTable(Interface)(Heap), iterator, & i, First, Last );\


    \
            if( p ){ return ((*p)) ; } else { return 0; }  }


        Class (Search) (cstring reg)\
    \
        {
    \
            fSizeType i;\



    #define defineType(Class)\
    \
        Class(Type)(void) ;\
    \
      explicit cstring Class(Type)(void)


    #define defineFact(Class)\
    \
        Class(Fact)(void) ;\
    \
      explicit Constructor Class(Fact)(void)


    #define defineSetup(Class)\
    \
        Class(Setup) () ;\
    \
      explicit void Class(Setup)(void)



        Class (Search) (cstring key)\
    \
        {
    \
            fSizeType  i;\

    \
            if( p ){ return ((*p)) ; } else { return 0; }  }




    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
         CONSTRUCTION;       CONSTRUCTION;       CONSTRUCTION;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    # if 0

    #define defineSubFactoryMethod(Class, Type, Name, First, Last)\
    \
        Class (Search ## Name) (cstring key)\
    \
        {   Type pair = { key, 0 },\
                    * p;\
            size_t    i;\
    \
            p = Type##Search \
    \
                ( Class##Name##Table, pair, & i, First, Last );\
    \
            if ((p)) { return ((p)) ; } else { return 0 ; } }


    #define defineClassFactoryMethod(Class, First, Last)\
    \
        String (Search ## Name) (cstring reg)\
    \
        {   Interface iterator[3] = { &Volatile(Type), 0, 0 };\
    \
            fSizeType i;               volatiletype = reg;\
    \
            InterfaceHeap p = InterfaceSearch \
    \
                ( String(InterfaceHeap), iterator, & i, 0, 7 );\
    \
            if( p ){ return ((*p)) ; } else { return 0 ; } }


    explicit Object * String(SearchLibrary)(cstring key)

    {   Strategy  pair = { key, 0 },
                * p  ;
        size_type i  ;

        p = StrategySearch( String(LibraryTable), pair, & i, 0, 82 );

        if( p ) { return p->val; } else { return 0; } }


    explicit Object * String(SearchMethods)(cstring key)

    {   Interface table = { key, 0, 0 }; /*SINGLE SLOT*/
        size_t    i;
                                         /*TABLE LENGTH STORED HERE*/
        return InterfaceSearch( StringMethodsTable, table, &i, 0, 19 ); }


    (Class*)VirtualTable(Interface).insert(

        vtable, vstk, (Class*)allocate(sizeof(Class)),

        & Class(Interface), & Class(Init) )

    # endif // 0
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
         CONSTRUCTION;       CONSTRUCTION;       CONSTRUCTION;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///



#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * <library that defines Object-Oriented essentials in C (Complex C)>*
 *                                                                   *
 * THIS SOFTWARE IS NOT COPYRIGHTED                                  *
 *                                                                   *
 * This source code is offered for use in the static domain.         *
 * You may use, modify or distribute it freely.                      *
 *                                                                   *
 * This code is distributed in the hope that it will be useful, but  *
 * WITHOUT ANY WARRANTY.  ALL WARRANTIES, EXPRESS OR IMPLIED ARE     *
 * HEREBY DISCLAIMED.  This includes but is not limited to           *
 * warranties of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.*
 *                                                                   *
 * <jb.bee250@gmail.com> <Christopher Bond>                          *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "../Factory/fTable.h"  //this will get the job done A+

    #include "class.h"   //concrete class with strategic destructor
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**||               COMPLEX OBJECT (COMPLEX C)            || *
     *                                                           *
     * ||                 by Willy (03/30/2022)               || */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                       complex object                      */
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief   complex type.                                    *
     *                                                           *
     * components:    [class]/[function]/[namespace]/[complex]   *
     *                                                           *
     *     - namespace                                           *
     *                                                           *
     *     - class                                               *
     *                                                           *
     *     - function                                            *
     *                                                           *
     *     - complex (or just the constructor)                   *
     *                                                           *
     * construction:  [Polymorph]/[Interface]/[Namespace]        *
     *                                                           *
     *     - Polymorph                                           *
     *                                                           *
     *     - Interface (MethodsTable)                            *
     *                                                           *
     *     - Object                                              *
     *                                                           *
     *                                                           *
     *     - VolatileType                                        *
     *                                                           *
     *     - VolatileSearch                                      *
     *                                                           *
     *     - X                                                   *
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #define complex(member)complex ## member

  #if       ABANDONED
    typedef struct
    {   class base;

        Container * descriptions, indexes, offsets, lengths;///, ...

    }complex;
  #endif // ABANDONED
  #if       ABANDONED
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief these are for a struct assignment only             *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    typedef struct complex(VirtualTable)
    {   class (VirtualTable) base;
    }complex(VirtualTable);

    static complex(VirtualTable) complex(Interface) =
    { { & VolatileType, & complexInit, & class(Dtor) } };
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
  #endif // ABANDONED
  #if       ABANDONED
    static complex * complexInit( complex *, ... );

    explicit complex *

      complexInit( complex * self, ... )

    { if(!self){return 0;}

      Stack * stack = control();

    return self;}
  #endif // ABANDONED
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #undef complex


    #define        complex(cstring)        FactoryComplex(cstring)
            //use in place of virtual or something

    static Constructor FactoryComplex(cstring) ;

    explicit Constructor FactoryComplex(cstring type)

    {
        size_type           object;      // =

        Class(VirtualTable) interface;   // =

        Constructor         construct;   // =


        return VirtualTable(Interface).insert(

            vtable, vstk, object, interface, construct );
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                          OBJECT
                 +-----------------------------------+
                 | - stack of base types             |
                 |                                   |
                 +-----------------------------------+
                 | - stack or improper array?        |
                 |                                   |
                 +                                   +
                 |                                   |
                 |                                   |
                 +-----------------------------------+




                               INTERFACE
                 +-----------------------------------+
                 | - stack of base types             |
                 |                                   |
                 +-----------------------------------+
                 | - always a proper array           |
                 |                                   |
                 +                                   +
                 |                                   |
                 |                                   |
                 +-----------------------------------+



     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* clipboard:

    - - so there needs to be a factory table class inside
        the ftable called the builder. its class interface heap
        will include a singleton table for a single non-virtual
        table object and will have to start with creating a
        runtime version of a virtual table object using a runtime
        table for each struct (Object + Interface) and (Polymorph)
        for handling multiple inheritance.

    - -


    - - to fully include everything non-object-oriented from the C
        library, there needs to be some more careful thought
        towards more combinations of types, using primitives, ...

    - - i figure that the class builder is the place to keep
        everything object oriented but hopefully i can still
        put every C library function inside a Strategy table
        thats a Library table



        typedef double   (*DFac)( double, ... );   X

        #if 0
        static Object * ClassBuilderFunction( Stack *, ... );

        explicit Object * ClassBuilderFunction( Stack * self, ... )
        {
                //one thing gets passed into a function

                //two things get passed into a function




        }
        #endif // 0

    - - there needs to be a case for every datatype by string id

        typedef ctorPtr  (*Func)( cstring );///factory("Class")(this, ...);

     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *                                                           *
     *  THIS CLASS BUILDER SEEMS TO BE ANOTHER REASON WHY ALL    *
     *                                                           *
     *  FUNCTIONS NEED TO BE IMPLEMENTED AS FACTORIES THAT MAKE  *
     *                                                           *
     *  A CONTROL CALL ON A STACK POINTER, I BELIEVE.            *
     *                                                           *
     *                                                           *
     *  THIS WILL BE A CASE THATS LIKE A CERTAIN CASE SOMEWHERE  *
     *                                                           *
     *  IM SURE, ... ITS LIKE THE CONCEPT OF HOW YOU typedef A   *
     *                                                           *
     *  DATATYPE THATS A POINTER TYPE OR TYPE USING A QUALIFIER  *
     *                                                           *
     *  BEFORE USING typename HERE. THIS HERE IS THE CASE OF WHERE
     *                                                           *
     *  YOU NEED TO typedef A FUNCTION DATATYPE BEFORE RETURNING *
     *                                                           *
     *  THAT DATATYPE FROM A FUNCTION FOR THAT FUNCTIONS         *
     *                                                           *
     *  DECLARATION PROTOTYPE.                                   *
     *                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */

    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**||               CLASS BUILDER (COMPLEX C)             || *
     *                                                           *
     * ||                 by Willy (03/30/2022)               || */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                       class builder                       */
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief   class builder (complex type).                    *
     *                                                           *
     * components:    []/[]/[]/[]                                *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     * construction:  [Construct]/[]/[]/[]                       *
     *                                                           *
     *     - Construct                                           *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*           class builder: typedefs for functions           */
    typedef Object * (*Fact)( Object *, ... );/// #1

    typedef Object * (*CFac)( const Object *, ... );

    typedef Object * (*Meth)( cstring );///#2

    typedef cstring()(*Type)(void);

    ///object-oriented function types (Factory C functions/methods)

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /*     volatile search goes in factory table slot    */
        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /** * * * * * * * * * * * * * * * * * * * * * * * * **
         * @brief    volatile class factory method           *
         *                                                   *
         * i cant remember what this was for but i knew that *
         * there was room for it and so i implemented it. it *
         * was meant for where the factory table needs one   *
         * class factory method for all of them or something *
         * that was anyways volatile. so here is the volatile*
         * class factory method. if i find a reason to use   *
         * this i can remember, then i will make a note of   *
         * it here.                                          *
         *                                                   *
         * (fits in the same place as class factory method,  *
         * only 100% dynamic and volatile, if preferred, one *
         * can declare another variable like the rest named  *
         * index for where parameter 4 is getting a 0        *
         * passed) (for a starting point).                   *
         ** * * * * * * * * * * * * * * * * * * * * * * * * **/
        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /* this was for the builder package for a factory    *
         * table class, that includes a runtime object for   *
         * an interface that is assigned to virtual table    *
         * objects after, that includes the volatile type    *
         * function used by the factory table, it also       *
         * includes extending the class factory method and   *
         * sub factory method structs ...                    */
        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
              static volatile fSizeType volatilesize = 0;

static volatile Interface volatile volatileiter[3]={&Volatile(Type),0,0};

        static volatile InterfaceHeap volatile volatileregs = 0;


        static Interface Volatile(Search) ( cstring );


        explicit Interface Volatile(Search) ( cstring reg )

        {   volatiletype = reg;

            InterfaceHeap p = InterfaceSearch( volatileregs,

                                               volatileiter,

                                              &volatilesize, 0,

                                               volatilesize );

            if( p ){ return ((*p)) ; } else { return 0; } }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* clipboard:

    - - 00-99 (tower) implementation for each case of there being
        an amount of parameters getting passed into a function, as
        every time its a pointer getting passed i just decided,
        meaning the complex object will only work with other objects.

    - - the primitive as factory object typename will prove helpful
        for this case of there being only objects allowed in use
        within the complex objects data members.

    - -

     */
    /*

     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    #define complex(member)complex ## member


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief these are for a struct assignment only             *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    typedef struct complex(VirtualTable)
    {   class (VirtualTable) base;
    }complex(VirtualTable);

    static complex(VirtualTable) complex(Interface) =
    { { & VolatileType, & complexInit, & class(Dtor) } };
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
  #endif // ABANDONED
  #if       ABANDONED
    static complex * complexInit( complex *, ... );

    explicit complex *

      complexInit( complex * self, ... )

    { if(!self){return 0;}

      Stack * stack = control();

    return self; }
  #endif // ABANDONED
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    #undef complex


    #define        complex(cstring)        FactoryComplex(cstring)
            //use in place of virtual or something
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*

        typename(Table)(ClassVirtualTable,Constructor,SizeT);
        typedef  Table (ClassVirtualTable,Constructor,SizeT)

        //complex = descriptions, indexes, offsets, lengths;

                                               Construct;
     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING;WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING;WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
    #if 0
             Object * cmplx = factory("Class")(this, ...);
    #endif // 0
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING;WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<library that defines Object-Oriented essentials in C (Complex C)> *
 *                                                                   *
 * Copyright (C) <2017 - 2022>  <Christopher Bond>                   *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <jb.bee250@gmail.com>.              *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
#endif // COMPLEX_H_INCLUDED

#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * <library that defines Object-Oriented essentials in C (Complex C)>*
 *                                                                   *
 * THIS SOFTWARE IS NOT COPYRIGHTED                                  *
 *                                                                   *
 * This source code is offered for use in the static domain.         *
 * You may use, modify or distribute it freely.                      *
 *                                                                   *
 * This code is distributed in the hope that it will be useful, but  *
 * WITHOUT ANY WARRANTY.  ALL WARRANTIES, EXPRESS OR IMPLIED ARE     *
 * HEREBY DISCLAIMED.  This includes but is not limited to           *
 * warranties of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.*
 *                                                                   *
 * <jb.bee250@gmail.com> <Christopher Posten>                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "../Factory/fTable.h"  //this will get the job done A+

    //#include "class.h" //concrete class with strategic destructor
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**||               COMPLEX OBJECT (COMPLEX C)            || *
     *                                                           *
     * ||                 by Willy (03/30/2022)               || */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                       complex object                      */
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief   complex type.                                    *
     *                                                           *
     * components:    [class]/[function]/[info]/[factory]        *
     *                                                           *
     *     - info                                                *
     *                                                           *
     *     - class                                               *
     *                                                           *
     *     - function                                            *
     *                                                           *
     *     - complex (the constructor)                           *
     *                                                           *
     * construction:  [Polymorph]/[Interface]/[Namespace]        *
     *                                                           *
     *     - Polymorph                                           *
     *                                                           *
     *     - Interface (MethodsTable)                            *
     *                                                           *
     *     - Object                                              *
     *                                                           *
     *                                                           *
     *     - VolatileType                                        *
     *                                                           *
     *     - VolatileSearch                                      *
     *                                                           *
     *     - X                                                   *
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///




    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                          OBJECT
                 +-----------------------------------+
                 | - stack of base types             |
                 |                                   |
                 +-----------------------------------+
                 | - stack or improper array?        |
                 |                                   |
                 +                                   +
                 |                                   |
                 |                                   |
                 +-----------------------------------+




                               INTERFACE
                 +-----------------------------------+
                 | - stack of base types             |
                 |                                   |
                 +-----------------------------------+
                 | - always a proper array           |
                 |                                   |
                 +                                   +
                 |                                   |
                 |                                   |
                 +-----------------------------------+



     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* clipboard:

    - - so there needs to be a factory table class inside
        the ftable called the builder. its class interface heap
        will include a singleton table for a single non-virtual
        table object and will have to start with creating a
        runtime version of a virtual table object using a runtime
        table for each struct (Object + Interface) and (Polymorph)
        for handling multiple inheritance.

    - -


    - - to fully include everything non-object-oriented from the C
        library, there needs to be some more careful thought
        towards more combinations of types, using primitives, ...

    - - i figure that the class builder is the place to keep
        everything object oriented but hopefully i can still
        put every C library function inside a Strategy table
        thats a Library table



        typedef double   (*DFac)( double, ... );   X

        #if 0
        static Object * ClassBuilderFunction( Stack *, ... );

        explicit Object * ClassBuilderFunction( Stack * self, ... )
        {
                //one thing gets passed into a function

                //two things get passed into a function




        }
        #endif // 0

    - - there needs to be a case for every datatype by string id

        typedef ctorPtr  (*Func)( cstring );///factory("Class")(this, ...);

     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *                                                           *
     *  THIS CLASS BUILDER SEEMS TO BE ANOTHER REASON WHY ALL    *
     *                                                           *
     *  FUNCTIONS NEED TO BE IMPLEMENTED AS FACTORIES THAT MAKE  *
     *                                                           *
     *  A CONTROL CALL ON A STACK POINTER, I BELIEVE.            *
     *                                                           *
     *                                                           *
     *  THIS WILL BE A CASE THATS LIKE A CERTAIN CASE SOMEWHERE  *
     *                                                           *
     *  IM SURE, ... ITS LIKE THE CONCEPT OF HOW YOU typedef A   *
     *                                                           *
     *  DATATYPE THATS A POINTER TYPE OR TYPE USING A QUALIFIER  *
     *                                                           *
     *  BEFORE USING typename HERE. THIS HERE IS THE CASE OF WHERE
     *                                                           *
     *  YOU NEED TO typedef A FUNCTION DATATYPE BEFORE RETURNING *
     *                                                           *
     *  THAT DATATYPE FROM A FUNCTION FOR THAT FUNCTIONS         *
     *                                                           *
     *  DECLARATION PROTOTYPE.                                   *
     *                                                           *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */

    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**||               CLASS BUILDER (COMPLEX C)             || *
     *                                                           *
     * ||                 by Willy (03/30/2022)               || */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                       class builder                       */
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief   class builder (complex type).                    *
     *                                                           *
     * components:    []/[]/[]/[]                                *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     * construction:  [Construct]/[]/[]/[]                       *
     *                                                           *
     *     - Construct                                           *
     *                                                           *
     *     -                                                     *
     *                                                           *
     *     -                                                     *
     *                                                           *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*           class builder: typedefs for functions           */
    typedef Object * (*Fact)( Object *, ... );/// #1

    typedef Object * (*CFac)( const Object *, ... );

    typedef Object * (*Meth)( cstring );///#2

    typedef cstring()(*Type)(void);

    ///object-oriented function types (Factory C functions/methods)

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        /*     volatile search goes in factory table slot    */


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* clipboard:

    - - 00-99 (tower) implementation for each case of there being
        an amount of parameters getting passed into a function, as
        every time its a pointer getting passed i just decided,
        meaning the complex object will only work with other
        objects.

    - - the primitive as factory object typename will prove helpful
        for this case of there being only objects allowed in use
        within the complex objects data members.

    - -

     */
    /*

     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                                                           */

    /*                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*

        typename(Table)(ClassVirtualTable,Constructor,SizeT);
        typedef  Table (ClassVirtualTable,Constructor,SizeT)

        //complex = descriptions, indexes, offsets, lengths;



                                               Construct;
     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<library that defines Object-Oriented essentials in C (Complex C)> *
 *                                                                   *
 * Copyright (C) <2017 - 2022>  <Christopher Posten>                 *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <jb.bee250@gmail.com>.              *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
#endif // COMPLEX_H_INCLUDED

#endif // TRASHBIN_H_INCLUDED
#ifndef DEFINEBASICHASHTABLE_H_INCLUDED
#define DEFINEBASICHASHTABLE_H_INCLUDED

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    //#include "defineAbstractHashSet.h"

    #include "definePair.h"

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
                /**||                 C HASH TABLE MACRO                  || *
                 *                                                           *
                 * ||                      by Willy                       || */
                /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                                                  *
     * @brief x-macro for HashTable(Key, Value, Bits) minus the initializer needed for   *
     *        new(Class) and functions that encapsulate new(Class)                       *
     *                                                                                   *
     * @author willy                                                                     *
     *                                                                                   *
     * @version (2021 - 03 - 06)                                                         *
     *                                                                                   */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #define defineBasicHashTable(Key, Value, Bits, Components)\
    \
      /*define(BasicVector)(type, define(Iterator)(type)); */\
    \
        Components;\
    \
        defineAbstractHashSet(Key##Value##Pair, Bits, );/**...*/\
    \
        defineHashSetInitArray(Key##Value##Pair, Bits, (*self).base.array[ count ].key = 0;\
                                                       (*self).base.array[ count ].val = 0;\
        );\
        defineHashSetResize(Key##Value##Pair, Bits,    (*iter).key,\
    \
                                                       (*p).key,\
    \
                                                       (*p).key = (*iter).key;\
                                                       (*p).val = (*iter).val;,/*(pointer assign)*/\
    \
                                                       (*p).key == (*iter).key\
        );\
        defineHashSetAdd(Key##Value##Pair, Bits,       (*p).key,\
    \
                                                       (*p).key = info.key;\
                                                       (*p).val = info.val;,/*(assign)*/\
    \
                                                       (*p).key == info.key\
        );\
        defineHashSetRemove(Key##Value##Pair, Bits,    (*p).key,\
    \
                                                       (*p).key = 0;\
                                                       (*p).val = 0;\
        );\
    \
        defineHashSetQProbe(Key##Value##Pair, Bits,    info.key,\
    \
                                                       self->base.array[probe].key == 0,\
    \
                                                       self->base.array[probe].key == info.key,\
    \
                                                       info.val != 0,\
    \
                                                       info.val == 0,\
    \
                                                       (*slot) = self->base.array[probe];\
                                                       self->base.array[probe].key = 0;\
                                                       self->base.array[probe].val = 0;,\
    \
                                                       /**defineHashSetQProbePrint*/; \
    \
        );

    #define defineHashSetQProbePrint \
    \
                    if( Prints[4] )\
                    {\
                        printf("\nprobe return: %u", probe);\
    \
                        ifOutOfBounds( maxsize, probe, printf(" (OutOfBounds)") );\
    \
                        printf("\nfound: %s\n", ( found ? "true" : "false" ) );\
    \
                        if ( found ) {\
    \
                            printf("(coming out)\ntypeid: %s\n",\
    \
                                   self->base.array[ probe ].val->what()  ); }\
                        else\
    \
                        if ( info.val != 0 ) {\
    \
                            printf("(going in)\ntypeid: %s\n",  info.val->what()  );\
                    } }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #define HashTable(Key, Value, Bits)   Key##Value##PairHashSet##Bits

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
            /* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */
            /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
             * <library that defines void-Oriented essentials in C (Factory C)>  *
             *                                                                   *
             * Copyright (C) <2017 - 2022>  <Christopher Posten>                 *
             *                                                                   *
             * This program is free software: you can redistribute it and/or     *
             * modify it under the terms of the GNU General Public License       *
             * as published by the Free Software Foundation, either version 3    *
             * of the License, or any later version.                             *
             *                                                                   *
             * This program is distributed in the hope that it will be useful,   *
             * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
             * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
             * GNU General Public License for more details.                      *
             *                                                                   *
             * You should have received a copy of the GNU General Public         *
             * License along with this program.  If not, see:                    *
             * <https://www.gnu.org/licenses/>.                                  *
             * Also: <https://www.fsf.org>. (Free Software Foundation).          *
             *                                                                   *
             * The author may be reached at: <jb.bee250@gmail.com>.              *
             * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
            /* DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED DISCLAIMED */


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        CENTRAL; ACCESS; POINTER;     CENTRAL; ACCESS; POINTER;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

         volatile static struct fTable * volatile ftable = 0 ;

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        CENTRAL; ACCESS; POINTER;     CENTRAL; ACCESS; POINTER;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


        #if 0 // 1 for use
        #define vObj(object, type)     ((type *)((class**) obj)[1])
    #endif                      //looks right but not tested (vObj)
    ///vArr(object, type)[0]

    ///enum eObj { func = 0, var = 1, ptr = 2 };

    ///vObj(object, type)[func](...)

    ///vObj(object, type)[var] = 123


        /**
         * INITIALIZE THE cstring volatiletype TO WHAT DESCRIPTION
         *
         * YOU WANT BEFORE USING
         */
        /*static struct class(CompareTable)

              type_info = { &VolatileType, &equal, &greater };*/





            {
                int a = 0;

                if(true)
                {
                    a = 1;

                    int b = 1;
                }

                a= 2;

                {
                    int b = 2;
                }
            }



        explicit cstring    toString( const Object * self )///   (19)
        {/*
            bool  = false;

            if( Exception ){ Exception = false;  = true; }


            Object * * func = function(self, "toString");


            if(    ){ Exception = true; }

            if ( objt )
            {
                return ((cstring()(*)(const Object*))(*func))(this);
            }
            else
            {
                return typeid(self);
            }

        */ return "TEMP"; }



            /**DONT FORGET THAT THERE IS A DENT IN THE GLOBAL OVERLOAD FUNCTION
               NAMESPACE remove() FUNCTION SO: _remove() SINCE C USES remove()
               FOR REMOVING A FILE OR SOMETHING (SO IT IS IMPORTANT)(THE LIBRARY
               FUNCTION) OTHERWISE, EVERY METHOD NAME IN THE FactoryObject(FactoryTable)
               IS ALSO THE NAME OF THE GLOBAL OVERLOAD FUNCTION BY THAT NAME
             */
            //if(         !_remove( obj, 6 )      ){ printf("remove failed\n"); }



 IT IS    *
     *                                                           *
     *  NOT ANYTHING TOO IMPORTANT ITSELF(LIKE THE ctor FUNCTION)*
     *                                                           *
     *  BUT THERE WAS ROOM FOR IT AND IT IS AKIN TO what(object) *
     *                                                           *
     *  EVEN THOUGH what(object) WAS ALWAYS THERE IF THERE WAS   *
     *                                                           *
     *  A VIRTUAL TABLE THERE, SO ITS NOT A C CENTRAL OVERLOAD   *
     *                                                           *
     *  FUNCTION ITSELF. init() IS NOT AKIN TO ctor(object, ...) *
     *                                                           *
     *  OR dtor(object) BUT ITS AKIN TO destroy() FROM vTable.h  *


    # define classTemplateTable(Member)classTemplateTable ## Member
    static cstring class    (TemplateTable)(Type)(void);  ///#14
    typedef struct class    (TemplateTable) /*INFO HEAP TABLE*/
    {   /// /// /// ///     ()
        typePtr type;//[0]   //
        /// /// /// ///
        methPtr find;//[1]   //
        /// /// /// ///
        tblePtr list;//[2]   //
        /// /// /// ///
    }class      (TemplateTable);
  explicit/*FACTORY TABLE CLASS SUB FACTORY METHOD TABLE*////#
    cstring class(TemplateTable)(Type)(void)
    { return "class(TemplateTable)"; }



        typename   (Pair)(Name, Case);
        typedef     Pair (Name, Case)             Builder;/*unused*/





      enum Defaults { control, _factory, command,   strategy,

                      boolean, template, terminate, initial };

     *  note: uses vtable->add() to allocate extra memory        *
     &        after destructor for an array/object that          &
     *        stores the destructor inside it or objects         *
     &        without structure implementations.                 &

    int a;



    static Object * FactoryTable(Complex)(Fact)(void) ;

    explicit Constructor FactoryTable(Complex)(Fact)(void)

    {
        size_type           object;      // =

        Class(VirtualTable) interface;   // =

        Constructor         construct;   // =


        return VirtualTable(Interface).insert(

            vtable, vstk, allocate(sizeof(object)),

            interface, construct );
    }


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief i cant remember what this was for                                     *
     *                                                                              *
     *                                                                              *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void f32()
    {

        printVirtualTable();

        //printFactoryTable();

        size_t i = (uint32_t) pow(1, 2);

        for( int x = 0; x < 10; x++ )
        {

            printf("x: %u\t\t\tq: %u\n", x, (uint32_t) pow(x, 2) );
        }



        printf("i: %u", i);
    }
    ///#define templ(...)    ( a, function() )
    /**
    //dont forget to make it the responsibility of both the vtable and

    //ftable and even the vstk to have implementations of print functions

    //that iterate through everything and show things like distribution

    //like f14() or whichever one it was that was vtable testing

    //so u can also have a qProbe that "pings" back and forth maybe

    //even multiple times,...  a ping variable could be cool that would

    //be used to determine the amount of pings back and forth


    */



        static bool ;

            ///str->toString(str);

        String _str;///not an Object (automatic struct variable)

        if( !String(Init)(&_str, 2, "myString") ){  }//automatic memory initializer

                                                                                    //CWP
    #endif // DEFINEBASICHASHTABLE_H_INCLUDED//CWP

    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    /**                                                          *
     * @brief  functions table registration                      *
     *                                                           *
     *                                                           *
     * @param  cstring key                                       *
     *                                                           *
     *                                                           *
     * @return Object *                                          *
     *                                                           */\
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    \
        static Object * Vector(type)SearchFunctions( cstring );\
    \
        static Strategy \
    \
            Vector(type)FunctionsTable[seventeen] =\
        {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z*/\
          { "Vector(" #type ")(At)",           &Vector(type)At         },\
          { "Vector(" #type ")(Back)",         &Vector(type)Back       },\
          { "Vector(" #type ")(Begin)",        &Vector(type)Begin      },\
          { "Vector(" #type ")(Clear)",        &Vector(type)Clear      },\
          { "Vector(" #type ")(Copy)",         &Vector(type)Copy       },\
          { "Vector(" #type ")(Dtor)",         &Vector(type)Dtor       },\
          { "Vector(" #type ")(End)",          &Vector(type)End        },\
          { "Vector(" #type ")(Front)",        &Vector(type)Front      },\
          { "Vector(" #type ")(Init)",         &Vector(type)Init       },\
          { "Vector(" #type ")(Insert)",       &Vector(type)Insert     },\
          { "Vector(" #type ")(Max)",          &Vector(type)Max        },\
          { "Vector(" #type ")(Remove)",       &Vector(type)Remove     },\
          { "Vector(" #type ")(Replace)",      &Vector(type)Replace    },\
          { "Vector(" #type ")(Resize)",       &Vector(type)Resize     },\
          { "Vector(" #type ")(Size)",         &Vector(type)Size       },\
          { "Vector(" #type ")(Type)",         &Vector(type)Type       },\
          { "get" #type "ptr",                 (&get##type##ptr)       },\
          { "", 0 }\
        };\
    \
    \
        explicit Object * Vector(type)SearchFunctions( cstring key )\
        {\
            Strategy pair = { key, 0 },\
                   * p;\
            size_t   i;\
    \
            p = StrategySearch( Vector(type)FunctionsTable,\
                                pair, &i, 0, 16 );\
    \
            if( p ){ return p->val; } else { return 0; }\
        }\
    \
    \
        static struct class (StrategyTable)\
    \
            Vector(type)Functions = \
    \
        {\
            &classFunctionsTableType,\
    \
            &Vector(type)SearchFunctions,\
    \
             Vector(type)FunctionsTable \
        };\
    \
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    /**                                                          *
     * @brief  builder table registration                        *
     *                                                           *
     *                                                           *
     * @param  cstring key                                       *
     *                                                           *
     *                                                           *
     * @return Object *                                          *
     *                                                           */\
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/\
    \
        static Object * Vector(type)SearchBuilder( cstring );\
    \
        static Builder\
    \
            Vector(type)BuilderTable[seventeen] = \
    \
        {/**A B C D E F G H I J K L M N O P Q R S T U V W X Y Z*/\
    \
{ "Iterator * (*begin)( const Container * );",                 "CFac" },\
{ "Iterator * (*end)( const Vector(" #type ") * );",           "CFac" },\
{ "Object * (*at)( const Container *, ... );",                 "CFac" },\
{ "SizeType (*size)( const Container * );",                    "CFac" },\
{ "Vector(" #type ") * (*init)( Vector(" #type ") *, ... );",  "Fact" },\
{ "bool (*clear)( Vector(" #type ") * );",                     "Fact" },\
{ "bool (*copy)( Container *, const Container * );",           "Fact" },\
{ "bool (*insert)( Container *, ... );",                       "Fact" },\
{ "bool (*remove)( Container *, ... );",                       "Fact" },\
{ "bool (*replace)( Vector(" #type ") *, size_type, type );",  "Fact" },\
{ "bool (*resize)( Vector(" #type ") *, size_type );",         "Fact" },\
{ "cstring (*what)(void);",                                    "Type" },\
{ "size_type (*max)( const Vector(" #type ") * );",            "CFac" },\
{ "type * (*front)( Vector(" #type ") * );",                   "Fact" },\
{ "type * (*back)( Vector(" #type ") * );",                    "Fact" },\
{ "void (*dtor)( Vector(" #type ") * );",                      "Fact" },\
{ "void * (*getptr)( Vector(" #type ") * );",                  "Fact" },\
    \
          { "", "" }\
        };\
    \
    \
        explicit Object * Vector(type)SearchBuilder( cstring key )\
        {\
            Builder pair = { key, 0 }, /*SINGLE SLOT*/\
                   * p;\
            size_t   i;\
                                              /*TABLE LENGTH STORED HERE*/\
            p = BuilderSearch( Vector(type)BuilderTable, pair, &i, 0, 16 );\
    \
            if( p ){ return p->val; } else { return 0; }\
        }\
    \
    \
        static struct class(BuilderTable)\
    \
            Vector(type)Builder = \
    \
        {\
            &classBuilderTableType,\
    \
            &Vector(type)SearchBuilder,\
    \
             Vector(type)BuilderTable \
        };\
    \


    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *  OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD  *
     *                      possibilities                        *
     * - - since a vector can be placed inside a vector          *
     *     it might be too much to initialize pointers to        *
     *     an interface for each object and instead have a       *
     *     pointer inside struct Vector(type) named functions    *
     *     that points to a singleton object of a structure that *
     *     keeps an initialized interface. strategy will be      *
     *     limited with functions or strategic functions that    *
     *     each object will have unique implementations for will *
     *     still be stored inside struct Vector(type) - -        *
     *                                                           *
     *   therefore a static list of pointers would be allocated  *
     *   for a static interface (assuming thats the same as C++) *
     *                                                           *
     * - - so:                                                   *
     *                                                           *
     *       struct type##VectorFunctions;                       *
     *                                                           *
     *       typedef struct type##Vector                         *
     *       {     Container base;                               *
     *                                                           *
     *           //... length, maxsize and function pointers     *
     *           // of strategic significance                    *
     *                                                           *
     *           type##VectorFunctions * functions;              *
     *                                                           *
     *                                                           *
     *       }Vector(type);                                      *
     *                                                           *
     *       typedef struct type##VectorFunctions                *
     *       {                                                   *
     *           //... main interface of pointers                *
     *                                                           *
     *           //... static class variables                    *
     *                                                           *
     *           //this will limit the amount of pointers        *
     *           //to one full set per vector type as            *
     *           //a Container of a set of elements              *
     *           //or a specified datatype                       *
     *                                                           *
     *       }type##VectorFunctions;                             *
     *                                                           *
     *       type##VectorFunctions func = { ... }; //singleton   *
     *                                                           *
     *       //inside the initializer:                           *
     *                                                           *
     *               self->functions = &func;                    *
     *                                                           *
     *                                                           *
     *                                                           *
     *                                                           *
     *   #define [type]Iterator(Member) [type]Iterator##Member   *
     *                                                           *
     *  OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD  *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



    # define classBasicsTable(Member)classBasicsTable ## Member
    static cstring class    (BasicsTable)(Type)(void);    ///#12
    typedef struct class    (BasicsTable)   /*INFO HEAP TABLE*/
    {   /// /// /// ///     ()
        typePtr type;//[0]   //
        /// /// /// ///
        methPtr find;//[1]   //
        /// /// /// ///
        tblePtr list;//[2]   //
        /// /// /// ///
    }class      (BasicsTable);  ///StrategyTable
  explicit/*FACTORY TABLE CLASS SUB FACTORY METHOD TABLE*////#
    cstring class(BasicsTable)(Type)(void)
    { return "class(BasicsTable)"; }



    # define classLibraryTable(Member)classLibraryTable ## Member
    static cstring class    (LibraryTable)(Type)(void);   ///#13
    typedef struct class    (LibraryTable)  /*INFO HEAP TABLE*/
    {   /// /// /// ///     (String, File, ...)
        typePtr type;//[0]   //
        /// /// /// ///
        methPtr find;//[1]   //
        /// /// /// ///
        tblePtr list;//[2]   //
        /// /// /// ///
    }class      (LibraryTable); ///StrategyTable
  explicit/*FACTORY TABLE CLASS SUB FACTORY METHOD TABLE*////#
    cstring class(LibraryTable)(Type)(void)
    { return "class(LibraryTable)"; }


    \
    /*\
        static type##VirtualTable * type##Virt( type * );\
    \
        volatile struct type##Helper\
        {   Helper base;\
    \
            type * self;\
    \
            type##VirtualTable * (*virt)( type * );\
    \
            ctorPtr (*fact)(void);\
    \
        }volatile type##Helper = \
            {{},nullptr,&type##Virt,&type##Fact};\
    \
    \
        explicit type##VirtualTable * type##Virt( type * self )\
        { return virtual( self, type ); }\
    \
    \
        static struct type##Helper * type##GetHelper();\
    \
        static struct type##Helper * (*type##InitHelper\
                                     (type * self))(void);\
    \
    \
        explicit struct type##Helper * type##GetHelper()\
        { return & type##Helper; }\
    \
        explicit struct type##Helper * (*type##InitHelper\
                                       (type * self))(void)\
        { type##Helper.self = self; return & type##GetHelper; }\
    */\
       \
        \
        /**
         * @brief c string class factory method (Factory C)(OOC)(C+)
         *//*  Class(FactoryMethod)  */\
        static class(FactoryMethod) /**THIS STRUCTURE IS EXTENDIBLE**/\
    \
            type(Method) = \
    \
        { &type(Search) };/**CLASS FACTORY METHOD**/\
    \
    \
        static void typename(Setup)(type) {}



            if( virtual( self, class ) )
            {
                Object * * objt = &( (Object * *)
                  virtual( this, class ) )[ p->val ] ;
                return objt; /// +this
            }
            else
            {
                if(Exception){ throw( new(Exception) )
                  (this, "NullInterface"); } else { return 0; }
            } }


     *
     * @throw
     *
     * @throw
     *
     * @throw
     *
     * @throw
     *
     * @throw
     *

    /* (using.h)
        - - there is room for BooleanTables here in the
            control factory when a boolean statement returns
            onto a stack as a 1 or 0

        - - the case involved when its a constructor called
            during the factory control sequence requires that
            new(Class) gets passed into the function call at
            the constructor slot in the factory control sequence
            so there will then be a comparison that evaluates to
            true when the constructor returned by new(Class)
            is compared to the constructor at its factory slot.
            when this occurs, a terminate sequence  is raised
            and the very next factory function in the factory
            control sequence returns memory for an object NOT
            another factory in sequence

        - - if you want the new object to get loaded onto a return
            stack instead, then don't pass new(Class) or one
            of its substitutes into the factory at the same
            sequence point as the command slot that has the
            constructor in it. (think of something else)

        - - that (something else) would be to use new() by itself
            first a bunch of times so the virtual table's stack
            gets filled up then invoke this as Type represents
            the stack there (this)

        - - don't forget to set up a loop cycle using setJump()
            and longJump()  A.K.A.  jump()  and   set()  so
            you can use indirect recursion to substitute for
            loops here... *update* the loops cant be that way
            but the factory sequence relies on the setJump
            thats set by the try{} block since when a function
            returns then the setJump set inside that function
            becomes invalid. so a set jump cant be set in one
            function to go to the next, but the result is just
            as satisfying just as long as there is proper ging
            as to whether to branch over certain blocks of code
            or not.

        - - the array handed to the command center has to be
            of the type: Pair(Function, ReturnStack)

                     thats also typedef(d) as:     Factory
                     to go beside:                 Command
                     (so either)

        - - consider the Skip-- to work in a way that if u set
            Skip to 5 then it would skip 5 functions...

        - - when the Factory is raised the control sequence is
            for a Factory array, when its lowered its for a Command
            array

        - - when the Command is raised it is for the iterator
            to stay parked in Factory mode like the iterator is always
            parked in Command mode (when the Factory is lowered)

        - - consider that virtual(obj, class) should throw an
            exception maybe considering its use here in this file
            or consider that maybe there should be at least an
            Insert pointer that gets declared and initialized if
            not an interface and an Insert pointer (then thats too
            much to me) so there would be a check for null there.

        - - ///         (*abort)(  )   (in struct bunker vtable)

        - - ///         (*destroy)(  )

        - - i cant remember Type it was but i am sure there was a case
            where i needed to add a  or re-use an existing one
            that would be used for the the case when the template method
            that gets called using the template



        - - Stack and Array become files

        - - go through comments in Object.h and structclass.h

        - - implement namespace("Set", "Case")

        - - implement complex.h

        - - check double return thru pointer type from function

        - - implement typename for FactoryPrimitive & FactoryArray

        - -

        - - email programming instructors at end-of-semester

     */

    #define     namespace(Set, Case)     NamespaceControl(Set, Case)
    static StackControl * ControlFactory(NameSpace)(Set, Case);

    except explicit StackControl * ControlFactory(NameSpace)

        ( Set setName, Case caseName )

    {/* Class(FactoryMethod) list = FactoryTable(Interface)
        .map(ftable, setName);

      if( !list ){ throw( new(NullPointer) )
          (this, "NotAFactoryTableClass"); }

      Object * pos = list->search("classTemplateTable");




    */}
    explicit void aTable(Init)(void)
        {VirtualTable(Allocator)(&vtable,default_prime);
         AdapterTable(Allocator)(&atable,default_prime / 4);}

    explicit void aTable(Destroy)(void)
        {VirtualTable(Deallocator)(&vtable);
         AdapterTable(Deallocator)(&atable);}

         /*
    #undef  addAdapter //(adapter, object)
    #define addAdapter(adapter, object)\
    \
        AdapterTable(Interface).insert( atable, astk, adapter, object )

    #undef  getAdapter //
    #define getAdapter(adapter)\
    \
        AdapterTable(Interface).search( atable, astk, adapter )

    #undef  remAdapter //
    #define remAdapter(adapter)\
    \
        AdapterTable(Interface).remove( atable, astk, adapter )

    #include "Adaptable.h"

    #include "../Adapter/Observable.h"
    */
    #if 0
        atable->insert(adapter, object)

        atable->search(adapter)

        atable->remove(adapter)
    #endif // 0
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
  #if 0
    #undef  addObserver //(observer, object)
    #define addObserver(observer, object)\
    \
        AdapterTable(Interface).insert( otable, astk, observer, object )

    #undef  getObserver //
    #define getObserver(observer)\
    \
        AdapterTable(Interface).search( otable, astk, observer )

    #undef  remObserver //
    #define remObserver(observer)\
    \
        AdapterTable(Interface).remove( otable, astk, observer )
  #endif // 0

      /*
    static AdapterTable(FactoryTable)

        AdapterTable(Factory) =

    { { &class(FactoryTableType), &AdapterTable(Fact), 0 } };


    static Interface AdapterTable(InterfaceHeap)[one] =

    { &AdapterTable(Factory), nullptr } ;


    static Interface typename(ClassFactoryMethod)(AdapterTable,0,0);


    static class(FactoryMethod)

        AdapterTable(Method) =

    { & AdapterTable(Search) };


    static void typename(Setup)(AdapterTable) {}
    */
    // /// /// /// /// /// /// /// /// /// /// /// /// /// /// ////
    //---------------------------------------------------------+ //
    explicit class * class(Init)( class * self, ... )           //|
    { if( !self ){ return 0; }                                  //|
      Stack * stack = control();                                //|
                                                                //|
      size_t c = arg(stack, size_t);                            //|
      switch(c)                                                 //|
      {                                                         //|
        case 0:                                                 //|
            self->dtor = 0; //null                              //|
        break;                                                  //|
        case 1:                                                 //|
            self->dtor = arg(stack, size_t);//                  //|
        break;                                                  //|
        case 2:                //re-constructor//               //|
            self->dtor = 0;   //              //                //|
                                                                //|
            c = arg(stack, size_t);                             //|
                             //  //.remove   //                 //|
            VirtualTable(Interface).remove(vtable, vstk, self); //|
                                 //.add(with extra bytes)       //|
            VirtualTable(Interface).insert(vtable, vstk,        //|
                                                                //|
                allocate( sizeof(class) + arg(stack, size_t) ), //|
                                                                //|
                & class(Interface), 0 );/* (*/self = this;/*) *///|
                                                                //|
            if( !self ){ return 0; }                            //|
                                                                //|
            ((class*)self)->dtor = c       ;                    //|
        break;                                                  //|
      }                                                         //|
        return self; }                                          //|
                                                                //|
    explicit void class(Dtor)( class * self )                   //|
    { if(self->dtor)                                            //|
      { self->dtor( self ); } }                                 //|
    //---------------------------------------------------------+//|
    // /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///|



            ///       multidex(typeid(obj))("...")("...") ;

            ///       map(typeid(obj))("...") ;

            //        multimap(true)(typeid(obj))("...")("...") ;

            //        multimap(false)(typeid(obj))("...") ;

        /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        typename   (Table)(Case,Pos,Stamp);    ///Template
        typedef     Table (Case,Pos,Stamp)        Namespace;

        typedef     Namespace * NamespaceArray;
        typename   (Object)    (NamespaceArray);


        typename   (Table)(int,int,int);
        typedef     Table (int,int,int)

                                                  Complex;

        typedef     Complex * Construct;
                                               ///Complex
  #if 0  #if 0
void IOStream(End)(void){CIStream(Destroy)(&cin);COStream(Destroy)(&cout);}
  #endif // 0
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

   void IOStream(Begin)(void){CIStream(New)(&cin);COStream(New)(&cout);}
  #endif // 0
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    volatile typename(Pair)(ClassName,Construct);

    volatile typename(Iterator)(ClassNameConstructPair);

    volatile typename(Vector)(ClassNameConstructPair,);

    volatile typename(StringHashTable)(ClassName,Construct,);




            new(Exception) exception (this, "InputMismatch");

        new(InputMismatch) exception (this, "text...");

        printf("type:\t\t %s\n", typeid(*vTop()));
        printf("time:\t\t %s\n", ((Exception*)*vTop())->time);
        printf("date:\t\t %s\n", ((Exception*)*vTop())->date);
        printf("line:\t\t %d\n", ((Exception*)*vTop())->line);
        printf("file:\t\t %s\n", ((Exception*)*vTop())->file);
        printf("text:\t\t %s\n", ((Exception*)*vTop())->text);
        printf("\n");

        if( !vPop() ) {  }

        if( !vPop() ){ new(Exception) exception (this, "pop returns false"); }

        if( !vPop() ){ new(Exception) exception (this, "pop returns false"); }

        printf("type:\t\t %s\n", typeid(*vTop()));
        printf("time:\t\t %s\n", ((Exception*)*vTop())->time);
        printf("date:\t\t %s\n", ((Exception*)*vTop())->date);
        printf("line:\t\t %d\n", ((Exception*)*vTop())->line);
        printf("file:\t\t %s\n", ((Exception*)*vTop())->file);
        printf("text:\t\t %s\n", ((Exception*)*vTop())->text);
        printf("\n");

        if( !vPop() ){ new(Exception) exception (this, "pop returns false"); }

        if( !vPop() ){ new(Exception) exception (this, "pop returns false"); }

        printf("type:\t\t %s\n", typeid(*vTop()));
        printf("time:\t\t %s\n", ((Exception*)*vTop())->time);
        printf("date:\t\t %s\n", ((Exception*)*vTop())->date);
        printf("line:\t\t %d\n", ((Exception*)*vTop())->line);
        printf("file:\t\t %s\n", ((Exception*)*vTop())->file);
        printf("text:\t\t %s\n", ((Exception*)*vTop())->text);
        printf("\n");


    volatile static bool aStack = false;

    { if( !aStack )
      {
        aStack = true;

        while( aTop() ){ aPop(); }
      }

      {
        if( adpt == 0 )
        { return false; }

        aPush(adpt);

          Pair( Adapter, Class ) pair = { object, 0 };
          Pair( Adapter, Class ) * p =
            ((HashTable(Adapter,Class,VirtualTable)(32)*)
            &AdapterTable(Interface))->search(self, pair);
            if( p == 0 )
            { return false; }
              else

              if( (*p).key == adpt )
              { (*p).key = 0; (*p).val = 0; ///
              ((Vector(AdapterClassPair)*)self)->length--;

                aPop();

              if( !aTop() ){

    AdapterClassPairQuadraticProbe32ResizeHelper( self );

                aStack = false; }

              return true; } } }


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief small space to work outwards from here includes static initializers   *
     *        but nothing successful                                                *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void f37()
    {
        FactoryArray * array = new(FactoryArray)(this, allocate(sizeof(Factory) * 10));


        Controller = (*array);

        Factory pair = { &f37, 0 };

        //setFactorySlot( pair );


    }
                 /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**               add new destructor to vtable               */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static struct class * classDestroy(struct class * self);
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /**********************************************************************
     *                add new destructor to vtable                        *
     **********************************************************************/
    explicit void f07()
    {
    /**
        class* d1 = new(class)(this, 0); //small factory constructor

        class* d2 = new(class)(this, 1, &classDestroy);


        if(d1 == nullptr || d2 == nullptr) {return;}


        printf("0x%x\n0x%x\n", d1->dtor, d2->dtor);


        delete(d1);//check return for 1 or 0 for successful removal
                  //from vtable

        delete(d2);//along with this being 0
    */
    }
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    static struct class * classDestroy(struct class *);

    explicit struct class * classDestroy(struct class * self)
    {

        ///- - destroy global array? - -

        puts("destructor called");
    }

    /*
     * test function for making a control call/case
     *
     * (small space to work outwards from again)
     */
    static void controlTest(Object *, ...);

    explicit void controlTest(Object * self, ...)
    {
        Stack * stack = control();


        double d = arg(stack, double);

        double e = arg(stack, double);

        double f = arg(stack, double);


        printf("d: %.2f\ne: %.2f\nf: %.2f\n", d, e, f);

    }


                    #define tmplt(Set, Case)\
                    \
                        (((Case##Set*)Set##Array)[Case])

                  ///  #define template(Set, Case)\
               ///     \
                  ///      (((Case##Set*)(*Set##Array))[Case])

    /**********************************************************************
     *                  template(Set, Case) example                       *
     *                                                                    *
     **********************************************************************/
    explicit void f06()    //majority syntax experiment
    {
        Hospital * h = new(Hospital)(this);

        template(Emergency, Yellow)(h, 0)(h, 1);///call yellow then red

        Emergency(Yellow) p1 = template(Emergency, Green)(h, 0);

        Emergency(Red) p2 = p1(h,0,"a b c",'0');
                    //use an array of void * with an enumeration

                    //and the template(Set, Case) array front-end
        p2(0);//red
                    //this could be used for an object without
        delete(h);
    }               //class definition
        // first 4 should return 0 once WeatherStationDtor is
        // FULLY implemented
    /*
        if( !delete(c) ) {printf("\n0\n");}else{printf("\n1\n");}//1
        //usleep(1000000);
        if( !delete(f) ) {printf("\n0\n");}else{printf("\n1\n");}//2
        //usleep(1000000);
        if( !delete(h) ) {printf("\n0\n");}else{printf("\n1\n");}//3
        //usleep(1000000);
        if( !delete(s) ) {printf("\n0\n");}else{printf("\n1\n");}//4
        //usleep(1000000);


        if( !delete(cd) ){printf("\n0\n");}else{printf("\n1\n");}
        //usleep(1000000);
        if( !delete(fd) ){printf("\n0\n");}else{printf("\n1\n");}
        //usleep(1000000);
        if( !delete(hd) ){printf("\n0\n");}else{printf("\n1\n");}
        //usleep(1000000);
        if( !delete(sd) ){printf("\n0\n");}else{printf("\n1\n");}
        //usleep(1000000);
    */

        //printVirtualTable();
                //obvious re-delete
        //if( !delete(sd) ){printf("\n0\n");}else{printf("\n1\n");}//0 always

        //destroy();//no more vtable, ... new(), delete(), virtual(), typeid() (pack it in)
        //init();///101

    //void throwException()

    #define _throwException()\
    /*{*/\
        throw ( new(Exception) )(this, "...");\
    /*}*/


    void * (*fPtr)(void *, ...);

        /*        from defineObject.h       */

    static void func2(void *);

    explicit void func2(void * self){printf("0");}

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief small space to work outwards from here includes ignoring returns      *
     *        and having an inactive cast to calling a function that returns        *
     *        void from a pointer to a function that returns a void * and           *
     *        attempting to return with the function                                *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void f35()
    {
        fPtr = & func2;


        //(Class) func(0);


        if( 0 )
        {
            (Class) fPtr(0);
        }
        else
        {
            size_t x = fPtr(0);
        }

    }

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                                       *
     *                                                                              *
     *                                                                              *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void f39()
    {
        Object * self = 0;

        controlTest(self, .99, .89, .79);
    }
//this includes a destructor call and vtable->remove

        ////////////////////////////////////
           #define charcopy charCopy
           #define charresize charResize
           #define char(f) char##f
        ////////////////////////////////////

    //define(Copy)(char);


    macros();  macros(a, b, c, f, d, e, f, g);

    asm("  ");
    /**

                if(!self){return;}\
        \
                Object * node = self;\
        \
                delete(self);\
        \
                if( getDecorator(self) )\
                {\
                    virtual (getDecorator(self), class)->dtor(self);\
                }\

                Object * node = self;
                while( node )
                {
                    self = getDecorator(self);

                    delete(node);

                    node = self;
                }



        Beverage * node;

        while( darkRoast )
        {
            node = darkRoast;

            printBeverageDescription(node->description);

            darkRoast = getDecorator(darkRoast);

            delete( node );
        }

        while( beverage )
        {
            node = beverage;

            printBeverageDescription(node->description);

            beverage = getDecorator(beverage);

            delete( node );
        }


    Pair(Class, ClassVirtualTable) parray[10];///desperately needs
        ///a static initializer as global automatic array

    static void fInit( Pair(Class, ClassVirtualTable) );

    explicit void fInit( Pair(Class, ClassVirtualTable) pair )///OO style initializer
    {                   ///not for automatic array as much, look for typename(Object)(...)
        size_t i;     ///later in this file

        for(i = 0; i < 10; i++)
        {
            parray[i] = pair;
        }
    }

        //char(VectorInsert)(...);   yes
        ///char(vector)(insert)();   no,
        ///## cannot appear at either end of macro expansion
    /*
    typedef unsigned int Unsigned;  //valid token

    #undef size_type
    #define size_type size_t
    defineHashSet(Unsigned, 32);
    */

        Pair(Class, ClassVirtualTable) pair = {0, 0}, //struct initializer

        pair2 = pair; //structured datatype assign      STRUCT ASSIGN


        printf("0x%x\n", &pair);

        printf("0x%x\n", &pair2);

        printf("%d\n", pair.key);

        printf("%d\n", pair.val);

        printf("%d\n", pair2.key);

        printf("%d\n", pair2.val);




            {"_hash",            &_hash},
            {"_hash32",          &_hash32},
            {"_hash64",          &_hash64},
            {"_hash_string",     &_hash_string},
    */

    #define macro_name    ...   ...


    #define macro_name()  ...   ...


    asm("  ");


    static double _dfunc();

    explicit double _dfunc(){ double d = 23456.45678; return d; }

    void * (*_dp)() = &_dfunc;

    @brief Composite map/multimap (dex)

        ((void)0) ;

        unsigned long int i;

        for(i = 0; i < ((Vector(ClassClassVirtualTablePair)*)vtable)->maxsize; i++)
                                                          //997 default
        {
            printf("0x%x\t\t\t\t\t", ((Vector(ClassClassVirtualTablePair)*)vtable)

                ->array[i].key);

        }puts("\n\n");


    /**
        void type##Sort( type * array,\
            \
                    size_type left, size_type right )
     */


        ///static;  (not inside of a function semicolon or no) (defined or no)

    static uint64_t _ifunc();

    explicit uint64_t _ifunc(){ uint64_t i = 123456789; return i; }

    void * (*_ip)() = &_ifunc;



    static bool _bfunc();

    explicit bool _bfunc(){ bool b = true; return b; }

    void * (*_bp)() = &_bfunc;

            ///double d = (double)_dp();  ///(no go)

        ///printf("%.2f\n", d);


        uint64_t i = (uint64_t)_ip();///damages the number (integer)

        printf("%ull\n", i);


        bool b = (bool)_bp();

        printf("%u\n", b);
        /*

    static bool default(equal)( const Object *, const Object * );

    static bool default(greater)( const Object *, const Object * );


    explicit bool default(equal)

        ( const Object * self, const Object * objt ){ return true; }

    explicit bool default(greater)

        ( const Object * self, const Object * objt ){ return true; }


    static int default(cin)( Object *, ... );

    static int default(cout)( const Object *, ... );


    explicit int default(cin)

        ( Object * self, ... ){ return 0; }

    explicit int default(cout)

        ( const Object * self, ... ){ return 0; }
        */
    /**
        THIS IS FOR THE FILE FACTORY OBJECT AS THE FUNCTIONS CALLED ARE NOT CALLED

        FROM virtual BUT THEY ARE OF THE C CENTRAL OVERLOAD FUNCTIONS IMPLEMENTED

        IN FactoryObject.h  THEY ARE THE SAME AS OVERLOADED FUNCTIONS ELSEWHERE

        IF ANYTHING THEY ARE MORE POWERFUL. (FACTORY C) (02/14/2022) NOW ALL THERE

        IS TO DO IN THAT AREA IS USE THEM FROM THE CONTROL FACTORY, LIKE WHAT THEY

        ARE MEANT FOR BASED ON MY PERSONAL CHOICE OF AN IMPLEMENTATION FOR THEM.


        ALSO THE C CENTRAL OVERRIDE METHOD SHOULD GET A CHANCE TO BE TESTED NOW,

        AND HAVE ITS HELPER override METHOD IMPLEMENTED FOR SEARCHING EVERY FACTORY

        TABLE CLASS INTERFACE HEAP FOR A FUNCTION BY NAME "...".
     */


    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief provide centralized access thats runtime access    *
     *                                                           *
     * to important c functions and important factory c tables,  *
     *                                                           *
     * including the virtual table for loading new virtual tables*
     *                                                           *
     * into (one for each program loaded by the operating system *
     *                                                           *
     * user) and a side table for side programs/processes.       *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void f38(){}

    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     * @brief                                                                       *
     *                                                                              *
     *                                                                              *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
    explicit void f39()
    {

    }

    explicit void f40(){}

    explicit void f41(){}

    explicit void f42(){}

    explicit void f43(){}

    explicit void f44(){}

    explicit void f45(){}

    explicit void f46(){}

    explicit void f47(){}

    explicit void f48(){}

    explicit void f49(){}

    explicit void f50(){}



    explicit void f52()
    {}

    explicit void f53()
    {}

    explicit void f54()
    {}

    explicit void f55()
    {}

    explicit void f56()
    {}


  #if 0 ///(this is inactive)
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief  this was the other idea for class factory method  *
     ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
        #define defineFactoryMethod(\
        \
          Make, Class, Type, Name, First, Last)\
        \
          Class (Search) (cstring);\
        \
        explicit Object * Class (Search) (cstring reg)\
        \
          {\
              if( string(equal)( # Make, "Sub" ) )\
              {\
                return class(factory)(  );\
              }\
              else \
              if( string(equal)( # Make, "Class" ) )\
              {\
                return class(factory)(  );\
              }\
          }



            class (factory) (cstring);\
        \
          explicit Object * class(factory) (cstring reg)\
        \
          {
              if(  )

              {   Interface iterator[3]  =  { &Volatile(Type), 0, 0 };\
            \
                  fSizeType i;                 volatiletype = reg;\
            \
                  InterfaceHeap p  =  Search(Interface)(\
            \
                    Class (InterfaceHeap), iterator, & i, First, Last );\
            \
                  if ((p)) { return ((*p)) ; } else { return 0; }  }

              else

              if(  )
            \
              {   Object * slot[1]  =  { key } ;\
            \
                  fSizeType  i;\
            \
                  Type * p  =  Search(Type)(\
            \
                    Class##Type##Table, slot, & i, First, Last );\
            \
                  if ((p)) { return ((p)) ; } else { return 0; }  }

          }

  #endif // 1

    /*\
        if( !pJumpVal ) printf( "\nbool: %d\n", *((bool*)jTop()->val) );\
        if( pJumpVal ) printf( "bool: %d\n", *((bool*)pJumpVal) );\
    \
        if( !pJumpVal ){ printf("try"); }\
        if( pJumpVal ){ printf("catch"); }*/\



  #else
    #define try \
    \
        jump = false;\
    \
        pJumpVal = set( envBuffer );\
    \
        if( pJumpVal != 0 )  {}\
    \
        if( !jump )

  #endif // 1

    /**
        jump = setJump( envBuffer );\
    \
        if( !jump )
    */

  #else

    #define exception(self, text)\
    \
        (self, _line_, _file_, _time_, _date_, text);\
    \
            jump = true;\
    \
            jump( envBuffer, & jump )

  #endif // 1
    /**
        THIS MACRO COULD POSSIBLY HAVE SOME WORK PUT INTO IT TO

        MAKE IT DYNAMIC FOR OTHER TYPES OF OBJECT LIKE A Vector(type)

        WHEN USING A MACRO WITH AN ELLIPSIS OR ...
     */
    /**
        (self, _line_, _file_, _time_, _date_, text);\
    \
        longJump( envBuffer, true )
    */


        //if( e )

  #else

    #define catch( pointer )\
    \
        pointer = ( jump ? this : nullptr );\
    \
        if( jump )

  #endif // 1


    #define cScan  scanf(

    #define sScan  sscanf( (*ConsoleOut(Object)),

    #define fScan  fscanf( ConsoleOut(Object),


    #if 0

    static Type *
    typename(FactoryMethod)(Sub, Class, Type, Name, 0, 0);/// X (NO)

    #endif // 0


     explicit int FactoryTable(PrintStandard)(FactoryTable * self, char * str)

     { size_t i = 0, i2 = 0, i3 = 0, count = 0, colCount = 0, length;
         for(i2 = 0; i2 < ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->maxsize; i2++) //
        { if(((Vector(ClassNameClassFactoryMethodPair)*)
                self)->array[i2].key != nullptr)
            {count++; length = string(size)(((Vector
                    (ClassNameClassFactoryMethodPair)*)
                    self)->array[i2].key);
                sprintf(str, "\"%s\"", ((Vector
                    (ClassNameClassFactoryMethodPair)*)
                    self)->array[i2].key);
                for( size_t index = 0; index <= 30 - length - 2; index++ )
                { sprintf(str, " "); }
            }else{sprintf(str, "\"\"");
                for( size_t index = 0; index <= 30 - 3; index++ )
                { sprintf(str, " "); }
            } colCount++;
            if(colCount == 4){ sprintf(str, "\n"); colCount = 0; }
        }sprintf(str, "\n\n\n");
        for(i2 = 0; i2 < ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->maxsize; i2++) //
        { if(((Vector(ClassNameClassFactoryMethodPair)*)
                self)->array[i2].val != nullptr)
            {count++;sprintf(str, "%s\n", ((Vector
                    (ClassNameClassFactoryMethodPair)*)
                    self)->array[i2].key );
                colCount++;}
        }sprintf(str, "\n\n");
        sprintf(str, "maxsize:\t\t\t\t%d\n",
               ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->maxsize); //
        sprintf(str, "length:\t\t\t\t\t%d\n",
               ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->length);   //
        return 0;}


    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief             print vTable (file)                    *
     *      - - easy function to check what is allocated - -     *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit int VirtualTable(PrintFile)(VirtualTable * self, File * file)

     { fprintf(file, "\n");
         size_t i = 0, i2 = 0, i3 = 0, count = 0, colCount = 0;
         for(i2 = 0; i2 < ((Vector(ClassClassVirtualTablePair)*)
            self)->maxsize; i2++) //
        {if(((Vector(ClassClassVirtualTablePair)*)
                self)->array[i2].key != nullptr)
            {count++;fprintf(file, "0x%x\t\t", ((Vector
                    (ClassClassVirtualTablePair)*)
                    self)->array[i2].key);
            }else{fprintf(file, "0x0\t\t\t");
            }colCount++;
            if(colCount == 5){ fprintf(file, "\n"); colCount = 0; }
        }fprintf(file, "\n\n\n");
        for(i2 = 0; i2 < ((Vector(ClassClassVirtualTablePair)*)
            self)->maxsize; i2++) //
        {if(((Vector(ClassClassVirtualTablePair)*)
                self)->array[i2].val != nullptr)
            {count++;fprintf(file, "%s\n", ((classVirtualTable*)((Vector
                (ClassClassVirtualTablePair)*)self)->array[i2].val)->type() );
                colCount++;}
        }fprintf(file, "\n\n");
        ClassN * node = ((ClassStk*)vstk)->stktop;
        while(   node   )
        {fprintf(file, "Stack: 0x%x\n", node->info);
            node = node->link;
        }fprintf(file, "\n\n");
        fprintf(file, "maxsize:\t\t\t\t%u\n",
               ((Vector(ClassClassVirtualTablePair)*)
            self)->maxsize); //
        fprintf(file, "length:\t\t\t\t\t%u\n\n",
               ((Vector(ClassClassVirtualTablePair)*)
            self)->length);   //
        fprintf(file, "stack height:\t\t\t\t%u\n\n",
             ClassStkGetLength(  ((Stk(Class)*)vstk)->stktop  )   );
        return 0;}

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

#ifdef VIRTUALTABLESINGLETON

    #ifndef COMPLEX_H_INCLUDED
    #define COMPLEX_H_INCLUDED
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*** * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *       1) write an add function for the vtable             *
     *          to take memory from an object, init              *
     *          and return the constructor's pointer.            *
     *                                                           *
     *       2) use the constructor just to return               *
     *          (this replaces allocate(bytes)).                 *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
     * @brief                complex(bytes)                      *
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    # define complex(member)complex ## member

      static Object * complex(Init)(Object *);

      explicit Object * complex(Init)(Object * self){return self;}

    #undef complex()


    #define complex(bytes)(Object*)VirtualTable(Interface).insert(\
    \
        vtable, vstk, (Object*)allocate(bytes),\
    \
        & class(Interface), & complex(Init) ) (this)

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING;WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
    #if 0
                   Object * object = complex(bytes);
    #endif // 0
    /*/ /// /// /// /// /// /// /// /// /// /// /// /// /// /// /*/
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        WARNING;WARNING;      INCOMPLETE;       WARNING;WARNING;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    #endif // COMPLEX_H_INCLUDED
  #endif // VIRTUALTABLESINGLETON

  #if 0 // 1
    {try{
             if( self == vtable )
             { return ((factPtr*)multimap(false)("VirtualTable")
             ("class(ConsoleTable)"))[2](self); }

             if( self == ftable )
             { return ((factPtr*)multimap(false)("FactoryTable")
             ("class(ConsoleTable)"))[2](self); }

             if( self == atable )
             { return ((factPtr*)multimap(false)("AdapterTable")
             ("class(ConsoleTable)"))[2](self); }


        return ((factPtr*)multimap(false)(typeid(self))
            ("class(ConsoleTable)"))[2](self);
    /**
      for the day:

          i have discovered that there are two problems here

          (08/21/2022).


          vtable remove() cannot empty the stack, and the try

          needs to set a jump with a choice of jump variable.


          vtable remove() (delete) empties the stack and (this) throws

          an exception from the control factory, where it cannot

          be caught it seems since the set jump set a jump with

          the same variable it did in a function that returned and

          so is invalid. (like the original problem with the

          constructor) so even that it was throwing was deletes

          fault and this picks out a flaw in the control factory

          (and try/catch) and the 26 setjump variables either need

          to go or they could come in handy (using them where

          they are?) no. only a stack of jump bufs will work.


          update: this #if 1-0 work for either throwing or not,

                  just that the Jump objects are big and can't

                  be deleted just removed from the virtual table

                  by iterating it for its typeid or calling destroy().


          also:   the implementation choice that throws is only

                  done for console not all 3 (file, console, standard).

          and of course:

                  i leave the jumpBuf object in the vtable because

                  i like looking at it, if you want it deleted, you

                  push it onto the stack (inside try/throw/catch).h

                  before the throw and pop/delete it in catch.h, if

                  you want any object to be there for you after your

                  jump, push it not onto the jump stack (jPush(obj))

                  but the object stack using vPush(obj) before the throw.

     */
     }catch( Exception * e )
     {
         if( string(equal)( e->text, "NotAVirtualTableObject" ) )
         {
             delete(e);

             return printf("%s", self);
         }
     }}



        Container * v2 = new(Vector(int))(this, 255);//case == maxsize
                                                    //if case > 1 i think


        unsigned short max = typemax(unsigned short), i;

        for(i = 0; i < max; i++)
        {
            int * p;
            if( virtual(v2, Container)->insert(v2, i, rand() % 100) )

            { if(i % 1 == 0)
              {puts("insert() successful");} p = virtual(v2, Container)->at(v2, i);

                if( p != 0 )

                { if(i % 1 == 0){puts("at() successful");
                  printf("val: %d\tindex: %d\n", *p, i);} }

                else

                { if(i % 1 == 0){puts("at() unsuccessful");} }
            }

            else

            {
                if(i % 1 == 0)
                {printf("insert() unsuccessful\nindex: %d\n", i);}
                break;
            }
        }delete(v2);






        Iterator(char) * _iter = new(Iterator(char))(this, nullptr);

        Vector(char)   *    a = new(Vector(char))(this, 255),

                       *    b = new(Vector(char))(this, 255);

        Iterator       * _iter2= virtual(a, Container)->begin(this);//too soon


        v2 = new( Vector(int) )( this, 1000000 );




        Iterator * v2begin = virtual(v2, Container)->begin(this),

                 * v2end = virtual(v2, Vector(int))->end(this);

/*
        printf("int vector:\n");
        while( !virtual(v2begin, Iterator)->equal(this, v2end) )
        {

            printf("%d\t",  *((Iterator(int)*)v2begin)->p );

            virtual(v2begin, Iterator)->next(this);


        }printf("\n");
*/


        if( virtual(a, Vector(int))->resize(this, 40000000000) )
        {
            puts("resize succeeded");
            printf("new size: %d\n", virtual(a, Vector(int))->max(this));

            a->length = a->maxsize;
    printf( "new size: %d\n", (unsigned short)virtual(a, Container)->size(this) );
        }
        else
        {
            printf("resize unsuccessful\n");
                   //40 000 000 000
            a->length = 40000000000;

            printf( "size: %d\n", a->length);

                    a->length += 1;

            printf( "size: %d\n", a->length);

            printf( "size: %d\n", (unsigned long int)virtual(a, Container)->size(this) );
        }


        a->length = 0;

        Container * d;

        c = a; d = b;

        virtual(c, Container)->insert(this, 0, 'x');
        virtual(c, Container)->insert(this, 1, 'y');
        virtual(c, Container)->insert(this, 2, 'z');

        virtual(c, Container)->insert(this, 3, '1');
        virtual(c, Container)->insert(this, 4, '2');
        virtual(c, Container)->insert(this, 5, '3');

        char(Copy)(//copy or concatenate

            a->array + (size_t)virtual(c, Container)->size(this),

            a->array,

            a->array + (size_t)virtual(c, Container)->size(this) +

                       (size_t)virtual(c, Container)->size(this),

            a->array + (size_t)virtual(c, Container)->size(this)
        );
          a->length += (size_t)virtual(c, Container)->size(this);

        virtual(a, Container)->copy(this, a);//straight copy, do nothing if a == b

        for(size_t i = 0; i < (size_t)virtual(d, Container)->size(this); i++)
        {
            printf("%c ", *(char*)virtual(d, Container)->at(this, i));

        }puts("\n");

        printf("a size: %d\n", virtual(a, Vector(int))->max(this));
        if ( virtual(a, Vector(int))->resize(this, 12) ) //12
        {
            puts("resize succeeded");
        }
        else
        {
            puts("resize failed");
        }
        printf("a size: %d\n\n", virtual(a, Vector(int))->max(this));

        /// /// /// /// /// /// /// /// /// ///
        char* p = a->array;
        a->array = allocate(700);
        a->maxsize = 700;
        for(i = 0; i < (size_t)virtual(a, Container)->size(this); i++)
        {
            a->array[i] = p[i];
        }
        deallocate(p);
        /// /// /// /// /// /// /// /// /// ///

        for(i = 0; i < (size_t)virtual(a, Container)->size(this); i++)
        {
            printf("%c ", *(char*)virtual(a, Container)->at(this, i));

        }puts("\n");

        printf("front: %c\n", * virtual(a, Vector(int))->front(this));
        printf("back: %c\n", * virtual(a, Vector(int))->back(this));


        delete(a);

        delete(b);




    #if 1
        {
            multimap(true)(typeid(self))("class(VirtualHeap)");



            Virtual* virt = map(meth);
            if( !virt ){printf("noinfo");}


                  return &( (Object * *)

                  virtual( self, class ) )[ virt->val ] ;/// +this
        }
    #else





    #endif



    #if 0 //PLEASE_DEBUG_ERROR_FLAG_STACK_FAILURE___MULTIMAP___
        {
            multimap(true)(typeid(self)) ;

            class(Interface) * p = map("class(VirtualHeap)");

            if( !p ){ throw(new(NullPointer))
                (this, "NotAHeapInterface"); }

            virtual * v = ((methPtr*)p)[1](meth);

            if( !v ){ throw(new(NullPointer))
                (this, "NoInfo"); }

            return &( (Object * *)virtual( self, class ) )

            [ v->val ] ;/// +this
        }
    #else //ONE_STATEMENT




        /**+---------------------------------+
         * @brief multimap                   |
         * +---------------------------------+
         */
        explicit Registructor FactoryTable(Dex)(bool flag)
        //(compile time-dynamic) flag case
        {
    #if !DEX_FLAG___STACK___
            Dex(Flag) = flag;

    #else

            //if( Dex(I) < 3 ) { Dex(Flags)[Dex(I)]
            //    = new(bool)(this, flag); Dex(I)++; }
            //else{ throw(new(OutOfBounds))(this, "MaxMapFlags(3)") }

            bool * f = new(bool)(this, flag);
            if( (*f) != flag ){ (*f) = flag; }//DEBUG (ASSERT)

            if( !fPush( f ) )///<---push flag
                { throw( new(OutOfMemory) )
                (this, "FlagStackFailure"); }//


            //(Flag)fstk


            if( Dex(DebugFlag) ){

                    printf( "top: %d\n", **fTop() );

                    printf("flag: %d\n", flag ); };
            //(*flag) ? "true" : "false"

    #endif

          return registructor; }





            /// /// /// /// /// /// /// /// /// /// /// ///
        except explicit Object * (*Dex(02)
            (cstring key))(cstring)
        {   /// /// /// /// /// /// /// /// /// /// /// ///
            if( string(equal)( key, "" ) )
              { throw(new(EmptyString))
              (this, "EmptyInterfaceTypeID"); }

            class(Interface)
               * reg = 0;
            if( true )
               { reg = map (key); }             //<--pop map
            if( !reg ){ throw( new(NullPointer) )
                   (this, "NotAHeapInterface"); }

    #if !DEX_FLAG___STACK___
            if( Dex(Flag) )
    #else
            //bool * flag = Dex(Flags)[--Dex(I)];


            //if( string(equal)( ( vTop() ?
            //    typeid(*vTop()) : "" ), "bool" ) )
            //{
            //    flag = vPop(); ///<---pop flag
            //}




            bool * flag = flag();

            /*
            if( flag != true || flag != false )
            {
                flag = Dex(Flag)
            }*/


            if( Dex(DebugFlag) ){ printf("flag: %d\n", (*flag) ); }
            //(*flag) ? "true" : "false"


            if(   !flag   ){ throw( new(NullPointer) )
                            (this, "NullFlag"); }

            if(  (*flag)  )
    #endif


            {
    #if DEX_FLAG___STACK___
                delete(flag);
    #endif // DEX_FLAG___STACK___
                Key * security = Dex(Keys)(((typePtr*)reg)[0]());
                if ( !security ){ throw( new(NullPointer) )
                            (this, "NoSubFactoryMethod"); }

                if( !mPush(((methPtr*)reg)[1]) )//<--push map
                    { throw( new(OutOfMemory) )
                    (this, "MapStackFailure"); }

                return & Dex(03); }
            else///multidex

            {
    #if DEX_FLAG___STACK___
                delete(flag);
    #endif // DEX_FLAG___STACK___
                return reg; } }///dex
            /// /// /// /// /// /// /// /// /// /// /// ///


        /*typedef struct N(Flag)
        {
            Flag             info;
            struct N(Flag) * link;
        }N(Flag);

        static N(Flag) * newN(Flag)( Flag );

        explicit N(Flag) * newN(Flag)( Flag info )
        { N(Flag) * self = (N(Flag)*)
          allocate(sizeof(N(Flag)));
          if( !self ){ return 0; }
          self->link = 0;

          ((bool *)self->info)
           = info;
          return(self); }*/



/*  #if 1
      if( !fvector ){fvector = Flag(Vector)(Init)
        (allocate(sizeof(Flag(Vector))),5);}
    #endif // 0*/

   #if 0
    #define acc _acc //(after define _acc above)
    #define acv _acv
    #define acd _acd
    //(reserve the word act for something abstract/loop)//#define act
    #define aci _aci
   #endif // SCRUB

    //this also but no worries about that one (this)

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        CENTRAL;                ABORT;                  METHOD;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    private static private except private void struct(Bunker)

    (Override)(void *,...) ; private static private except

    private void (*Override)(void *,...)=&struct(Bunker)(Override);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
        CENTRAL;                ABORT;                  METHOD;
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


    /// /// /// /// /// /// /// /// /// ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    ///                                 ///
    /// /// /// /// /// /// /// /// /// ///
/*
    #include "../Template/defineVector.h"

    /// /// /// /// /// /// /// /// /// ///

    volatile static Object * volatile fvector = 0;

    static bool        fVectorPush(Flag);
    static bool        fVectorPop(void);///
    static Flag *      fVectorTop(void);

    # define FlagVector(Member)\
    \
        FlagVector ## Member

    # define FlagIterator(Member)\
    \
        FlagIterator ## Member

    hazardous typename(Iterator)(Flag) ;

    hazardous typename(Vector)(Flag, ) ;

    typedef FlagVector fVector;
*/

  #if 0 // 1 DEBUG
    explicit Object *   protected( Object * self, ... )
    {
        if( !(*Flags[0]) ){flags(0)=1;ControlSlot[0][0]=&self;}

        Object * objt = ((Object *(*)(Object*,...))

            (*function( self, "insert" )))(this);

        (*Flags[0]) = false;

        return objt;
    }
  #else
    //static Object * typename(Function)
        //(protected,Object *,Object *(*)(Object*,...),);
  #endif // DEBUG



  #if 0
    #define __temp__ static

    #define __temp__(flag)  ...


    //#define static(flag)

    static int __a;

    private int __b;

    #define private(flag)

    private ; int ___c; //chicken scratches _ _ _
  #endif // 0
/*
    #define static(flag) \
    \
        FactoryTable(Public)(flag)
    //static Flagstructor FactoryTable(Public)(bool);

    #define protected(flag) \
    \
        FactoryTable(Protected)(flag)
    //static Flagstructor FactoryTable(Protected)(bool);

    #define private(flag) \
    \
        FactoryTable(Private)(flag)
    static Flagstructor FactoryTable(Private)(bool);



    */


    /// /// /// /// /// /// /// /// /// ///
    /*             implement             */
    /** * * * * * * * * * * * * * * * * **
     * @brief spare list                 *
     * - - keep a spare list of ptrs - - *
     * @param                            *
     * @return bool                      *
     ** * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// ///
/*    explicit bool fVectorPush(Flag object)//
    {//throw?
        return Vector(Flag)(StackInsert)

        (fvector, object);
    }*/
    /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * **
     * @brief perform error checking     *
     * @return object oriented bool(Flag)*
     ** * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// ///
  /*  explicit bool fVectorPop(void)
    {//
        return Vector(Flag)(NoIndexRemove)

        (fvector);
    }*/
    /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * **
     * @brief fTop() to check last       *
     * @return Flag pointer              *
     ** * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// ///
  /*  explicit Flag * fVectorTop(void)
    {//
        return Vector(Flag)(NoIndexAt)

        (fvector);
    }*/
    /// /// /// /// /// /// /// /// /// ///

        #define DEX_FLAG___STACK___MULTIMAP___BUG___ 1 //TRY GET RID OF
    #define DEX_FLAG___STACK___ 1

    #if !DEX_FLAG___STACK___
        volatile static bool Dex(Flag) = false;
    #endif // DEX_FLAG___STACK___
        volatile static bool Dex(DebugFlag) = true;


    static bool * Dex(Flags)[3] = {nullptr,nullptr,nullptr} ;
    volatile static uint8_t Dex(I) = 0;

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /* clipboard:

    - - "access denied" if pass flag raised and no pass on stack.

    - - there is no check on the first data field pos of an
        interface being null, should be no problem, since they
        are initialized by constant value usually (without a
        builder mode/extension) but might want to do a check
        there as the last place to throw an exception over
        null pointer (the class factory method is an interface
        also).

    - - there is a check needed for memory failure with the
        push onto the stack also (so throw an exception).

     */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit int printAdapterTable (AdapterTable * self){}

    explicit int aTableTesting(AdapterTable * self) {}


    explicit int AdapterTable(PrintStandard)(AdapterTable * self, char * str){}

    explicit int AdapterTable(PrintFile)(AdapterTable * self, File * file){}




        Vector(int) * v = new(Vector(int))(this, 255);

        Container * c = v;

        virtual(c, Container)->insert(this, 0, 123);//
        virtual(c, Container)->insert(this, 1, 456);//
        virtual(c, Container)->insert(this, 2, 789);//
                                                    //



        Vector(int) * v2 = new(Vector(int))(this, 1, v);//copy constr

        virtual(v2, Container)->copy(this, v);//cast to base type

        virtual(v2, intVector)->resize(this, 64000);

            ///65280 as multiple of multiplier * original size

        printf("old size: %d\nnew size: %d\n",

               virtual(v, Vector(int))->max(this),

               virtual(v2, Vector(int))->max(this));

        Iterator(int) * it,

                      * end = new(Iterator(int))( this,

                            virtual(v2, Container)->at(this, 2) + 1 );

        Iterator * iter;//polymorphic base for all pointer iteration objects

        printf("size: %d\n", virtual(v2, Container)->size(this));

        int j;
        for(j = 0; j < 3; j++)
        {
            printf("%d ", virtual(v2, Container)->at(this, j) );
        }

        for( iter = new(Iterator(int))(this, virtual(v2, Container)->at(this, 0) );

            virtual(iter, Iterator)->equal(this, end);

            virtual(iter, Iterator)->next(this) )
        {
            printf("%d ", *(int*)virtual(iter, Iterator)->get(this) );
        }



    #define definePassNumber(Class, Interface)\
    \
        /*static cstring*/ Class(Interface)(Type)();\
    \
        volatile static string * volatile \
    \
            Class(Interface)(ID) = nullptr;\
    \
        explicit cstring Class(Interface)(Type)()\
    \
        { TypeID(PassNumber)(Class(Interface)(ID),\
    \
          & Class(Interface)); \
    \
          return (*Class(Interface)(ID)); }




        size_t k;
        for(k = 0; k <  virtual(v2, Container)->size(this); ++ k )
        {
            printf( "%d\t",  virtual(v2, Container)->at(this, k) );

        }printf("\n\n");


        delete(v);
        delete(v2);
        delete(end);
        delete(iter); //objects that are leaving visible scope delete

printf("delete bool\n");    \
printf("flag: %s\n", *pJumpVal?"true":"false"  );\
printf("flag: %u\n", *pJumpVal  );\
printf("_b: %s\n", _b?"true":"false"  );\
printf("_b: %u\n", _b  );\
printf("p?:");\
printf(" %u\n", (bool*)_b?"true":"false"  );\
printf("p?: %u\n", (bool*)_b  );\
    \
printf("((bool*)pJumpVal): %u\n", ((bool*)pJumpVal)  );\
printf("(*(bool*)pJumpVal): %u\n", *((bool*)pJumpVal) );\

printf("delete jump\n");



printf("flag (...): %u\n", *_p_.val  );\
           # define sub(member)sub ## member
            struct sub(FactoryMethod);// ; = {}
            #undef sub()




        Stk(int) * stk = new(Stk(int))(this);

        Iter(int) * itr;



        virtual(stk, Stk(int))->push(stk, 789);
        virtual(stk, Stk(int))->push(stk, 456);
        virtual(stk, Stk(int))->push(stk, 123);


        itr = virtual(stk, Container)->begin(stk);//do something


        printf("length: %d\n", Stk(int)(GetLength)(stk->stktop));

        while(stk->stktop != nullptr)
        {
            printf("%d", *virtual(stk, Stk(int))->top(stk));
            putchar(' ');
            virtual(stk, Stk(int))->pop(stk);

        }putchar('\n');

        if( delete(stk) )
        {}

        for(i2 = 0; i2 < ((Vector(ClassNameClassFactoryMethodPair)*)\
            self)->maxsize; i2++)/*//*/\
        { if(((Vector(ClassNameClassFactoryMethodPair)*)\
                self)->array[i2].val != nullptr)\
            {count++;Print "%s\n", ((Vector\
                    (ClassNameClassFactoryMethodPair)*)\
                    self)->array[i2].key End;\
                colCount++;}\
        }Print "\n\n" End;\

        for(i2 = 0; i2 < ((Vector(ClassNameClassFactoryMethodPair)*)
            self)->maxsize; i2++) //
        { if(((Vector(ClassNameClassFactoryMethodPair)*)
                self)->array[i2].val != nullptr)
            {count++;printf("%s\n", ((Vector
                    (ClassNameClassFactoryMethodPair)*)
                    self)->array[i2].key );
                colCount++;}
        }puts("\n\n");
        destroy(); //pack it in OOC... re-implemented to set up again


          0 1 2 3 4
          ( h e a p T
/*
        expand this (volatile(Init)) for switch of factory
        table classes at the same time remember, a complex... ()


                                - - or - -

        class(builder)(complex)(self, "var", int)(this, 123)

        including a constructor would be nice for the class
        builder version of complex. at the same time then there
        wouldn't be assignment from (not really).
*/


    printf("hello");

        /** STRING CLASS FACTORY METHOD **/
    static Interface String(HeapSearch) ( cstring );        /// #1

        /** STRING SUB FACTORY METHODS **/
    static Strategy * String(BasicsSearch)( cstring );   /// #2

    static Strategy * String(LibrarySearch)( cstring );   /// #3

    static Virtual *  String(VirtualSearch)( cstring );    /// #4

    static Polymorph * String(PolymorphSearch)( cstring );  /// #5

    static Complex * String(ComplexSearch)( cstring );  /// #6

/** USING ARRAYS IN C IS THAT AN AUTOMATIC ARRAY DOESN'T **/
                                 /** PROBABLY A REASON WHY NOT EVERYONE GETS THAT FAR **/
                                 /** USE AN EXTRA POINTER ...            AN AUTOMATIC ARRAY
                                     OF int OR ANOTHER AUTOMATIC DATATYPE CANT HAVE A DOUBLE
                                     POINTER POINT TO IT (TERMINATES THE PROGRAM).  **/
            if(     0     ){ /*THIS BLOCK WILL NEVER EXECUTE*/ }
            /*THIS OBJECT HAS A VIRTUAL TABLE THAT DOESN'T HAVE THE equal() FUNCTION SO...*/

            /**v(obj)->remove = 0;///assignment of read-only member 'remove' (GOOD) (final)*/

    /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * **
     * @brief print stack + height       *
     *                                   *
     * @return 0                         *
     ** * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// ///
    explicit int              tPrint(void)
    {
        return printTypeStk(tstk);
    }

    /// /// /// /// /// /// /// /// /// ///

    explicit int printTypeStk( Stk(Type) * self, ... )
    {
        N(Type) * node = ((Stk(Type)*)self)->stktop;
        while(   node   )
        {printf("%s\t", (void*)node->info);
            node = node->link;
        }printf("\n\n");
        printf( "height: %u\n\n",
            Stk(Type)(GetLength)
               ( ((Stk(Type)*)self)->stktop ) );
        return 0;}


    /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * **
     * @brief print stack + height       *
     *                                   *
     * @return 0                         *
     ** * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// ///
    explicit int              hPrint(void)
    {
        return print_HeapStk(hstk);
    }

    /// /// /// /// /// /// /// /// /// ///

    explicit int print_HeapStk( Stk(_Heap) * self, ... )
    {
        N(_Heap) * node = ((Stk(_Heap)*)self)->stktop;
        while(   node   )
        {printf("0x%x\t", (void*)node->info);
            node = node->link;
        }printf("\n\n");
        printf( "height: %u\n\n",
            Stk(_Heap)(GetLength)( ((Stk(_Heap)*)self)->stktop ) );
        return 0;}

    /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * **
     * @brief print stack + height       *
     *                                   *
     * @return 0                         *
     ** * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// ///
    explicit int              jPrint(void)
    {
        return printJumpStk(jstk);
    }

    /// /// /// /// /// /// /// /// /// ///

    explicit int printJumpStk( Stk(Jump) * self, ... )
    {
        N(Jump) * node = ((Stk(Jump)*)self)->stktop;
        while(   node   )
        {printf("0x%x\t", (void*)node->info.key);
        printf("0x%x\t", (void*)node->info.val);
        printf("%s\n", (*(bool*)node->info.val ? "true" : "false" ) );
            node = node->link;
        }printf("\n\n");
        printf( "height: %u\n\n",
            Stk(Jump)(GetLength)( ((Stk(Jump)*)self)->stktop ) );
        return 0;}

    /// /// /// /// /// /// /// /// /// ///
    /** * * * * * * * * * * * * * * * * **
     * @brief print stack + height       *
     *                                   *
     * @return 0                         *
     ** * * * * * * * * * * * * * * * * **/
    /// /// /// /// /// /// /// /// /// ///
    explicit int              ePrint(void)
    {
        return printExceptStk(estk);
    }

    /// /// /// /// /// /// /// /// /// ///

    explicit int printExceptStk( Stk(Except) * self, ... )
    {
        N(Except) * node = ((Stk(Except)*)self)->stktop;
        while(   node   )
        {printf("0x%x\t", (void*)node->info);
            node = node->link;
        }printf("\n\n");
        printf( "height: %u\n\n",
            Stk(Except)(GetLength)( ((Stk(Except)*)self)->stktop ) );
        return 0;}
