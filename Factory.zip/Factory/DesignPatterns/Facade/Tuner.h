#ifndef TUNER_H_INCLUDED
#define TUNER_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    #include "Amplifier.h"


    #define Tuner(Member)  Tuner##Member

    struct Tuner
    {   struct class base;

        String *      description;

        double        frequency;

    };


    struct Tuner(VirtualTable)
    {   struct class(VirtualTable) base;

        void (*on) ( Tuner * );

        void (*off)( Tuner * );

        void (*setFrequency)( Tuner *, double );

        void (*setAm)( Tuner * );

        void (*setFm)( Tuner * );

        cstring () (*toString)( Tuner * );

    };


    static Tuner * TunerInit( Tuner *, String *, ... );

    static void TunerDtor( Tuner * );

    static cstring TunerType();


    explicit cstring TunerType(){ return "Tuner"; }


    static void TunerOn ( Tuner * );

    static void TunerOff( Tuner * );

    static void TunerSetFrequency( Tuner *, double );

    static void TunerSetAm( Tuner * );

    static void TunerSetFm( Tuner * );

    static cstring TunerToString( Tuner * );


    static Tuner(VirtualTable)

        Tuner(Interface) =

    {
        {
            &TunerType,

            &TunerInit,

            &TunerDtor
        },

        &TunerOn,

        &TunerOff,

        &TunerSetFrequency,

        &TunerSetAm,

        &TunerSetFm,

        &TunerToString
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   initializer                                      *
     *                                                           *
     * @param   self, desc                                       *
     *                                                           *
     * @return  Tuner *                                          *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit Tuner * TunerInit( Tuner * self,

        String * description, ... )
    {
        if( !self ){ return 0; }

        self->description       =       description;

        return self;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   dtor (destructor)                                *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void TunerDtor( Tuner * self )
    {
        delete(self->description);
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   on                                               *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void TunerOn ( Tuner * self )
    {
        printf("%s is on\n",

            virtual( self->description, String )->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   off                                              *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void TunerOff( Tuner * self )
    {
        printf("%s is off\n",

            virtual( self->description, String )->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   setFreq                                          *
     *                                                           *
     * @param   self, freq                                       *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void TunerSetFrequency( Tuner * self, double frequency )
    {
        self->frequency = frequency;

        printf("%s setting frequency to %s\n",

            virtual( self->description, String )->toString(this), self->frequency);
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   setAm                                            *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void TunerSetAm( Tuner * self )
    {
        printf("%s setting AM mode\n",

            virtual( self->description, String )->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   setFm                                            *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void TunerSetFm( Tuner * self )
    {
        printf("%s setting FM mode\n",

            virtual( self->description, String )->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   toString                                         *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  cstring                                          *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit cstring TunerToString( Tuner * self )
    {
        return virtual( self->description, String )->toString(this) ;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   AmplifierSetTuner                                *
     *                                                           *
     * @param   self, tuner                                      *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void AmplifierSetTuner( Amplifier * self, Tuner * tuner )
    {
        self->tuner = tuner;

        printf("%s setting tuner to %s\n",

            virtual( self->description, String )->toString(this),

            virtual( self->tuner->description, String )->toString(this) );

    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///


#endif // TUNER_H_INCLUDED
