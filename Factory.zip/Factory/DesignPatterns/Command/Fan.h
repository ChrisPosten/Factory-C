#ifndef FAN_H_INCLUDED
#define FAN_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    #include "../../OOC/Virtual/vTable.h"

    #include "../../OOC/Library/String.h"


    #define Fan(Member) Fan##Member
    typedef struct
    {   struct class base;/// = {} (for automatic struct variable)

        String * location;

        int      level;/// OFF = -1, LOW = 0, MED = 1, HIGH = 2

    } Fan;


    typedef struct
    {   struct class (VirtualTable) base;

        void (*high)( Fan * );

        void (*med)( Fan * );

        void (*low)( Fan * );

        void (*off)( Fan * );

        int () (*getSpeed)( Fan * );

    }Fan(VirtualTable);

    ///called from constructor pointer with new(Fan)
    static Fan * FanInit( Fan *, String * );

    static void FanDtor( Fan * );

    static cstring FanType() ;


    explicit void FanDtor( Fan * self ){ delete(self->location); }

    explicit cstring FanType() { return "Fan"; }


    static void FanHigh( Fan * );

    static void FanMed( Fan * );

    static void FanLow( Fan * );

    static void FanOff( Fan * );

    static int FanGetSpeed( Fan * );



    static Fan(VirtualTable) FanInterface =

    {
      { &FanType, &FanInit, &FanDtor },

        &FanHigh,

        &FanMed,

        &FanLow,

        &FanOff,

        &FanGetSpeed };


    explicit Fan * FanInit

        ( Fan * self, String * location )

    { if(!self){return 0;}

        self->location = location;

        self->level = -1; //OFF

      return self; }


    explicit void FanHigh( Fan * self )

    { self->level = 2;///HIGH

      if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sFan is on high.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    explicit void FanMed( Fan * self )
    { self->level = 1;///MED

      if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sFan is on med.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    explicit void FanLow( Fan * self )
    { self->level = 0;///LOW

      if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sFan is on low.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    explicit void FanOff( Fan * self )
    { self->level = -1;///OFF

      if(!self->location)
      { printf("\"UNKNOWN LOCATION\"\n"); }
        printf("%sFan is off.\n",
            virtual(self->location, String)
            ->toString(this) ); }


    explicit int FanGetSpeed( Fan * self )

    { return self->level; }


#endif // FAN_H_INCLUDED
