#ifndef CDPLAYER_H_INCLUDED
#define CDPLAYER_H_INCLUDED
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *<Head First: Design Patterns textbook examples for OOC (Factory C)>*
 *                                                                   *
 * Copyright (C) <2023>  <Christopher Posten>                        *
 *                                                                   *
 * This program is free software: you can redistribute it and/or     *
 * modify it under the terms of the GNU General Public License       *
 * as published by the Free Software Foundation, either version 3    *
 * of the License, or any later version.                             *
 *                                                                   *
 * This program is distributed in the hope that it will be useful,   *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     *
 * GNU General Public License for more details.                      *
 *                                                                   *
 * You should have received a copy of the GNU General Public         *
 * License along with this program.  If not, see:                    *
 * <https://www.gnu.org/licenses/>.                                  *
 * Also: <https://www.fsf.org>  (Free Software Foundation).          *
 *                                                                   *
 * The author may be reached at: <christopher.posten@factoryc.org>.  *
 * or: <jb.bee250@gmail.com>                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                    initial preparation                    */
    #include "Amplifier.h"

    #define CDPlayer(Member)   CDPlayer##Member

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                          implement                        */
    typedef struct CDPlayer
    {   struct class base;

        String *      description,

               *      title;

        size_t        track;

    }CDPlayer;

    typedef struct CDPlayer(VirtualTable)
    {   struct class(VirtualTable) base;

        void (*on)( CDPlayer * );

        void (*off)( CDPlayer * );

        void (*eject)( CDPlayer * );

        void (*play)( CDPlayer *, String * );

        void (*stop)( CDPlayer * );

        void (*pause)( CDPlayer * );

        cstring () (*toString)( CDPlayer * );

    }CDPlayer(VirtualTable);

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                      prototypes                           */
    static CDPlayer * CDPlayerInit( CDPlayer *, String *, String *, size_t );

    static void CDPlayerDtor( CDPlayer * );

    static cstring CDPlayerType();


    explicit cstring CDPlayerType(){ return "CDPlayer"; }


    static void CDPlayerOn( CDPlayer * );

    static void CDPlayerOff( CDPlayer * );

    static void CDPlayerEject( CDPlayer * );

    static void CDPlayerPlay( CDPlayer *, String * );

    static void CDPlayerStop( CDPlayer * );

    static void CDPlayerPause( CDPlayer * );

    static cstring CDPlayerToString( CDPlayer * );

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                  declare static interface                 */
    static CDPlayer(VirtualTable)

        CDPlayer(Interface) =

    {
        {
            &CDPlayerType,

            &CDPlayerInit,

            &CDPlayerDtor
        },
        &CDPlayerOn,

        &CDPlayerOff,

        &CDPlayerEject,

        &CDPlayerPlay,

        &CDPlayerStop,

        &CDPlayerPause,

        &CDPlayerToString
    };

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   initializer constructor can point to (ClassInit) *
     *                                                           *
     * @param   self , desc                                      *
     *                                                           *
     * @return  instance to initialize pointer after new(Class)  *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /*                     implement functions                   */
    explicit CDPlayer * CDPlayerInit( CDPlayer * self, String * description,

        String * title, size_t track )
    {
        if( !self ){ return 0; }

        self->description       =       description;

        self->title             =       title;

        self->track             =       track;

        return self;
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   destructor (dtor)                                *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CDPlayerDtor( CDPlayer * self )
    {
        delete(self->description);

        delete(self->title);
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   on                                               *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CDPlayerOn( CDPlayer * self )
    {
        printf("%s is on\n", virtual( self->description, String )

               ->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   off                                              *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CDPlayerOff( CDPlayer * self )
    {
        printf("%s is off\n", virtual( self->description, String )

               ->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   eject                                            *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CDPlayerEject( CDPlayer * self )
    {
        self->title = null;

        printf("%s eject\n", virtual( self->description, String )

            ->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   play                                             *
     *                                                           *
     * @param   self, title                                      *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CDPlayerPlay( CDPlayer * self, String * title )
    {
        self->title = title;

        self->track = 0;

        printf("%s playing %s \n",

            virtual( self->description, String )

               ->toString(this), self->title);
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   stop                                             *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CDPlayerStop( CDPlayer * self )
    {
        self->track = 0;

        printf("%s stopped \n", virtual( self->description, String )

               ->toString(this));
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   pause                                            *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  void                                             *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit void CDPlayerPause( CDPlayer * self )
    {
        printf("%s paused %s \n",

            virtual( self->description, String )

               ->toString(this), self->title);
    }

    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///
    /**                                                          *
     * @brief   toString                                         *
     *                                                           *
     * @param   self                                             *
     *                                                           *
     * @return  cstring                                          *
     *                                                           */
    /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// ///

    explicit cstring CDPlayerToString( CDPlayer * self )
    {
        return virtual( self->description, String )->toString(this) ;
    }

    /**
    THIS CLASS CAME WITH AN OVERLOADED FUNCTION IN JAVA. HERE THERE IS A COUPLE

    SOLUTIONS FOR THAT AND ONE WOULD BE A FACTORY FUNCTION WITH A CASE NUMBER

    FOR A DEFAULT SECOND PARAMETER, THE CASE NUMBER WOULD DETERMINE WHAT PARAMETERS

    COME NEXT AND HOW THEY ARE TREATED. THE OTHER OPTION WOULD BE TO FILL OUT THE

    METHODS TABLE AND OR THE FUNCTIONS TABLE FOR A FACTORY TABLE CLASS AND INCLUDE

    THE CENTRAL OVERLOAD FUNCTION FOR THAT FUNCTION. play() THAT WOULD BE THE GLOBAL

    FACTORY OBJECT FUNCTION (USING A METHOD NAME) THATS THE CENTRAL OVERLOAD FUNCTION

    play(). void play( Object * self, ... ); WOULD USE A VIRTUAL TABLE OBJECT

    THATS AN OBJECT OF A FACTORY TABLE CLASS, BOTH FOR THE String AND THE int ALSO

    SO THEIR typeid(obj) CAN BE USED AS THE KEY TO THE FACTORY METHOD FOR THAT DATATYPE.

    THE CDPlayer WOULD BE THE CLASS THAT HAS THOSE FUNCTIONS AS A FACTORY TABLE CLASS.

    THERE NEEDS TO BE AT LEAST TWO VERSIONS OF THAT FUNCTION TO CALL, THAT WOULD BE

    DETERMINED BY THE typeid(obj) OF THE SECOND PARAMETER.
     */


         /*void (*play)( CDPlayer *, String * );*////void (*play)( CDPlayer *, ... );

        ///void (*play)( CDPlayer *, int * ); ///MUST BE A FACTORY TABLE CLASS
#endif // CDPLAYER_H_INCLUDED
